<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
$textl = 'Opsi Blog';
$headmod = 'blog';
$actions = array("categories","recent_posts","search","top_blogs","top_comments","top_posts");
if ($act && in_array($act,$actions)) { require("includes/".$act.".php"); }
else { require("includes/index.php"); }
require('../incfiles/end.php');
