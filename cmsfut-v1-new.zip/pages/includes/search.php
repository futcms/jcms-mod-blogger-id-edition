<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = $textl." | Pencarian";
require('../incfiles/head.php');
echo '<div class="phdr"><a href="blog.php"><b>Opsi Blog</b></a> | Pencarian Posting</div>';
$q = isset($_GET['q']) ? htmlentities($_GET['q']) : false;
echo '<div class="gmenu"><p><h3>Pencarian Posting</h3><form method="get" action="blog.php"><input type="hidden" name="act" value="search"/><input type="text" name="q" value="'.$q.'"/><p><input type="submit" value="Cari"/></p></form></p></div>';
if (!$q OR strlen($q) < 2 OR strlen($q) > 10) {
echo 'Cari postingan minimal 2 dan maksimal 10 karakter.';
}
else {
$total = mysql_result(mysql_query("SELECT COUNT(DISTINCT `id`) FROM `blog_posts` WHERE `title` LIKE '%".mysql_real_escape_string($q)."%' AND `draft`='no'"),0);
if ($total == 0) {
echo '<div class="menu">Tidak menemukan hasil untuk pencarian "'.$q.'".</div>';
} else {
echo '<div class="gmenu">Ditemukan '.$total.' hasil untuk pencarian "'.$q.'".</div>';
$query = mysql_query("SELECT `id`,`site_id`,`user_id`,`title`,`permalink`,`time` FROM `blog_posts` WHERE `title` LIKE '%".mysql_real_escape_string($q)."%' AND `draft`='no' ORDER BY `time` DESC LIMIT $start, $kmess");
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('blog.php?act=search&amp;q='.$q.'&amp;', $start, $total, $kmess).'</div>';
while ($post=mysql_fetch_array($query)) {
$blog = mysql_fetch_array(mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".$post['site_id']."'"));
$author = mysql_fetch_array(mysql_query("SELECT `name` FROM `users` WHERE `id`='".$post['user_id']."'"));
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="'.functions::blog_link($blog['url1']).'/'.$post['permalink'].'.html">'.str_ireplace($q,"<font color=\"red\"><b>".$q."</b></font>",$post['title']).' | '.htmlspecialchars($blog['title']).'</a><div class="sub">'.(($rights == 7 || $rights == 9) ? '<div><a href="../panel-blog/index.php?act=edit_post&amp;post_id='.$post['id'].'">Edit</a> | <a href="../panel-blog/index.php?act=edit_post&amp;mod=delete&amp;post_id='.$post['id'].'"><span class="red">Hapus</span></a></div>' : '').'Penulis: <a href="../users/profile.php?user='.$post['user_id'].'">'.$author['name'].'</a><br />Waktu: '.functions::display_date($post['time']).'</div>';
echo '</div>';
++$i;
}
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('blog.php?act=search&amp;q='.$q.'&amp;', $start, $total, $kmess).'</div>';
}
}