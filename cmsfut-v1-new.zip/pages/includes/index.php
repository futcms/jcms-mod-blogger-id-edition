<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
require('../incfiles/head.php');
echo '<div class="phdr"><b>Opsi Blog</b></div>
<div class="gmenu"><p><h3>Pencarian Posting</h3><form method="get" action="blog.php"><input type="hidden" name="act" value="search"/><input type="text" name="q" value=""/><p><input type="submit" value="Cari"/></p></form></p></div>
<div class="menu"><a href="blog.php?act=recent_posts">Posting Terbaru</a></div>
<div class="menu"><a href="blog.php?act=top_comments">Komentar Terbanyak</a></div>
<div class="menu"><a href="blog.php?act=top_posts">Top Posting</a></div>
<div class="menu"><a href="blog.php?act=top_blogs">Top Blog</a></div>
<div class="menu"><a href="whois.php">WHOIS</a></div>
<div class="phdr"><b>Kategori</b></div>';
$blog_categories = explode(",",$set['blogcat']);
$in = array();
for ($i=0;$i<count($blog_categories);$i++) {
$in[] = strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$blog_categories[$i])));$cat = str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$blog_categories[$i]));
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_sites` WHERE `category`='".strtolower($cat)."'"),0);
echo '<div class="menu"><a href="blog.php?act=categories&amp;category='.$cat.'">'.$blog_categories[$i].'</a> ('.$total.')</div>';
}
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_sites` WHERE FIND_IN_SET(category,'".implode(",",$in)."') = 0"),0);
echo '<div class="menu"><a href="blog.php?act=categories&amp;category=uncategories">Uncategories</a> ('.$total.')</div>';
