<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');
$textl = $textl." | Top Blog";
require('../incfiles/head.php');
switch ($mod) {
case 'all_time':
$xmod = "all_time";
$query = "`user_id`!=''";
$order = "`hits_total`";
break;
default:
$xmod = "today";
$query = "`user_id`!='' AND `hits_today_date`='".date("d-m-Y",(time() + $set['timeshift']))."'";
$order = "`hits_today`";
break;
}
echo '<div class="phdr"><a href="blog.php"><b>Opsi Blog</b></a> | Top Blog | '.($xmod == "all_time" ? 'Semua waktu' : 'Hari ini').'</div>';
echo '<div class="menu"><ul><li>'.($xmod == "all_time" ? '<a href="blog.php?act=top_blogs&amp;mod=today">Hari ini</a>' : 'Hari ini').'</li><li>'.($xmod == "today" ? '<a href="blog.php?act=top_blogs&amp;mod=all_time">Semua waktu</a>' : 'Semua waktu').'</li></ul></div>';
$total = mysql_result(mysql_query("SELECT COUNT(DISTINCT `id`) FROM `blog_sites` WHERE $query"),0);
if ($total == 0) {
echo '<div class="menu">Belum ada Blog.</div>';
} else {
$req = mysql_query("SELECT `id`,`user_id`,`title`,`url1`,`hits_today`,`hits_total` FROM `blog_sites` WHERE $query ORDER BY $order DESC LIMIT 10");

while ($blog=mysql_fetch_array($req)) {
$author = mysql_fetch_array(mysql_query("SELECT `name` FROM `users` WHERE `id`='".$blog['user_id']."'"));
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="'.functions::blog_link($blog['url1']).'">'.htmlspecialchars($blog['title']).'</a><div class="sub">'.(($rights == 7 || $rights == 9) ? '<div><a href="../panel-blog/index.php?act=edit_blog&amp;blog_id='.$blog['id'].'">Edit</a> | <a class="red" href="../panel-blog/index.php?act=edit_blog&amp;mod=delete&amp;blog_id='.$blog['id'].'">Hapus</a></div>' : '').'Pengelola: <a href="../users/profile.php?user='.$post['user_id'].'">'.$author['name'].'</a><br />';
if($mod == "all_time")
echo 'Hits semua waktu: '.$blog['hits_total'];
else
echo 'Hits hari ini: '.$blog['hits_today'];
echo '</div>';
echo '</div>';
++$i;
}
}
