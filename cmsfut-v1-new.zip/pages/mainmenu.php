<?
/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

defined('_IN_JOHNCMS') or die('Error: restricted access');

$mp = new mainpage();

/*
-----------------------------------------------------------------
Блок информации
-----------------------------------------------------------------
*/
echo $mp->news;
echo '<div class="phdr"><b>Posting Terbaru</b></div>';
$total_posts = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `draft`='no'"),0);
if ($total_posts) {
$posts = mysql_query("SELECT `site_id`,`title`,`permalink`,`time` FROM `blog_posts` WHERE `draft`='no' ORDER BY `time` DESC LIMIT 5");
while($post=mysql_fetch_array($posts)) {
$blog = mysql_fetch_assoc(mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".$post['site_id']."'"));
echo '<div class="menu"><a href="'.($user_id ? $set['homeurl'].'/login.php?r='.urlencode(functions::blog_link($blog['url1']).'/'.$post['permalink'].'.html') : functions::blog_link($blog['url1']).'/'.$post['permalink'].'.html').'">'.htmlspecialchars($post['title']." | ".$blog['title']).'</a> <span class="gray">'.functions::display_date($post['time']).'</span></div>';
}
}
else {
echo '<div class="menu">'.$lng['list_empty'].'</div>';
}
echo '<div class="phdr"><b>Opsi Blog</b></div><div class="menu"><a href="pages/blog.php?act=recent_posts">Posting Terbaru</a></div>
<div class="menu"><a href="pages/blog.php?act=top_comments">Komentar Terbanyak</a></div>
<div class="menu"><a href="pages/blog.php?act=top_posts">Top Posting</a></div><div class="menu"><a href="pages/blog.php?act=top_blogs">Top Blog</a></div><div class="menu"><a href="pages/blog.php?">Kategori Blog</a></div>';
echo '<div class="phdr"><b>Penanda</b></div>';
/*
echo '<div class="menu"><a href="news/index.php">' . $lng['news_archive'] . '</a> (' . $mp->newscount . ')</div>';
*/
/*
-----------------------------------------------------------------
Блок общения
-----------------------------------------------------------------
*/
echo '<div class="phdr"><b>' . $lng['dialogue'] . '</b></div>';
// Ссылка на гостевую
if ($set['mod_guest'] || $rights >= 7)
    echo '<div class="menu"><a href="guestbook/index.php">' . $lng['guestbook'] . '</a> (' . counters::guestbook() . ')</div>';
// Ссылка на Форум
if ($set['mod_forum'] || $rights >= 7)
    echo '<div class="menu"><a href="forum/">' . $lng['forum'] . '</a> (' . counters::forum() . ')</div>';

// Forum Updates
echo '<div class="phdr"><b>Forum Updates</b></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' and kedit='0' AND `close`!='1'"), 0);

$req = mysql_query("SELECT * FROM `forum` WHERE `type` = 't' and kedit='0' AND `close`!='1' ORDER BY `time` DESC LIMIT $start, $kmess");
while ($arr = mysql_fetch_array($req)) {
$q3 = mysql_query("select `id`, `refid`, `text` from `forum` where type='r' and id='" . $arr['refid'] . "'");
$razd = mysql_fetch_array($q3);
$q4 = mysql_query("select `id`, `refid`, `text` from `forum` where type='f' and id='" . $razd['refid'] . "'");
$frm = mysql_fetch_array($q4);
$nikuser = mysql_query("SELECT `from`, `time` FROM `forum` WHERE `type` = 'm' AND `close` != '1' AND `refid` = '" . $arr['id'] . "'ORDER BY time DESC");
$nik = mysql_query("SELECT `from`, `id`, `text`, `time` FROM `forum` WHERE `type` = 'm' AND `close` != '1' AND `refid` = '" . $arr['id'] . "'ORDER BY time ASC");
$colmes1 = mysql_num_rows($nikuser);
$cpg = ceil($colmes1 / $kmess);
$nam = mysql_fetch_array($nikuser);
$na = mysql_fetch_array($nik);
$np = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_forum_rdm` WHERE `time` >= '" . $arr['time'] . "' AND `topic_id` = '" . $arr['id'] . "' AND `user_id`='$user_id'"), 0);
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
// Topic icons
$icons = array(
($np ? (!$arr['vip'] ? '<img src="../images/op.gif" alt="op" />' : '') : '<img src="../images/np.gif" alt="np" />'),
($arr['vip'] ? '<img src="../images/pt.gif" alt="pt" />' : ''),
($arr['realid'] ? '<img src="../images/rate.gif" alt="rate" />' : ''),
($arr['edit'] ? '<img src="../images/tz.gif" alt="tz" />' : '')
);
echo functions::display_menu($icons, ' ', ' ');
echo functions::display_prefix($style,$arr['prefix']);
echo '<a href="'.$home.'/forum/index.php?id=' . $arr['id'] . '">' . $arr['text'] . '</a>';
echo '<small> [' . $colmes1 . ']</small> ';
if ($cpg > 1)
echo '<a href="forum/index.php?id=' . $arr['id'] . ($_SESSION['uppost'] ? '' : '&clip&page=' . $cpg) . '">&gt;&gt;</a>';
echo '<div class="sub">';
echo $na['from'];
echo ' / ';
echo $nam['from'];
echo ' <span class="gray">(' . functions::display_date($arr['time']) . ')</span>';
echo '</div></div>';
$i++;
}

if ($total > $kmess){
echo '<div class="topmenu">' . functions::display_pagination('index.php?', $start, $total, $kmess) . '</div>';
}


if ($total == 0) {
echo '<div class="menu">
<p>' . $lng['list_empty'] . '</p></div>';
}

/*
-----------------------------------------------------------------
Блок полезного
-----------------------------------------------------------------
*/    
// Ссылка на загрузки
if ($set['mod_down'] || $rights >= 7)
    echo '<div class="menu"><a href="download/">' . $lng['downloads'] . '</a> (' . counters::downloads() . ')</div>';
// Ссылка на библиотеку
if ($set['mod_lib'] || $rights >= 7)
    echo '<div class="menu"><a href="library/">' . $lng['library'] . '</a> (' . counters::library() . ')</div>';
// Ссылка на библиотеку
if ($set['mod_gal'] || $rights >= 7)
    echo '<div class="menu"><a href="gallery/">' . $lng['gallery'] . '</a> (' . counters::gallery() . ')</div>';
if ($user_id || $set['active']) {
$total_templates = mysql_result(mysql_query("SELECT COUNT(*) FROM `sharetemplates` WHERE `type`='file'"),0);
    echo '<div class="menu"><a href="users/index.php">' . $lng['users'] . '</a> (' . counters::users() . ')</div>' .
        '<div class="menu"><a href="users/album.php">' . $lng['photo_albums'] . '</a> (' . counters::album() . ')</div>' .
        '<div class="menu"><a href="share-templates/">Share Templates</a> ('.$total_templates.')</div>';
}
?>
