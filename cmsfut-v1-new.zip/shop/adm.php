<?php

define('_IN_JOHNCMS', 1);

require_once('../incfiles/core.php');
$textl = 'Set pricing';
require_once('../incfiles/head.php');

if ($rights > 6 and $user_id){
echo '<div class="phdr"><b>Set pricing</b> | <a href="/shop/">Shop</a></div>';

switch ($act) {
case 'price':
if (isset($_POST['submit'])) {

    $pr1 = isset($_POST['status']) ? abs(intval($_POST['status'])) : '';
    $pr2 = isset($_POST['login']) ? abs(intval($_POST['login'])) : '';
    $pr3 = isset($_POST['karmap']) ? abs(intval($_POST['karmap'])) : '';
    $pr4 = isset($_POST['karmam']) ? abs(intval($_POST['karmam'])) : '';
    $pr5 = isset($_POST['amail']) ? abs(intval($_POST['amail'])) : '';
    $pr6 = isset($_POST['cnick']) ? abs(intval($_POST['cnick'])) : '';
    $pr7 = isset($_POST['cstat']) ? abs(intval($_POST['cstat'])) : '';
    $error = false;

    if (empty($pr1) || empty($pr2) || empty($pr3) || empty($pr4) || empty($pr5) || empty($pr6) || empty($pr7))
        $error = $error . 'Do not put price!<br />';

    if (preg_match('/[^\d]+/', $pr1) || preg_match('/[^\d]+/', $pr2) || preg_match('/[^\d]+/', $pr3) || preg_match('/[^\d]+/', $pr4) || preg_match('/[^\d]+/', $pr5) || preg_match('/[^\d]+/', $pr6) || preg_match('/[^\d]+/', $pr7))
        $error = $error . 'Invalid characters in the price!<br />';

    if (empty($error)) {

    mysql_query("UPDATE `shop` SET `price` = CASE WHEN `id` = 1 THEN '$pr1' WHEN `id` = 2 THEN '$pr2' WHEN `id` = 3 THEN '$pr3' WHEN `id` = 4 THEN '$pr4' WHEN `id` = 10 THEN '$pr5' WHEN `id` = 11 THEN '$pr6' WHEN `id` = 12 THEN '$pr7' END WHERE `id` IN('1', '2', '3', '4', '10', '11', '12')");

        echo '<div class="gmenu">Prices are set!</div>';
    } else {
        echo '<div class="rmenu"><p><b>ERROR!</b><br />' . $error . '</p></div>';
    }
       }

    $price_sql = mysql_query("SELECT `price` FROM `shop` WHERE `id` IN('1', '2', '3', '4', '10', '11', '12')");
    $i = 1;
    $arr = array(1 => "Installation status:","Change Nick:","Karma +:","Karma -:","Anonymous PM","Color Nick:","Color Status:");
    $arr2 = array(1 => "status","login","karmap","karmam","amail","cnick","cstat");
    $arr3 = array(1 =>
    "Enter the amount debited from the user during the installation status of coins",
    "Enter the amount debited from the user when changing nickname coins",
    "Enter the amount debited from the user coins for a positive vote in karma",
    "Enter the amount debited from the user coins for removing the negative voices in karma",
    "Enter the amount debited from the user coins for sending anonymous PM",
    "Enter the amount debited from the user for changing the color of coins Nick",
    "Enter the amount debited from the user for changing the color of coins Status");

    echo '<div class="list2">Admin, you can assign sdes prices of goods in the store.</div>';
    echo '<form action="adm.php?act=price" method="post">';

    while ($price = mysql_fetch_assoc($price_sql)) {
    echo $i % 2 ? '<div class="list2">' : '<div class="list1">';

    echo '<p><b>'.$arr[''.$i.''].'</b><br/><input type="text" name="'.$arr2[''.$i.''].'" maxlength="15" value="' . $price['price'] . '" /><br/><small>'.$arr3[''.$i.''].'</small></p>';

    echo '</div>';
    ++$i;
    }

    echo '<div class="nfooter"><input type="submit" name="submit" value="Set prices"/></div></form></div></div>';
    break;

case 'balans':
    if (isset($_POST['submit'])) {

    $mn1 = isset($_POST['bonus']) ? abs(intval($_POST['bonus'])) : '';
    $mn2 = isset($_POST['fpost']) ? abs(intval($_POST['fpost'])) : '';
    $mn3 = isset($_POST['nt']) ? abs(intval($_POST['nt'])) : '';
    $mn4 = isset($_POST['gpost']) ? abs(intval($_POST['gpost'])) : '';
    $mn5 = isset($_POST['komm']) ? abs(intval($_POST['komm'])) : '';
    $mn6 = isset($_POST['reg']) ? abs(intval($_POST['reg'])) : '';
    $error = false;


    if (empty($mn1) || empty($mn2) || empty($mn3) || empty($mn4) || empty($mn5) || empty($mn6))
    $error = $error . 'Entered amount of coins!<br />';

    if (preg_match('/[^\d]+/', $mn1) || preg_match('/[^\d]+/', $mn2) || preg_match('/[^\d]+/', $mn3) || preg_match('/[^\d]+/', $mn4) || preg_match('/[^\d]+/', $mn5) || preg_match('/[^\d]+/', $mn6))
    $error = $error . 'Invalid characters!<br />';

    if (empty($error)) {
        mysql_query("UPDATE `shop` SET `price` = CASE WHEN `id` = 5 THEN '$mn1' WHEN `id` = 6 THEN '$mn2' WHEN `id` = 7 THEN '$mn3' WHEN `id` = 8 THEN '$mn4' WHEN `id` = 9 THEN '$mn5' WHEN `id` = 13 THEN '$mn6' END WHERE `id` IN('5', '6', '7', '8', '9', '13')");
        echo '<div class="gmenu">Accrual coins found!</div>';
    } else {
        echo '<div class="rmenu"><p><b>ERROR!</b><br />' . $error . '</p></div>';
    }
       }

    $price_sql = mysql_query("SELECT `price` FROM `shop` WHERE `id` IN('5', '6', '7', '8', '9', '13')");

    $i = 1;

    $arr = array(1 => "Bonus:","Forum Post:","New Topic:","Post in the Guestbook:","Comment:","Registration:");
    $arr2 = array(1 => "bonus","fpost","nt","gpost","komm","reg");
    $arr3 = array(1 =>
    "Enter the amount accrued to the user in the form of coins daily bonus",
    "Enter the number of coins for the user accrued forum post",
    "Enter the number of the user assessed coins for creating a new theme and PP in it",
    "Enter the number of coins for the user accrued post guestbook",
    "Enter the number of coins for the user accrued comment",
    "Enter the number of coins to the user assessed for registering at");

    echo '<div class="list2">Admin, you can assign sdes coins accrued nick for posts.<br/>And also the number of coins daily bonus.</div>';
    echo '<form action="adm.php?act=balans" method="post">';

    while ($price = mysql_fetch_assoc($price_sql)) {
        echo $i % 2 ? '<div class="list2">' : '<div class="list1">';

        echo '<p><b>'.$arr[''.$i.''].'</b><br/><input type="text" name="'.$arr2[''.$i.''].'" maxlength="15" value="' . $price['price'] . '" /><br/><small>'.$arr3[''.$i.''].'</small></p>';

        echo '</div>';
        ++$i;
    }

    echo '<div class="phdr"><input type="submit" name="submit" value="Set prices"/></div></form></div></div>';
    break;

default:
echo '<div class="list1"><a href="adm.php?act=price">Prices of goods</a></div>';
echo '<div class="list2"><a href="adm.php?act=balans">Bonus / Coins for posts</a></div>';
echo '<div class="nfooter">Admin, you can assign sdes prices of goods in the store.<br/>And coins accrued nick for posts.<br/>And also change the number of coins daily bonus.</div>';
      }
}

require_once('../incfiles/end.php');
?>