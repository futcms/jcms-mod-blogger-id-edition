<?php

define('_IN_JOHNCMS', 1);

require_once('../incfiles/core.php');
require_once('../incfiles/head.php');
$textl = 'Shop Site';

if (!$user_id) {
echo '<div class="rmenu"><p><b>ERROR!</b><br />You are not logged!</p></div>';
} else {
$array = array(
    'status',
    'karmap',
    'karmam',
    'nick',
    'amail'
);
if ($act && ($key = array_search($act, $array)) !== false && file_exists('includes/' . $array[$key] . '.php')) {
    require('includes/' . $array[$key] . '.php');
} else {
echo '<div class="phdr"><b>Shop</b></div>';

if ($rights > 6)
echo '<div class="rmenu"><a href="adm.php">Set pricing</a></div>';

echo '<div class="list1"><a href="money.php">Transfer coins</a></div>';
echo '<div class="list2"><a href="/users/color.php">Nick Color</a></div>';
echo '<div class="list1"><a href="index.php?act=status">Set Status</a></div>';
echo '<div class="list2"><a href="index.php?act=nick">Change nick</a></div>';
echo '<div class="list1"><a href="index.php?act=karmap">Karma +</a></div>';
echo '<div class="list2"><a href="index.php?act=karmam">Karma -</a></div>';
echo '<div class="list1"><a href="index.php?act=amail">Anonymous shipping PM</a></div>';
echo '<div class="phdr">' . $lng['hi'] . '<b> '.$login.'</b>! This shop site!<br/>There you can spend your coins on something useful.<br/>At this point you <b>' . $datauser['balans'] . '</b> coins!</div>';
  }
    }
require_once('../incfiles/end.php');

?>
