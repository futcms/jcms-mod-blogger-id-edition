<?php

define('_IN_JOHNCMS', 1);
require_once('../incfiles/core.php');
require_once('../incfiles/head.php');
$textl = 'Shop Site';

if (!$user_id) {
echo '<div class="rmenu"><p><b>ERROR!</b><br />You are not logged!</p></div>';
} else {
echo '<div class="phdr"><b>Transfer coins</b> | <a href="/shop/">Shop</a></div>';

switch ($act) {
case 'ok':

    $kod = isset($_POST['kod']) ? trim($_POST['kod']) : '';
    $logid = isset($_POST['logid']) ? trim($_POST['logid']) : '';
    $sum = isset($_POST['sum']) ? abs(intval($_POST['sum'])) : '';
    $error = false;

    if (empty($logid))
        $error = $error . 'Not entered Nick/ID<br />';
    elseif (mb_strlen($logid) > 15)
        $error = $error . 'Invalid length Username/ID!<br />';
    if (preg_match('/[^\da-zA-Z\-\@\*\(\)\?\!\~\_\=\[\]]+/', $logid))
        $error = $error . 'Invalid characters Username/ID!<br />';

    if (empty($sum))
        $error = $error . 'Do not enter the amount!<br />';
    if (preg_match('/[^\d]+/', $sum))
        $error = $error . 'Invalid characters in total!<br />';
    // CAPTCHA
    if (empty($kod) || mb_strlen($kod) < 4)
        $error = $error . 'You have not entered the verification code!<br />';
    elseif ($kod != $_SESSION['code'])
        $error = $error . 'Verification code is incorrect!<br />';
    unset($_SESSION['code']);

    if (empty($error)) {

        if (is_numeric($logid) != false) {
        $req = mysql_query("select * from `users` where `id`='$logid'");
        if (mysql_num_rows($req) == 0) $error = 'No such nick!<br/>';
        } else {
        $uid = mysql_fetch_assoc(mysql_query("SELECT `id` FROM `users` WHERE `name`='$logid'"));
        $req = mysql_query("select * from `users` where `id`='".$uid['id']."'");
        $logid = $uid['id'];
        if (mysql_num_rows($req) == 0) $error = 'No such nick!<br/>';
        }

        if ($datauser['balans'] < $sum || $datauser['balans'] == 0) {
        $error = 'You do not have enough coins!<br/>';
        }
    }

    if (empty($error)) {
        $mon = mysql_fetch_assoc(mysql_query("SELECT `balans` FROM `users` WHERE `id`='$logid'"));
        mysql_query("UPDATE `users` SET `balans` = '" . ($mon['balans'] + $sum) . "' WHERE `id` = '$logid'");
        mysql_query("UPDATE `users` SET `balans` = '" . ($datauser['balans'] - $sum) . "' WHERE `id` = '$user_id'");
        mysql_query("INSERT INTO `cms_mail` SET `user_id` = '0',`from_id` = '" . $logid . "',`text` = 'User [b]".$login."[/b] you turned [b]".$sum."[/b] coin site!',`time` = '" . time() . "',`sys` = '1',`them` = 'Translation coins'");
        $polz = mysql_fetch_assoc(mysql_query("SELECT `name` FROM `users` WHERE `id`='$logid'"));
        mysql_query("INSERT INTO `cms_mail` SET `user_id` = '0',`from_id` = '" . $user_id . "',`text` = 'You have translated [b]".$sum."[/b] coin site user [b]".$polz['name']."[/b]!',`time` = '" . time() . "',`sys` = '1',`them` = 'Translation coins'");
        echo '<div class="gmenu">Translated!';
        echo '<br/><a href="/shop/">In Store</a>';
        echo '</div>';
    } else {
        echo '<div class="rmenu"><p><b>ERROR!</b><br />' . $error . '</p></div>';
    }

break;

default:

    echo '<div class="list2"><b>'.$login.'</b>, Sdes you can convert their coin to another user.</div>';
    echo '<form action="money.php?act=ok" method="post"><div class="list1">';
    if ($user) {
    $usr = mysql_fetch_assoc(mysql_query("SELECT `name` FROM `users` WHERE `id`=".$user.""));
    }
    echo '<p><b>ID or Nickname:</b><br/><input type="text" name="logid" maxlength="15" '.($user ? 'value="' . $usr['name'] . '"' : '').' /><br/><small>Enter user ID or Nick transferee coins</small></p>';
    echo '<p><b>Amount:</b><br/><input type="text" name="sum" maxlength="15" /><br/>Enter the amount you want to transfer</small></p></div>';
    echo '<div class="gmenu"><p><img src="/captcha.php?r=' . rand(1000, 9999) . '" alt="Verification code" border="1"/><br />';
    echo 'Captcha:<br/><input type="text" size="5" maxlength="5" name="kod"/></p></div>';
    echo '<div class="phdr"><input type="submit" name="submit" value="Submit"/></div></form>';
break;
    }
       }
require_once('../incfiles/end.php');
?>