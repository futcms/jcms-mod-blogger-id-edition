<?php

define('_IN_JOHNCMS', 1);

echo '<div class="phdr"><b>Sending messages</b> | <a href="/shop/">Shop</a></div>';

$price = mysql_fetch_assoc(mysql_query("SELECT `price` FROM `shop` WHERE `id` = 10"));
$a = $price['price'];

$flood = functions::antiflood();
if ($flood) {
echo functions::display_error($lng['error_flood'] . ' ' . $flood . '&#160;' . $lng['seconds'], '<a href="/shop/index.php">' . $lng['back'] . '</a>');
require_once('../incfiles/end.php');
exit;
}

if (isset($_POST['submit'])) {
    if (isset($ban['1']) || isset($ban['3'])) {
    require_once('../incfiles/end.php');
    exit;
    }

    $kod = isset($_POST['kod']) ? trim($_POST['kod']) : '';
   $name = isset($_POST['usr']) ? functions::check($_POST['usr']) : '';
    $text = isset($_POST['msg']) ? functions::check($_POST['msg']) : '';
   $tema = isset($_POST['tema']) ? functions::check(mb_substr($_POST['tema'], 0, 50)) : '';
    $error = false;

    // CAPTCHA
    if (empty($kod) || mb_strlen($kod) < 4)
        $error = $error . 'You have not entered the verification code!<br />';
    elseif ($kod != $_SESSION['code'])
        $error = $error . 'Verification code is incorrect!<br />';
    unset($_SESSION['code']);

    if (empty($name))
        $error = $error . 'Not entered nickname or ID of the recipient!<br />';
   if (empty($tema))
        $error = $error . 'Do not put drugs topic!<br />';
    if (empty($text))
        $error = $error . 'Text is not entered anonymous PM!<br />';

    if (empty($error)) {
?        if ($datauser['balans'] < $a) {
        $error = 'Not enough coins to send anonymous
messages!<br/>';
        }
    }

        if (is_numeric($name) != false) {
        $req = mysql_query("select * from `users` where `id`='$name'");
        if (mysql_num_rows($req) == 0) {
        $error = 'No such nick!<br/>';
        }
        $fusr = $name;
        } else {
        $req = mysql_query("select * from `users` where `name`='$name'");
        if (mysql_num_rows($req) == 0) {
        $error = 'No such nick!<br/>';
        }
        $uid = mysql_fetch_assoc(mysql_query("SELECT `id` FROM `users` WHERE `name`='$name'"));
        $fusr = $uid['id'];
        }

    if (empty($error)) {

        mysql_query("UPDATE `users` SET `balans` = '" . ($datauser['balans'] - $a) . "', `lastpost` = '" . time() . "' WHERE `id` = '$user_id'");
        mysql_query("INSERT INTO `cms_mail` SET `user_id` = '0',`from_id` = '" . $fusr . "',`text` = '" . $text . "

[b]Message sent through the shop site!
Answer him not need!!![/b]',`time` = '" . time() . "',`sys` = '1',`them` = '" . $tema . "'");
        echo '<div class="gmenu">Reported anonymously sent!';
        echo '<br/><a href="/shop/">In Store</a>';
        echo '</div>';
    } else {
        echo '<div class="rmenu"><p><b>ERROR!</b><br />' . $error . '</p></div>';
    }

} else {

    echo '<div class="list2"><b>'.$login.'</b>, Here you can send anonymous post has absolutely anyone!<br/>Cost: '.$a.' coins</div>';
    echo '<form action="/shop/index.php?act=amail" method="post"><div class="list1">';
    echo '<p><b>Nickname:</b><br/><input type="text" name="usr" maxlength="30" value="" /><br/><small>Enter a nickname or user ID you want to send a PM.</small></p>';
   echo '<p><b>Topic:</b><br/><input type="text" name="tema" maxlength="50" value="" /><br/><small>Enter the subject of anonymous private message.</small></p>';
    echo '<p><b>Text:</b><br/><textarea rows="' . $set_user['field_h'] . '" name="msg"></textarea><br/><small>Enter text anonymous PM. You can use smileys and BB code.</small></p></div>';
    echo '<div class="gmenu"><p><img src="/captcha.php?r=' . rand(1000, 9999) . '" alt="Verification code" border="1"/><br />';
    echo 'Captcha:<br/><input type="text" size="5" maxlength="5" name="kod"/></p></div>';
    echo '<div class="phdr"><input type="submit" name="submit" value="Submit"/></div></form>';
    }

?>