<?php

define('_IN_JOHNCMS', 1);

echo '<div class="phdr"><b>Change nick</b> | <a href="/shop/">Shop</a></div>';

$price = mysql_fetch_assoc(mysql_query("SELECT `price` FROM `shop` WHERE `id` = 2"));
$a = $price['price'];

if (isset($_POST['submit'])) {

    $kod = isset($_POST['kod']) ? trim($_POST['kod']) : '';
    $name = isset($_POST['name']) ? functions::check(mb_substr($_POST['name'], 0, 15)) : $datauser['name'];
    $error = false;

    if (empty($kod) || mb_strlen($kod) < 4)
        $error = $error . 'You have not entered the verification code!<br />';
    elseif ($kod != $_SESSION['code'])
        $error = $error . 'Verification code is incorrect!<br />';
    unset($_SESSION['code']);

    if (empty($error)) {

        if ($datauser['balans'] < $a) {
        $error = 'Not enough coins to change Nick!<br/>';
        }

        if (mb_strlen($name) < 2 || mb_strlen($name) > 15)
            $error = 'Invalid length nickname!';
        $lat_nick = functions::rus_lat(mb_strtolower($name));
        if (preg_match("/[^0-9a-z\-\@\*\(\)\?\!\~\_\=\[\]]+/", $lat_nick))
            $error = 'Invalid characters in their names!';
    }

    if (empty($error)) {
        mysql_query("UPDATE `users` SET `balans` = '" . ($datauser['balans'] - $a) . "', `name` = '" . mysql_real_escape_string($name) . "' WHERE `id` = '$user_id'");
        echo '<div class="gmenu">Username changed!';
        echo '<br/><a href="/shop/">To Shop</a>';
        echo '</div>';
    } else {
        echo '<div class="rmenu"><p><b>ERROR!</b><br />' . $error . '</p></div>';
    }

} else {

    echo '<div class="list2"><b>'.$login.'</b>, Sdes you can change a nickname.<br/><span style="color:red">IMPORTANT! Your nick will be changed throughout the site!<br/>In the current positions (on the forum, guestbook) and comments nickname will remain unchanged.<br/>In the posts and the comments written after the nick change - will be a new nickname.<br/><b>Authorize the site will need to nick, which was administered at registration!!!</b></span><br/>Cost: '.$a.' coins</div>';
    echo '<form action="/shop/index.php?act=nick" method="post"><div class="list1">';
    echo '<p><b>Nickname:</b><br/><input type="text" name="name" maxlength="50" value="'.$datauser['name'].'" /><br/><small>Enter your new nickname<br/>Minimum Length: 2 characters, Maximum length: 15 characters</small></p></div>';
    echo '<div class="gmenu"><p><img src="/captcha.php?r=' . rand(1000, 9999) . '" alt="" border="1"/><br />';
    echo 'Captcha:<br/><input type="text" size="5" maxlength="5" name="kod"/></p></div>';
    echo '<div class="phdr"><input type="submit" name="submit" value="Submit"/></div></form>';
    }

?>