<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');

echo '<div class="phdr"><b>Karma +</b> | <a href="/shop/">Shop</a></div>';

$price = mysql_fetch_assoc(mysql_query("SELECT `price` FROM `shop` WHERE `id` = 3"));
$a = $price['price'];

if (isset($_POST['submit'])) {

    $kod = isset($_POST['kod']) ? trim($_POST['kod']) : '';
    $error = false;

    if (empty($kod) || mb_strlen($kod) < 4)
        $error = $error . 'You have not entered the verification code!<br />';
    elseif ($kod != $_SESSION['code'])
        $error = $error . 'Verification code is incorrect!<br />';
    unset($_SESSION['code']);

    if (empty($error)) {

        if ($datauser['balans'] < $a) {
        $error = 'Not enough coins to increase karma!<br/>';
        }
    }

    if (empty($error)) {
        mysql_query("UPDATE `users` SET `balans` = '" . ($datauser['balans'] - $a) . "', `karma_plus` = '" . ($datauser['karma_plus'] + 5) . "' WHERE `id` = '$user_id'");
        mysql_query("INSERT INTO `karma_users` SET
                            `user_id` = '0',
                            `name` = 'Seller',
                            `karma_user` = '" . $user_id . "',
                            `points` = '5',
                            `type` = '1',
                            `time` = '" . time() . "',
                            `text` = 'Karma assessed using shop site!'
                        ");
        header('Location: index.php?act=karmap');
    } else {
        echo '<div class="rmenu"><p><b>ERROR!</b><br />' . $error . '</p></div>';
    }

} else {

    echo '<div class="list2"><b>'.$login.'</b>, Sdes you can add +5 to your karma.<br/>Cost: '.$a.' coins</div>';
    echo '<form action="/shop/index.php?act=karmap" method="post"><div class="list1">';
    echo '<p><b>Karma:</b><br/>'.($datauser['karma_plus'] - $datauser['karma_minus']).' (<span style="color:green">'.$datauser['karma_plus'].'</span> / <span style="color:red">'.$datauser['karma_minus'].'</span>)</p></div>';
    echo '<div class="gmenu"><p><img src="/captcha.php?r=' . rand(1000, 9999) . '" alt="" border="1"/><br />';
    echo 'Captcha:<br/><input type="text" size="5" maxlength="5" name="kod"/></p></div>';
    echo '<div class="phdr"><input type="submit" name="submit" value="Add +5"/></div></form>';
    }

?>