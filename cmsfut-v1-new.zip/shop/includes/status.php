<?php

define('_IN_JOHNCMS', 1);

echo '<div class="phdr"><b>Set Status</b> | <a href="/shop/">Shop</a></div>';

$price = mysql_fetch_assoc(mysql_query("SELECT `price` FROM `shop` WHERE `id` = 1"));
$a = $price['price'];

if (isset($_POST['submit'])) {

    $kod = isset($_POST['kod']) ? trim($_POST['kod']) : '';
    $text = isset($_POST['status']) ? functions::check(mb_substr($_POST['status'], 0, 50)) : '';
    $error = false;

    if (empty($kod) || mb_strlen($kod) < 4)
        $error = $error . 'You have not entered the verification code!<br />';
    elseif ($kod != $_SESSION['code'])
        $error = $error . 'Verification code is incorrect!<br />';
    unset($_SESSION['code']);

    if (empty($error)) {

        if ($datauser['balans'] < $a) {
        $error = 'Not enough coins to set status!<br/>';
        }
    }

    if (empty($error)) {
        mysql_query("UPDATE `users` SET `balans` = '" . ($datauser['balans'] - $a) . "', `status` = '" . mysql_real_escape_string($text) . "' WHERE `id` = '$user_id'");
        echo '<div class="gmenu">Status is set!';
        echo '<br/><a href="/shop/">To Shop</a>';
        echo '</div>';
    } else {
        echo '<div class="rmenu"><p><b>ERROR!</b><br />' . $error . '</p></div>';
    }

} else {

    echo '<div class="list2"><b>'.$login.'</b>, Sdes you can put yourself status.<br/>Cost: '.$a.' coins</div>';
    echo '<form action="/shop/index.php?act=status" method="post"><div class="list1">';
    echo '<p><b>Status:</b><br/><input type="text" name="status" maxlength="50" value="'.$datauser['status'].'" /><br/><small>Enter the text that you want the status currently set<br/>Maximum length: 50 characters</small></p></div>';
    echo '<div class="gmenu"><p><img src="/captcha.php?r=' . rand(1000, 9999) . '" alt="" border="1"/><br />';
    echo 'Captcha:<br/><input type="text" size="5" maxlength="5" name="kod"/></p></div>';
    echo '<div class="phdr"><input type="submit" name="submit" value="Submit"/></div></form>';
    }

?>