<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');

echo '<div class="phdr"><b>Karma -</b> | <a href="/shop/">Shop</a></div>';

$price = mysql_fetch_assoc(mysql_query("SELECT `price` FROM `shop` WHERE `id` = 4"));
$a = $price['price'];

switch ($mod) {
case 'del':

if ($datauser['balans'] < $a) {
echo '<div class="rmenu"><p><b>ERROR!</b><br />not enough coins to remove negative karma vote!</p></div>';
} else {
$req = mysql_query("SELECT * FROM `karma_users` WHERE `id` = '$id' AND `karma_user` = '" . $user_id . "'");
if (mysql_num_rows($req)) {
$res = mysql_fetch_assoc($req);
if (isset($_GET['yes'])) {

mysql_query("UPDATE `users` SET `balans` = '" . ($datauser['balans'] - $a) . "', `karma_minus` = '" . ($datauser['karma_minus'] - $res['points']) . "' WHERE `id` = '$user_id'");
mysql_query("DELETE FROM `karma_users` WHERE `id` = '$id'");
header('Location: index.php?act=karmam');
} else {
echo '<div class="gmenu"><p>Remove negative voice?<br/>' .
'<a href="index.php?act=karmam&amp;mod=del&amp;id=' . $id . '&amp;yes">Delete</a> | ' .
'<a href="index.php?act=karmam">Back</a></p></div>';
}
  } else {
echo '<div class="rmenu"><p><b>ERROR!</b><br />you act dishonestly!</p></div>';
  }
      }
break;

default:
echo '<div class="list1"><b>'.$login.'</b>, Sdes you can remove the negative votes of his karma.<br/>To uninstall, click hrestik near voice.<br/> Cost of removing one voice: '.$a.' coins</div><div class="gmenu">';
echo '<p><b>Karma:</b><br/>'.($datauser['karma_plus'] - $datauser['karma_minus']).' (<span style="color:green">'.$datauser['karma_plus'].'</span> / <span style="color:red">'.$datauser['karma_minus'].'</span>)</p></div>';
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `karma_users` WHERE `karma_user` = '" . $user_id . "' AND `type` = '0'"), 0);
if ($total) {
$req = mysql_query("SELECT * FROM `karma_users` WHERE `karma_user` = '" . $user_id . "' AND `type` = '0' ORDER BY `time` DESC LIMIT $start, $kmess");
while ($res = mysql_fetch_assoc($req)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<span style="color:red">-' . $res['points'] . '</span> ';
echo $user_id == $res['user_id'] || !$res['user_id'] ? '<b>' . $res['name'] . '</b>' : '<a href="profile.php?user=' . $res['user_id'] . '"><b>' . $res['name'] . '</b></a>';
echo ' <span style="color:gray">(' . functions::display_date($res['time']) . ')</span>';
echo ' <span style="color:red"><a href="index.php?act=karmam&amp;mod=del&amp;id=' . $res['id'] . '">[X]</a></span>';

if (!empty($res['text']))
echo '<br />' . functions::smileys(functions::checkout($res['text']));
echo '</div>';
++$i;
}
} else {
echo '<div class="rmenu"><p>No negative votes!</p></div>';
}
echo '<div class="phdr">' . $lng['total'] . ': ' . $total . '</div>';
if ($total > $kmess) {
echo '<div class="topmenu">' . functions::display_pagination('index.php?act=karmam&amp;', $start, $total, $kmess) . '</div>';
}
   }

?>