<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');$headmod = 'BYURL';
$headmodurl = $home."/dashboard/friend_updates.php";

require('../incfiles/blog.func.php');
if (!$user_id) {
    header('Location: '.$set['homeurl'].'/login.php');
    exit;
}
$textl = $lng['teman'];
if (strpos($datauser['friends'],"><") === false) {
require('../incfiles/head.php');echo functions::display_error('Maaf, Teman Anda kurang dari 2.');
require('../incfiles/end.php');exit;
}
require('../incfiles/head.php');echo '<div class="phdr"><b>' . $lng['teman'] . '</b></div>';
$total = $blog_notif;
if ($total == 0) {
echo '<div class="menu"><p>' . $lng['teman_notif'] . '</p></div>';
}
else {
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('friend_updates.php?', $start, $total, $kmess).'</div>';
$que = mysql_query("SELECT `id`,`site_id`,`user_id`,`title`,`permalink`,`friend_views`,`time` FROM `blog_posts` WHERE `user_id` IN(".implode(",",$userfriends).") AND `friend_views` NOT LIKE '%<".$user_id.">%' AND `draft`='no' AND `time` > '".$timeviews."' ORDER BY `time` DESC LIMIT $start,$kmess");
$num = 1;
echo '<div class="menu"><form method="post" action="friend_updates.php?page='.$page.'">';
while($fup = mysql_fetch_array($que)) {
$idp = md5($fup['id']);
$blog = mysql_fetch_array(mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".$fup['site_id']."'"));
$upost = mysql_fetch_array(mysql_query("SELECT `name` FROM `users` WHERE `id`='".$fup['user_id']."'"));
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="'.$set['homeurl'].'/login.php?r='.functions::blog_link($blog['url1']).'/'.$fup['permalink'].'.html"><input type="checkbox" name="'.$idp.'" value="'.$fup['id'].'"> '.htmlspecialchars($fup['title']." | ".$blog['title']).'</a><div class="sub"><div>' . $lng['penulis'] . ': <a href="../users/profile.php?user='.$fup['user_id'].'">'.htmlspecialchars($upost['name']).'</a></div><div>' . $lng['waktu'] . ': '.functions::display_date($fup['time']).'</div>';
if(isset($_POST[$idp]) AND $_POST[$idp] == $fup['id']) { mysql_query("UPDATE `blog_posts` SET `friend_views`='<".$user_id.">".$fup['friend_views']."' WHERE `id`='".$fup['id']."'");
echo '<div class="gray">' . $lng['tandai_sudah_dibaca'] . '</div>';
}
echo '</div></div>';
++$i;
$num++;
}
echo '<p><input type="submit" value="' . $lng['tandai'] . '"/></p></form></div>';
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('friend_updates.php?', $start, $total, $kmess).'</div>';
}
require('../incfiles/end.php');