<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

define('_IN_JOHNCMS', 1);
$headmod = "panelblog";

require('../incfiles/core.php');
require('../incfiles/blog.func.php');
if (!$user_id) {
    header('Location: ../index.php');
    exit;
}

$array = array(
'ads',
'comments',
'create_category',
'domain_parking',
'create_navigation',
'create_blog',
'verifikasi',
'edit_blog',
'edit_category',
'chat',
'edit_navigation',
'edit_post',
'my_blog',
'manage_categories',
'manage_comments',
'manage_navigations',
'manage_posts',
'template',
'upload_post',
'write_post',
'import_rss',
'preview',
'overview'
);
if ($act && ($key = array_search($act, $array)) !== false && file_exists('includes/' . $array[$key] . '.php')) {
    require('includes/' . $array[$key] . '.php');
} else {require('includes/index.php');
}
