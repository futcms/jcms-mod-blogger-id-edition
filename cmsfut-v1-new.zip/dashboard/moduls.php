<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
if (!$user_id) {
    header('Location: ../index.php');
    exit;
}
$textl = $lng['modul'];
require('../incfiles/head.php');
echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</b></a> | ' . $lng['modul'] . '</div>';
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
if (mysql_num_rows($myb) == 0) {
echo functions::display_error("Anda belum memiliki blog.");
require('../incfiles/end.php');
exit;
}
if(!file_exists("../files/cache/blogmoduls.dat")) {
echo functions::display_error("Modul kosong.");
require("../incfiles/end.php");
exit;
 }
$handle = fopen("../files/cache/blogmoduls.dat","r");
$body = fread($handle,filesize("../files/cache/blogmoduls.dat"));
fclose($handle);
$modul = explode("^",$body."^");
$total = count($modul);
for ($m = 0; $m < $total; $m++) {
$sub = explode("~",$modul[$m]);
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<a href="moduls.php?id='.($m + 1).'"><h3>'.htmlspecialchars($sub[1]).'</h3></a>';
if ($id AND $id == ($m + 1)) { echo '<div class="gray">'.functions::checkout($sub[2], 1, 1).'</div>';
}
echo '</div>';
$i++;
}
require("../incfiles/end.php");
?>