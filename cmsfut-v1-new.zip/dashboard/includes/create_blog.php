<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');


if ($set['blogdomain'] == "") {
$textl = $lng['buatblog'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['buatblog'] . '</div>';
echo functions::display_error("Saat ini belum tersedia.");
require('../incfiles/end.php');
exit;
}
if (strpos($set['blogdomain'],",") === false)
$sitedomain = $set['blogdomain'];
else
$sitedomain = explode(",",$set['blogdomain']);

$bc = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_sites` WHERE `user_id`='".$user_id."'"),0);
if ($bc >= $set['blogmax']) {
$textl = $lng['buatblog'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['buatblog'] . '</div>';
echo functions::display_error("Anda sudah tidak bisa lagi membuat blog baru. Maksimal blog per user adalah ".$set['blogmax']." blog.");
require('../incfiles/end.php');
exit;
}
$subdomain = isset($_POST['subdomain']) ? strtolower($_POST['subdomain']) : '';
$subdomain = preg_replace('#([\W_]+)#',' ',$subdomain);
$subdomain = str_replace(' ','-',$subdomain);
$domain = isset($_POST['domain']) ? strtolower($_POST['domain']) : '';
$ttl = isset($_POST['title']) ? $_POST['title'] : '';
$dcs = isset($_POST['description']) ? $_POST['description'] : '';
if (isset($_POST['create'])) {
$error = array();
$dur = time() - (05);
$dreq = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."' AND `time` > '".$dur."'");
if (mysql_num_rows($dreq) != 0)
$error[] = 'Kamu dapat membuat blog baru 1x48 jam.';
if (substr($subdomain,0,1) == "-" OR substr($subdomain,-1) == "-")
$error[] = "Subdomain harus diawali dan diakhiri huruf atau angka.";
$dof = explode(",",$set['blogsubdomaindisallow']);
if(in_array($subdomain,$dof) || is_dir("../".$subdomain))
$error[] = "Subdomain tidak diijinkan.";
if (is_array($sitedomain)) {
if (!in_array($domain,$sitedomain))
$error[] = "Domain tidak benar.";
}
else {
if ($domain != $sitedomain)
$error[] = "Domain tidak benar.";
}
$url1 = 'http://'.$subdomain.'.'.$domain;
$url2 = 'http://www.'.$subdomain.'.'.$domain;
$tb = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_sites` WHERE `url1`='".mysql_real_escape_string($url1)."' OR `url1`='".mysql_real_escape_string($url2)."' OR `url2`='".mysql_real_escape_string($url1)."' OR `url2`='".mysql_real_escape_string($url2)."'"),0);
if ($tb != 0)
$error[] = 'Alamat blog '.$url1.' sudah terdaftar. (<a href="'.$set['homeurl'].'/pages/whois.php?domain='.$subdomain.'.'.$domain.'">WHOIS</a>)';
if (mb_strlen($subdomain) < 4 OR mb_strlen($subdomain) > 30)
$error[] = "Subdomain minimal 4 dan maksimal 30 karakter.";
if (mb_strlen($ttl) < 2 OR mb_strlen($ttl) > 30)
$error[] = "Judul minimal 2 dan maksimal 30 karakter.";
if (mb_strlen($dcs) < 2 OR mb_strlen($dcs) > 200)
$error[] = "Deskripsi minimal 2 dan maksimal 100 karakter";
if (empty($error)) {
$dcs = strip_tags(rep_text($dcs));
$dcs = $dcs."^".$set['homeurl']."/favicon.ico^^".$set['homeurl']."/images/logo.gif^^no^no^no";
mysql_query("INSERT INTO `blog_sites` SET `user_id`='".$user_id."', `title` = '".mysql_real_escape_string(strip_tags(rep_text($ttl)))."', `url1`='".mysql_real_escape_string($url1)."', `url2`='".mysql_real_escape_string($url2)."', `settings` = '".mysql_real_escape_string($dcs)."', `time`='".time()."'");
$bid = mysql_insert_id();
mysql_query("INSERT INTO `blog_categories` SET `site_id`='".$bid."', `user_id`='".$user_id."', `name`='Uncategories', `permalink`='uncategories'");
mysql_query("UPDATE `users` SET `www`='".mysql_real_escape_string(functions::blog_link($url1))."' WHERE `id`='".$user_id."'");
header("location: index.php?act=my_blog");
exit;
}
else {
$result = functions::display_error($error);
}
}
$textl = $lng['buatblog'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['buatblog'] . '</div>';
if ($result)
echo $result;
echo'<div class="menu"><form method="post" action="index.php?act=create_blog"><p><h3>Subdomain / Username</h3><input type="text" name="subdomain" value="'.htmlspecialchars($subdomain).'"/><br /><h3>Domain</h3><select name="domain">';
if (is_array($sitedomain)) {
foreach($sitedomain as $domainsite) {
echo '<option value="'.$domainsite.'">'.$domainsite.'</option>';
}
}
else {
echo '<option value="'.$sitedomain.'">'.$sitedomain.'</option>';
}
echo '</select><br /><h3>' . $lng['judul'] . '</h3><input type="text" name="title" value="'.htmlspecialchars($ttl).'"/><br /><h3>' . $lng['desk'] . '</h3><textarea rows="' . $set_user['field_h'] . '" name="description">'.htmlspecialchars($dcs).'</textarea>
</p><p><input type="submit" name="create" value="' . $lng['buat'] . '"/></p></form></div>';
require('../incfiles/end.php');
