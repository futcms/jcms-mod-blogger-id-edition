<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');
if (isset($_GET['blog_id'])) {
$blog_id = trim($_GET['blog_id']);
$bl = mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."'");
if(mysql_num_rows($bl)==0) {
header("location: index.php");
exit;
}
$rss=$_POST['rss'];
$auto=$_POST['auto'];
$new_time=$_POST['new_time'];
$kategori=$_POST['kategori'];
$sumber=$_POST['sumber'];
if (isset($_POST['import']))
{
$rss=str_replace('http://','',$rss);
if (empty($rss))
$error='Silakan masukan URL RSS Feed';
if (empty($error))
{
$rss='http://'.$rss.'';
$hasil='<div class="gmenu">Import RSS '.$rss.'</div>';
}
else
{
$hasil='<div class="rmenu">'.$error.'</div>';
}
}
$textl='Import RSS';
include '../incfiles/head.php';
echo '<div class="phdr">';
if (!empty($hasil))
echo $hasil;
echo '<b>Import RSS</b> | <a href="index.php?act=list_rss&amp;action=list">List Auto Import</a></div>';
echo '<div class="list2">Di sini Anda bisa mengimport postingan pada blog lain dengan cara menyalin RSS pada blog tersebut, ada pun penuh atau tidaknya postingan atau deskripsi tergantung pada RSS yang diimport. Kalau di RSS tersebut isi deskripsi tidak penuh maka RSS Import pun menyalin isi deskripsinya tidak penuh, sebaliknya jika isi deskripsi pada Feed RSS penuh maka RSS Import akan menyalin semua isi deskripsi tersebut.<br/><b>Spesifikasi Penyalinan</b><br/><ol><li>Feed harus berjenis RSS, Jika Feed Atom atau lainnya maka RSS Import tidak dapat menyalin isinya.</li></ol><br/><b>Contoh Feed RSS</b><br/><ol><li>Blogspot: http://mafut.pw.blogspot.com/feeds/posts/default?alt=rss</li><li>IndoWapBlog: http://mafut.pw/rss.xml</li><li>MyWapBlog: http://mafut.yu.tl/rss.xml</li></ol><br/>Anda dapat menyalin isi RSS secara otomatis. Jika pada RSS tersebut ada posting terbaru maka akan disalin dan dipublikasikan pada blog anda.</p></div>';

echo '<form method="post" action="index.php?act=import_rss&amp;blog_id='.$blog_id.'">

<div class="phdr">RSS Feed</div>';

echo '<input name="rss" type="text" value="http://'.str_replace('http://','',$rss).'" size="30"/>';

echo '<div class="phdr">Kategori</div>';
$kat = mysql_query("SELECT * FROM `blog_categories` WHERE `site_id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."' ORDER BY `name` ASC LIMIT $start,$kmess");
while ($kategoris=mysql_fetch_array($kat))
{

echo '<input type="radio" name="kategori" value="'.$kategoris['id'].'"';
if ($kategoris['id'] == '1')
echo 'checked';
echo '<div class="menu">'.$kategoris['name'].'</div>';
}

echo '<div class="phdr">Perbarui Tanggal</div>';
echo '<input type="radio" name="new_time" value="1"/>Ya<br/><input type="radio" name="new_time" value="0" checked/>Tidak</br>';

echo '<div class="phdr">Auto Import</div>';
echo '<input type="radio" name="auto" value="1"/>Ya<br/><input type="radio" name="auto" value="0" checked/>Tidak</br>';

echo '<div class="phdr">Tampilkan link sumber</div>';

echo '<input type="radio" name="sumber" value="1"/>Ya<br/><input type="radio" name="sumber" value="0" checked/>Tidak</br>';

echo '<input name="import" type="submit" value="Import"/></form></div>';

if (isset($_POST['import']) && empty($error))
{
echo '<ol>';

$feed=$rss;
$howmany='5';

$uag = $_SERVER['HTTP_USER_AGENT'];

ini_set('user_agent',$uag."\r\naccept: text/html, application/xml;q=0.9, application/xhtml+xml, image/png, image/jpeg, image/gif, image/x-xbitmap, */*;q=0.1\r\naccept_charset: $_SERVER[HTTP_ACCEPT_CHARSET]\r\naccept_language: $_SERVER[HTTP_ACCEPT_LANGUAGE]");

$xml = simplexml_load_file($feed);
if ($xml)
{
foreach ($xml->channel->item as $item)
{
if (!$count)
$count='1';
else
$count=$count+1;

if ($count>$howmany)
$howmany=$count;
if ($count<=$howmany)
{
$title = $item->title;
if ($title)
{
$title = $item->title;
$link=htmlspecialchars($item->link);
$tgl = strtotime($item->pubDate);
$deskrip = $item->description;
if ($sumber == 1)
$desc=''.$deskrip.'<br/>Sumber: <a href="'.$link.'">'.$link.'</a>';
else
$desc=$deskrip;
if ($new_time == 1)
$tanggal=time();
else
$tanggal=$tgl;
echo $i % 2 ? '<li class="list1">' : '<li class="list2">';
echo '<a href="'.$link.'">'.htmlspecialchars($title).'</a> <small>('.time_ago($tanggal).')</small><br/>';

echo html_entity_decode(htmlentities($desc));
$cek=mysql_query("select * from import_rss where url_post='".mysql_real_escape_string($link)."'") or die(mysql_error());
if (mysql_num_rows($cek) == 0)
{
$permalink=permalink($title);
mysql_query("insert into `blog_posts` set `id`='".mysql_real_escape_string($blog_id)."', `user_id`='".$user_id."', `title`='".mysql_real_escape_string($title)."', `description`='".mysql_real_escape_string($desc)."', `permalink`='".mysql_real_escape_string($permalink)."', `time`='".$tanggal."', `category`='".$kategori."', `draft`='no'") or die(mysql_error());
$blog_id=mysql_insert_id();
$kf=mysql_fetch_array(mysql_query("select * from blog_categories where id='".$kategoris['id']."'"));
if (empty($kf['site_id']))
$o=$blog_id;
else
$o=''.$blog_id.','.$kf['site_id'].'';
mysql_query("update blog_categories set site_id='".$o."' where id='".$kategori."'");

mysql_query("insert into `import_rss` set `url_post`='".mysql_real_escape_string($link)."', `time`='".time()."'") or die(mysql_error());
}
++$i;
echo '</li>';
}
}
}
if ($auto == 1)
{
$cek_r=mysql_query("select * from import_rss where url_rss='".$feed."'");
if (mysql_num_rows($cek_r) == 0)
{
mysql_query("insert into import_rss set url_rss='".$feed."', update_time='".$new_time."', category='".$kategori."', sumber='".$sumber."', time='".time()."'");
echo '<div class="gmenu">'.$feed.' berhasil ditambahkan ke auto Import.</div>';
}
else
{
echo '<div class="rmenu">'.$feed.' sebelumnya telah ditambahkan ke auto Import.</div>';
}
}
}
else
{
echo '<div class="rmenu">Tidak bisa menampilkan data RSS dari '.$feed.'. Pastikan '.$feed.' adalah Feed berjenis RSS dan minimal terdapat 1 posting (item).</div>';
}
echo '</ol>';
}
echo '</div>';
include '../incfiles/end.php';
}
else {
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$bc = mysql_num_rows($myb);
if ($bc == 0) {
header('location: index.php');
exit;
}

$textl = "Import Rss";
require('../incfiles/head.php');

echo '<div class="phdr"><a href="index.php">' . $lng['dasbor'] . '</a> | <b>Import RSS</b></div>';

echo '<div class="menu"><form method="get" action="index.php"><p><input type="hidden" name="act" value="import_rss"><b>Subdomain</b><br/><select name="blog_id">';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}

echo '</select></p><p><input type="submit" value="Lanjutkan"/></p></form></div>';
require('../incfiles/end.php');
}