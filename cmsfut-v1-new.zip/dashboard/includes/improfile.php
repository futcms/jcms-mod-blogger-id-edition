<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($user_id) {
 $lng_profile = core::load_lng('profile');

 $arg = array(
 'iphist' => 0,
 'iphide' => 0,
 );
echo '<div class="user"><a href="/users/profile.php?user=' . $user_id . '">' . functions::display_user($datauser,$arg) . '</a> &#160;<a href="' . $set['homeurl'] . '/users/profile.php?act=office"><button class="phdr">' . $lng['profile'] . '</button></a>&#160; <a href="' . $set['homeurl'] . '/dashboard/index.php?act=write_post"><button class="phdr">' . $lng['menulis_posting'] . '</button></a>&#160; <a href="' . $set['homeurl'] . '/dashboard/index.php?act=my_blog"><button class="phdr">' . $lng['mafut21'] . '</button></a>&#160; <a href="' . $set['homeurl'] . '/exit.php"><button class="phdr">' . $lng['exit'] . '</button></a></div>';
}
?>