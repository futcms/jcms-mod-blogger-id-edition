<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');
function import_rss()
{
$total_rss=mysql_query("select * from `import_rss` where `url_rss`!=''");
if (mysql_num_rows($total_rss) != 0)
{
$flw=mysql_fetch_array(mysql_query("select * from `import_rss` where `url_rss`!='' order by Rand() limit 1;"));
$feed=$flw['url_rss'];
$howmany='5';
$uag = $_SERVER['HTTP_USER_AGENT'];

ini_set('user_agent',$uag."\r\naccept: text/html, application/xml;q=0.9, application/xhtml+xml, image/png, image/jpeg, image/gif, image/x-xbitmap, */*;q=0.1\r\naccept_charset: $_SERVER[HTTP_ACCEPT_CHARSET]\r\naccept_language: $_SERVER[HTTP_ACCEPT_LANGUAGE]");

$xml = simplexml_load_file($feed);
if ($xml)
{
foreach ($xml->channel->item as $item)
{
if (!$count)
$count='1';
else
$count=$count+1;
if ($count>$howmany)
$howmany=$count;

if ($count<=$howmany)
{
$title = $item->title;
if ($title)
{
$judul = $item->title;
$link = $item->link;
$tggl = $item->pubDate;
$tggl=strtotime($tggl);
$tek = $item->description;
if ($flw['sumber'] == 1)
$teks=''.$tek.'<br />Sumber: <a href="'.$link.'">'.$link.'</a>';
else
$teks=$tek;

$cek=mysql_query("select * from import_rss where url_post='".mysql_real_escape_string($link)."'");
if (mysql_num_rows($cek) == 0)
{
if ($flw['update_time'] == 1)
$tgl=time();
else
$tgl=$tggl;
$permalink=permalink($judul);
mysql_query("insert into `blog_posts` set `user_id`='".$user_id."', `title`='".mysql_real_escape_string($judul)."', `description`='".mysql_real_escape_string($teks)."', `time`='".$tgl."', `category`='".$flw['category']."', `draft`='0'");
$site_id=mysql_insert_id();
$kf=mysql_fetch_array(mysql_query("select site_id from blog_categories where id='".$flw['category']."'"));
if (empty($kf['site_id']))
$o=$site_id;
else
$o=''.$site_id.','.$kf['site_id'].'';
mysql_query("update blog_categories set site_id='".$o."' where id='".$flw['category']."'");

mysql_query("insert into `import_rss` set `url_post`='".mysql_real_escape_string($link)."', `time`='".time()."'");
}}}}}}}
?>
