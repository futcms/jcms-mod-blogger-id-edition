<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');

function permalink($var)
{
$var = preg_replace('#([\W_]+)#',' ',$var);
$var = str_replace(' ','-',$var);
$var = strtolower($var);
return $var;
}

if (isset($_GET['category_id'])) {
$category_id = mysql_real_escape_string(trim($_GET['category_id']));
$cat_que = mysql_query("SELECT * FROM `blog_categories` WHERE `id`='".$category_id."' AND `user_id` = '".$user_id."'");
if (mysql_num_rows($cat_que) == 0) {
$textl = $lng['edit_kat'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['edit_kat'] . '</div>';
echo functions::display_error('Kategori yang dipilih tidak benar.','<a href="index.php">'.$lng['back'].'</a>');
require('../incfiles/end.php');exit;
}
$category = mysql_fetch_array($cat_que);
switch($mod) {
case 'delete':
if ($category['permalink'] == "uncategories") {
$textl = $lng['edit_kat'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['edit_kat'] . '</div>';
echo functions::display_error('Kategori ini tidak bisa dihapus.','<a href="index.php?act=manage_categories&amp;blog_id='.$category['site_id'].'">'.$lng['back'].'</a>');
require('../incfiles/end.php');exit;
}
if (!isset($_SESSION['key']))
$_SESSION['key'] = md5(time());
$submit = $_SESSION['key'];
if (isset($_POST[$submit])) {
mysql_query("UPDATE `blog_categories` SET `counts` = `counts` + ".$category['counts']." WHERE `site_id`='".$category['site_id']."' AND `permalink`='uncategories'");
mysql_query("UPDATE `blog_posts` SET `category` = 'uncategories' WHERE `site_id`='".$category['site_id']."' AND `category` = '".mysql_real_escape_string($category['permalink'])."'");
mysql_query("DELETE FROM `blog_categories` WHERE `id`='".$category['id']."'");
unset($_SESSION['key']);
header("Location: index.php?act=manage_categories&blog_id=".$category['site_id']);
exit;
}
$textl = $lng['hapus_kat'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['hapus_kat'] . '</div>';echo '<div class="menu"><form method="post" action="index.php?act=edit_category&amp;mod=delete&amp;category_id='.$category_id.'"><p>Anda yakin akan menghapus Kategori ini?</p><p><input type="submit" name="'.$submit.'" value="' . $lng['ya'] . '"/><input type="submit" name="no" value="' . $lng['tidak'] . '" onclick="javascript:window.history.back()"/></p></form></div>';
require('../incfiles/end.php');
break;
default:
$ttl = isset($_POST['title']) ? $_POST['title'] : rep_text($category['name'],true);


if (isset($_POST['submit'])) {
$permalink = permalink($ttl);
if (mb_strlen($ttl) < 2 OR mb_strlen($ttl) > 30)
$error = "Nama kategori harus 2 s/d 30 karakter.";

if ($category['permalink'] == "uncategories") {
$cc = mysql_query("SELECT * FROM `blog_categories` WHERE `site_id`='".mysql_real_escape_string($category['site_id'])."' AND `user_id`='".mysql_real_escape_string($user_id)."' AND `name`='".mysql_real_escape_string($ttl)."' AND `permalink`!='uncategories'");
if (mysql_num_rows($cc) != 0)
$error = "Nama kategori sudah ada.";
}
else {
$cc = mysql_query("SELECT * FROM `blog_categories` WHERE (`site_id`='".mysql_real_escape_string($category['site_id'])."' AND `user_id`='".mysql_real_escape_string($user_id)."') AND (`name`='".mysql_real_escape_string($ttl)."' OR `permalink`='".mysql_real_escape_string($permalink)."')");
if (mysql_num_rows($cc) != 0)
$error = "Nama kategori sudah ada.";
}
if (empty($error)) {
if($category['permalink'] == "uncategories") {
$new_permalink = $category['permalink'];
}
else {
$new_permalink = $permalink;
}
mysql_query("UPDATE `blog_categories` SET `name`='".mysql_real_escape_string(rep_text(strip_tags($ttl)))."', `permalink`='".mysql_real_escape_string($new_permalink)."' WHERE `id`='".mysql_real_escape_string($category['id'])."' AND `user_id`='".mysql_real_escape_string($user_id)."'");
header("location: index.php?act=manage_categories&blog_id=".$category['site_id']);
exit;
}
else {
$error = '<div class="rmenu"><span class="red">'.$error.'</span></div>';
}
}
$textl = $lng['edit_kat'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['edit_kat'] . '</div>';
if ($error)
echo $error;
echo'<div class="menu"><form method="post" action="index.php?act=edit_category&amp;category_id='.$category_id.'"><p><h3>' . $lng['nama_kat'] . '</h3><input type="text" name="title" value="'.htmlspecialchars($ttl).'"/></p><p><input type="submit" name="submit" value="' . $lng['simpan'] . '"/><input type="submit" name="cancel" value="' . $lng['cancel'] . '" onclick="javascript:window.history.back()"/></p></form></div>';require('../incfiles/end.php');
}
}
else {
header('location: index.php');
}
