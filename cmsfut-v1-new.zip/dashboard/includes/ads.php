<?php

defined('_IN_JOHNCMS') or die('Error');
if (isset($_GET['blog_id'])) {
$blogid = trim($_GET['blog_id']); 
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($blogid)."'");
while($blog=mysql_fetch_array($myb)) {
if (isset($_POST['save'])) {
$ads = isset($_POST['ads']) ? $_POST['ads'] : '';
$adcode = isset($_POST['adcode']) ? $_POST['adcode'] : '';
mysql_query("UPDATE `blog_sites` SET `ads` = '".mysql_real_escape_string($ads)."', `adcode`='".mysql_real_escape_string($adcode)."' WHERE `id`='".mysql_real_escape_string($blogid)."' AND `user_id`='".$user_id."'");
$textl = "Ads";
require('../incfiles/head.php');
echo '<div class="menu">Iklan '.$blog['ads'].' pada blog '.$blog['url1'].' dengan publisher code '.$blog['adcode'].' berhasil disimpan</div>';
require('../incfiles/end.php');
exit;
}
$textl = "Ads";
require('../incfiles/head.php');
echo'<div class="phdr"><b>Iklan</b></div>';
echo '<div class="list2">Anda saat ini menggunakan iklan '.$blog['ads'].' dengan publisher id '.$blog['adcode'].'<form method="post" action="index.php?act=ads&amp;blog_id='.$blog['id'].'<p><b>Publisher Code</b></br><input class="iwb-text" type="text" name="adcode" value="'.$blog['adcode'].'"/><br /><b>Ads Type</b><select name="ads"><option value="buzzcity" selected="selected">Buzzcity</option><option value="ucweb" selected="selected">Ucweb</option><br /></select></p><p><input type="submit" name="save" value="Simpan"/></p></form></div>';

require('../incfiles/end.php');
}
}
else {
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$bc = mysql_num_rows($myb);
if ($bc == 0) {
header('location: index.php');
exit;
}
$textl = "Ads";
require('../incfiles/head.php');echo '<div class="phdr">';
echo '<form method="get" action="index.php"><input type="hidden" name="act" value="ads"><b>Subdomain</b><br/><select name="blog_id">';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select><br/><input type="submit" value="Lanjutkan"/></form></div>';
require('../incfiles/end.php');
}
?>