<?php


/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');

// Membuat

echo '<div class="phdr">' . $lng['mafut14'] . '</div>';
echo '<div class="menu"><a href="index.php?act=write_post">' . $lng['menulis_posting'] . '</a></div>';
echo '<div class="menu"><a href="index.php?act=upload_post">' . $lng['mafut13'] . '</a></div>';
echo '<div class="menu"><a href="files.php">' . $lng['upload_files'] . '</a></div>';
echo '<div class="menu"><a href="index.php?act=create_category">' . $lng['buat'] . ' ' . $lng['mafut2'] . '</a></div>';

// Kelola

echo '<div class="phdr">' . $lng['mafut12'] . '</div>';
echo '<div class="menu"><a href="index.php?act=manage_posts">' . $lng['k_posting'] . '</a></div>';
echo '<div class="menu"><a href="files.php">' . $lng['my_files'] . '</a></div>';
echo '<div class="menu"><a href="index.php?act=manage_navigations">' . $lng['k_nav'] . '</a></div>';
echo '<div class="menu"><a href="index.php?act=manage_categories">' . $lng['k_kat'] . '</a></div>';
echo '<div class="menu"><a href="index.php?act=manage_comments">' . $lng['k_kom'] . '</a></div>';

// Tampilan

echo '<div class="phdr">' . $lng['mafut10'] . '</div>';
echo '<div class="menu"><a href="index.php?act=create_navigation">' . $lng['buat'] . ' ' . $lng['mafut3'] . '</a></div>';
//echo '<div class="menu"><a href="moduls.php">' . $lng['erik9'] . '</a></div>';
echo '<div class="menu"><a href="index.php?act=template">' . $lng['edit'] . ' ' . $lng['themes'] . '</a></div>';
echo '<div class="menu"><a href="/share-templates">Berbagi Templates</a> '.$total_templates.'</div>';

// Pengaturan

echo '<div class="phdr">' . $lng['settings'] . '</div>';
echo '<div class="menu"><a href="index.php?act=my_blog">' . $lng['mafut'] . '</a></div>';
echo '<div class="menu"><a href="index.php?act=domain_parking">' . $lng['mafut7'] . '</a></div>';
echo '<div class="menu"><a href="index.php?act=verifikasi">Google Verifikasi</a></div>';

// Komunitas

echo '<div class="phdr">' . $lng['community'] . '</div>';
echo '<div class="menu"><a href="/forum">' . $lng['forum'] . '</a></div>';
echo '<div class="menu"><a href="/chatbook">' . $lng['mafut4'] . '</a></div>';
echo '<div class="menu"><a href="/users/profile.php?act=info&user=1">' . $lng['mafut6'] . '</a></div>';
echo '<div class="menu"><a href="/pages/blog.php">' . $lng['mafut20'] . '</a></div>';
echo '<div class="menu">' . $lng['jangan_hapus'] . '</div>';
?>
