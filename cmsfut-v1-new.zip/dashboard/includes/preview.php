<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');

function SaveTags($var) {
if ($exp = explode(",",$var)) {
$count = count($exp) -1;
for ($i = 0; $i <= $count; $i++) {
$vars[] = strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$exp[$i])));
}
$var = implode(",",$vars);
}
else {
$var = strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$var)));
}
return $var;
}
$shift = ($set['timeshift'] + $set_user['timeshift']) * 3600;


if (isset($_GET['post_id'])) {
$post_id = mysql_real_escape_string(trim($_GET['post_id']));

if ($rights == 7 || $rights == 9) {
$cpost = mysql_query("SELECT * FROM `blog_posts` WHERE `id`='".$post_id."'");
}
else {
$cpost = mysql_query("SELECT * FROM `blog_posts` WHERE `id`='".$post_id."' AND `user_id`='".$user_id."'");
}
if (mysql_num_rows($cpost) == 0) {
require('../incfiles/head.php');
echo functions::display_error('Postingan yang dipilih tidak benar','<a href="index.php?act=manage_posts">'.$lng['back'].'</a>');
require('../incfiles/end.php');
exit;
}
$post = mysql_fetch_assoc($cpost);
$puser = mysql_fetch_array(mysql_query("SELECT `rights` FROM `users` WHERE `id`='".$post['user_id']."'"));
if ($post['user_id'] != $user_id && $rights <= $puser['rights']) {
require('../incfiles/head.php');
echo functions::display_error('Kamu tidak dapat memoderasi Postingan ini.');
require('../incfiles/end.php');
exit;
}
$blog = mysql_fetch_array(mysql_query("SELECT `id`,`url1` FROM `blog_sites` WHERE `id`='".$post['site_id']."'"));
switch($mod) {
case 'delete':
if (!isset($_SESSION['key']))
$_SESSION['key'] = md5(time());
$submit = $_SESSION['key'];
if (isset($_POST[$submit])) {
mysql_query("DELETE FROM `blog_posts` WHERE `id`='".$post['id']."'");
mysql_query("DELETE FROM `blog_comments` WHERE `post_id`='".$post['id']."'");
mysql_query("UPDATE `blog_categories` SET `counts` = `counts` - 1 WHERE `site_id`='".$post['site_id']."' AND `permalink`='".mysql_real_escape_string($post['category'])."'");
unset($_SESSION['key']);
header("Location: index.php");
exit;
}
$textl = "Hapus Posting";
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | Hapus Posting</div>';echo '<div class="menu"><form method="post" action="index.php?act=edit_post&amp;mod=delete&amp;post_id='.$post_id.'"><p>Anda yakin akan menghapus Postingan ini?</p><p><input type="submit" name="'.$submit.'" value="Ya"/><input type="submit" name="no" value="Tidak" onclick="javascript:window.history.back()"/></p></form></div>';
require('../incfiles/end.php');
break;

default:
$ttl = isset($_POST['title']) ? $_POST['title'] : rep_text($post['title'],true);
$dcs = isset($_POST['description']) ? $_POST['description'] : rep_text($post['description'],true);
$cat = isset($_POST['category']) ? $_POST['category'] : $post['category'];
$tags = isset($_POST['tags']) ? strtolower($_POST['tags']) : $post['tags'];
$privacy = isset($_POST['privacy']) ? $_POST['privacy'] : $post['privacy'];

if (isset($_POST['publish'])) {
$update = $_POST['updatetime'];
$tags = SaveTags($tags);
if ($privacy == "publics")
$privacy = "publics";
else
$privacy = "friends";
$hh = $_POST['hh'];
$bb = $_POST['bb'];
$tttt = $_POST['tttt'];
$jj = $_POST['jj'];
$mm = $_POST['mm'];
$ss = $_POST['ss'];
$curtime = $_POST['DefaultTime'];
$key = $_POST['key'];
$waktuku = $hh." ".$bb." ".$tttt." ".$jj.":".$mm.":".$ss;
$waktu = strtotime($waktuku);
$ed = explode("^",$post['edit']);
if ($update == "no" || $ed[1] >= 2) {
$edtim = $ed[1];
$waktu = $post['time'];
$draft = $post['draft'];
}
else {
$edtim = $ed[1] + 1;
if (strtotime($waktuku) < strtotime($curtime)) {
$waktu = time();
$draft = "no";
}
else {
$waktu = $waktu - $shift;
$draft = "yes";
}
}
$edps = $ed[0] + 1;
$edit = $edps."^".$edtim;
$cfg_form = true;
require("../incfiles/lib/htmlpurifier/purify.php");
$dcs = $purifier->purify($dcs);
if (empty($_SESSION['key']) OR $_SESSION['key'] != $key)
$error = "Session tidak benar.";
$bc = mysql_query("SELECT * FROM `blog_categories` WHERE `site_id`='".mysql_real_escape_string($post['site_id'])."' AND `user_id`='".$post['user_id']."' AND `permalink`='".mysql_real_escape_string($cat)."'");
if (mysql_num_rows($bc) == 0)
$error = "Kategori yang dipilih tidak benar.";
/*
$dflood = time() - 90;
$cflood = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `user_id`='".$post['user_id']."' AND `time` > '".$dflood."'"),0);
if ($cflood != 0)
$error = "Silakan tunggu beberapa saat lagi.";
*/
if (mb_strlen($ttl) < 2 OR mb_strlen($ttl) > 100)
$error = "Judul harus 2 s/d 100 karakter.";
if (mb_strlen($dcs) < 10)
$error = "Deskripsi minimal 10 karakter";
if (empty($error)) {

mysql_query("UPDATE `blog_posts` SET `title` = '".mysql_real_escape_string(rep_text(strip_tags($ttl)))."', `description` = '".mysql_real_escape_string(rep_text($dcs))."', `category` = '".mysql_real_escape_string($cat)."', `tags` = '".mysql_real_escape_string($tags)."', `privacy` = '".mysql_real_escape_string($privacy)."', `draft` = '".mysql_real_escape_string($draft)."', `edit` = '".mysql_real_escape_string($edit)."', `time` = '".mysql_real_escape_string($waktu)."' WHERE `id`='".$post['id']."' AND `user_id`='".$post['user_id']."'");
if ($cat != $post['category']) {
mysql_query("UPDATE `blog_categories` SET `counts` = `counts` - 1 WHERE `site_id`='".mysql_real_escape_string($post['site_id'])."' AND `user_id`='".$post['user_id']."' AND `permalink`='".mysql_real_escape_string($post['category'])."'");

mysql_query("UPDATE `blog_categories` SET `counts` = `counts` + 1 WHERE `site_id`='".mysql_real_escape_string($post['site_id'])."' AND `user_id`='".$post['user_id']."' AND `permalink`='".mysql_real_escape_string($cat)."'");
}
if ($post['user_id'] == $user_id)
header("location: index.php?act=manage_posts&blog_id=".$post['site_id']."&notice=".urlencode("Posting berhasil dipubikasikan."));
else
header("location: ".functions::blog_link($blog['url1'])."/".$post['permalink'].".html");
exit;
}
else {
$error = '<div class="rmenu"><span class="red">'.$error.'</span></div>';
}
}
$textl = "Preview Posting";
require('../incfiles/head.php');echo '<div class="phdr" align="center"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | Preview Posting<br/><a href="index.php?act=edit_post&amp;post_id='.$post_id.'">Edit Posting ini</a></div>';
if ($error)
echo $error;
echo'<div class="menu"><p><h3>Judul</h3><div class="post"><h2>'.htmlspecialchars($ttl).'</h2></div><br /><h3>Deskripsi</h3><br/>'.functions::smileys($dcs).'</div>';
require('../incfiles/end.php');
}
}
else {
header("location: index.php");
}