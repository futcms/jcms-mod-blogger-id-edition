<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');

if (isset($_GET['blog_id'])) {
$blog_id = trim($_GET['blog_id']);
$code = isset($_POST['code']) ? $_POST['code'] : '';
$cb = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."'");
if (mysql_num_rows($cb) == 0) {
header('location: index.php');
exit;
}
$blog = mysql_fetch_assoc($cb);
if (isset($_POST['submit'])) {
require("../incfiles/lib/htmlpurifier/navigation.php");
$code = $purifier->purify($code);
if (mb_strlen($code) < 2 OR mb_strlen($code) > 5000)
$error = "Kode minimal 2 dan maksimal 5000 karakter";
if (empty($error)) {
$code = str_replace("^","",rep_text($code));
if (empty($blog['navigations'])) {
$navcode = $code;
}
else {
$navcode = $code."^".$blog['navigations'];
}
mysql_query("UPDATE `blog_sites` SET `navigations`='".mysql_real_escape_string($navcode)."' WHERE `id`='".$blog['id']."'");
mysql_query("UPDATE `users` SET `lastpost` = '" . time() . "' WHERE `id` = '" . $user_id . "'");
header("location: index.php?act=manage_navigations&blog_id=".$blog_id."&notice=".urlencode("Navigasi berhasil dibuat."));
exit;
}
else {
$error = '<div class="rmenu"><span class="red">'.$error.'</span></div>';
}
}
$textl = $lng['navigasi'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['navigasi'] . '</div>';
if ($error)
echo $error;
echo'<div class="menu"><form method="post" action="index.php?act=create_navigation&amp;blog_id='.$blog_id.'"><p><h3>' . $lng['blog'] . '</h3><img src="../images/blogs.png" width="16" height="16" class="left" />&#160;<a href="'.functions::blog_link($blog['url1']).'/">'.htmlspecialchars($blog['title']).'</a><br /><h3>' . $lng['kode'] . '</h3><textarea rows="' . $set_user['field_h'] . '" name="code">'.htmlentities($code).'</textarea></p><p><input type="submit" name="submit" value="' . $lng['simpan'] . '"/></p></form></div>';
require('../incfiles/end.php');
}
else {
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$bc = mysql_num_rows($myb);
if ($bc == 0) {
header('location: index.php');
exit;
}

$textl = $lng['navigasi'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['navigasi'] . '</div>';
echo '<div class="menu"><form method="get" action="index.php"><p><input type="hidden" name="act" value="create_navigation"><h3>' . $lng['pilih_blog'] . '</h3><select name="blog_id">';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select></p><p><input type="submit" value="' . $lng['lanjutkan'] . '"/></p></form></div>';
require('../incfiles/end.php');
}
