<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');

if (isset($_GET['blog_id'])) {
$blog_id = mysql_real_escape_string(trim($_GET['blog_id']));
if($blog_id == "ALL") {
header("location: index.php?act=comments");
exit;
}
$bl = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='".$blog_id."' AND `user_id`='".$user_id."'");
if(mysql_num_rows($bl)==0) {
header("location: index.php");
exit;
}
$blog = mysql_fetch_array($bl);
$in = isset($_GET['in']) ? $_GET['in'] : 'post';
if ($in == "guestbook") {
$qu = "`post_id`='0'";
$in = "guestbook";
$ttl = "Kelola Buku tamu"; }
else {
$qu = "`post_id`!='0'";
$in = "post";
$ttl = "Kelola Komentar"; }
switch ($mod) {
case 'accepted':
$status = "accepted";
break;
case 'moderated':
$status = "moderated";
break;
case 'spam':
$status = "spam";
break;
default:
$status = "accepted";
break;
}
if (isset($_GET['comment_id'])) {
$cid = abs(intval(trim($_GET['comment_id'])));
$co_que = mysql_query("SELECT * FROM `blog_comments` WHERE `id`='".$cid."' AND `site_id`='".$blog['id']."' AND `user_id`='".$blog['user_id']."'");
if (mysql_num_rows($co_que) != 0) {
$co = mysql_fetch_array($co_que);
if ($co['status'] != "spam" AND $mod == "spam") {
mysql_query("UPDATE `blog_comments` SET `status`='spam' WHERE `id` = '".$co['id']."'");
if ($co['post_id'] != 0 AND $co['status'] == "accepted") { mysql_query("UPDATE `blog_posts` SET `comments` = `comments` - 1 WHERE `id`='".$co['post_id']."'"); }
$return = "Komentar berhasil dipindahkan.";
}
elseif ($co['status'] != "accepted" AND $mod == "accepted") {
mysql_query("UPDATE `blog_comments` SET `status`='accepted' WHERE `id` = '".$co['id']."'");
if ($co['post_id'] != 0) { mysql_query("UPDATE `blog_posts` SET `comments` = `comments` + 1 WHERE `id`='".$co['post_id']."'"); }
$return = "Komentar berhasil dipindahkan.";
}
elseif ($mod == "delete") {
mysql_query("DELETE FROM `blog_comments` WHERE `id` = '".$co['id']."'");
if ($co['post_id'] != 0 AND $co['status'] == "accepted") { mysql_query("UPDATE `blog_posts` SET `comments` = `comments` - 1 WHERE `id`='".$co['post_id']."'"); }
$return = "Komentar berhasil dihapus.";
}

}
else{
$return = "Komentar yang dipilih tidak benar.";
}
}

$textl = "Panel Blog | ".$ttl;
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</b></a> | ' . $lng['k_kom'] . '</div>';
if ($return)
echo '<div class="rmenu">'.$return.'</div>';
$query = mysql_query("(SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."' AND $qu AND `status` = 'accepted') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."' AND $qu AND `status` = 'moderated') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."' AND $qu AND `status` = 'spam')");
$taotal = array();
while($taotl=mysql_fetch_array($query)) { $taotal[] = $taotl[0]; }
$total_accepted = $taotal[0];
$total_moderated = $taotal[1];
$total_spam = $taotal[2];
echo'<div class="user"><h3><img src="../images/blogs.png" width="16" height="16" class="left" />&#160;<a href="'.functions::blog_link($blog['url1']).'">'.htmlspecialchars($blog['title']).'</a></h3></div><div class="phdr">'.((!$in OR $in == "post") ? 'Komentar' : '<a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;in=post">' . $lng['comments'] . '</a>').' | '.($in == "guestbook" ? $lng['guestbook'] : '<a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;in=guestbook">'.$lng['guestbook'].'</a>').'</div><div class="list2"><ul><li>'.((!$mod OR $mod == "accepted") ? 'Disetujui ('.$total_accepted.')' : '<a href="index.php?act=manage_comments&amp;blog_id='.$blog_id.'&amp;mod=accepted">' . $lng['disetujui'] . ' ('.$total_accepted.')</a>').'</li><li>'.($mod == "moderated" ? 'Dimoderasi ('.$total_moderated.')' : '<a href="index.php?act=manage_comments&amp;blog_id='.$blog_id.'&amp;mod=moderated">' . $lng['dimoderasi'] . ' ('.$total_moderated.')</a>').'</li><li>'.($mod == "spam" ? 'Spam ('.$total_spam.')' : '<a href="index.php?act=manage_comments&amp;blog_id='.$blog_id.'&amp;mod=spam">' . $lng['spam'] . ' ('.$total_spam.')</a>').'</li></ul></div>';
if ($mod == "moderated")
$total = $total_moderated;
elseif ($mod == "spam") $total = $total_spam; else $total = $total_accepted;
if($total==0) {
echo '<div class="menu"><p>'.$lng['list_empty'].'</p></div>';
} else {
$comments = mysql_query("SELECT * FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."' AND $qu AND `status` = '".$status."' ORDER BY `time` DESC LIMIT $start,$kmess");
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('index.php?act=manage_comments&amp;blog_id='.$blog_id.'&amp;in='.htmlentities($in).'&amp;mod='.$status.'&amp;', $start, $total, $kmess).'</div>';
while($comment=mysql_fetch_array($comments)){
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
if ($comment['author_id'] != 0)
echo '<a href="../users/profile.php?user='.$comment['author_id'].'"><img src="../users/avatar.php?user='.$comment['author_id'].'" alt=""/></a> ';
else
echo '<img src="../users/avatar.php?user='.$comment['author_id'].'" alt=""/>';
echo '<a href="'.htmlentities($comment['author_homepage']).'">'.htmlspecialchars($comment['author_name']).'</a> ';
if ($comment['adminread'] == 0) {
mysql_query("UPDATE `blog_comments` SET `adminread`='1' WHERE `id`='".$comment['id']."'");
echo '(<span class="red">'.functions::display_date($comment['time']).'</span>)';
}
else {
echo '('.functions::display_date($comment['time']).')';
}
if ($comment['quote'] == "") { echo '<br />'.nl2br($comment['text']).'<br />'; } else { $quot = explode("<!-- quote -->",$comment['quote']); echo '<fieldset><legend>'.$quot[0].'</legend><div>'.nl2br($quot[1]).'</div></fieldset><br />'.nl2br($comment['text']).'<br />';}
if ($comment['post_id'] == 0) {
echo 'Pada <a href="'.$set['homeurl'].'/login.php?r='.urlencode(functions::blog_link($blog['url1']).'/guestbook.html').'">' . $lng['guestbook'] . '</a>';
} else {
$post = mysql_fetch_array(mysql_query("SELECT `title`,`permalink` FROM `blog_posts` WHERE `id`='".$comment['post_id']."'"));
echo '' . $lng['pada_postingan'] . ' <a href="'.$set['homeurl'].'/login.php?r='.urlencode(functions::blog_link($blog['url1']).'/'.$post['permalink'].'.html').'">'.htmlspecialchars($post['title']).'</a>';
}
echo '<div class="sub">'.($comment['status'] == "accepted" ? '<a href="'.$set['homeurl'].'/login.php?r='.urlencode(functions::blog_link($blog['url1']).'/'.$post['permalink'].'.html?quote='.$comment['id']).'">' . $lng['balas'] . '</a> | <a href="index.php?act=manage_comments&amp;blog_id='.$blog_id.'&amp;mod=spam&amp;comment_id='.$comment['id'].'">' . $lng['spam'] . '</a>' : '<a href="index.php?act=manage_comments&amp;blog_id='.$blog_id.'&amp;mod=accepted&amp;comment_id='.$comment['id'].'">' . $lng['menyetujui'] . '</a>').' | <a href="index.php?act=manage_comments&amp;blog_id='.$blog_id.'&amp;mod=delete&amp;comment_id='.$comment['id'].'" onclick="return confirm(\'Anda yakin ingin menghapus komentar ini?\')"><span class="red">' . $lng['delete'] . '</span></a></div></div>';
++$i;
}
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('index.php?act=manage_comments&amp;blog_id='.$blog_id.'&amp;in='.htmlentities($in).'&amp;mod='.$status.'&amp;', $start, $total, $kmess).'</div>';
}
require('../incfiles/end.php');
}
else {
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$bc = mysql_num_rows($myb);
if ($bc == 0) {
header('location: index.php');
exit;
}

$textl = "Panel Blog | Kelola Komentar";
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['k_kom'] . '</div>';
echo '<div class="menu"><form method="get" action="index.php"><p><input type="hidden" name="act" value="manage_comments"><h3>' . $lng['pilih_blog'] . '</h3><select name="blog_id"><option value="ALL" selected="selected">' . $lng['all'] . '</option>';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select></p><p><input type="submit" value="' . $lng['lanjutkan'] . '"/></p></form></div>';
require('../incfiles/end.php');
}
