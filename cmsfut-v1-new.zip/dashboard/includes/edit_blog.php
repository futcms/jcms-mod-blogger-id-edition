<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');


if (isset($_GET['blog_id'])) {
$blog_id = mysql_real_escape_string($_GET['blog_id']);
if ($rights == 7 || $rights == 9) {
$bcheck = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='".$blog_id."'");
}
else {
$bcheck = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='".$blog_id."' AND `user_id`='".$user_id."'");
}
if (mysql_num_rows($bcheck) == 0) {
$textl = $lng['edit_blog'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['edit_blog'] . '</div>';
echo functions::display_error('Blog yang dipilih tidak benar.','<a href="index.php?act=edit_blog">'.$lng['back'].'</a>');
require('../incfiles/end.php');
exit;
}
$blog = mysql_fetch_array($bcheck);
$buser = mysql_fetch_array(mysql_query("SELECT `rights` FROM `users` WHERE `id`='".$blog['user_id']."'"));
if ($blog['user_id'] != $user_id && $rights <= $buser['rights']) {
require('../incfiles/head.php');
echo functions::display_error('Anda tidak mempunyai akses untuk mengelola ini.');
require('../incfiles/end.php');
exit;
}
if (strpos($set['blogdomain'],",") === false)
$sitedomain = $set['blogdomain'];
else
$sitedomain = explode(",",$set['blogdomain']);

switch($mod) {
case 'delete':
if (!isset($_SESSION['key']))
$_SESSION['key'] = md5(time());
$submit = $_SESSION['key'];
if (isset($_POST[$submit])) {
mysql_query("DELETE FROM `blog_posts` WHERE `site_id`='".$blog['id']."'");
mysql_query("DELETE FROM `blog_sites` WHERE `id`='".$blog['id']."'");
mysql_query("DELETE FROM `blog_comments` WHERE `site_id`='".$blog['id']."'");
mysql_query("DELETE FROM `blog_categories` WHERE `site_id`='".$blog['id']."'");
if (is_file("../files/templates/u".$blog['user_id']."-b".$blog['id']."-mobile.xml"))
unlink("../files/templates/u".$blog['user_id']."-b".$blog['id']."-mobile.xml");
if (is_file("../files/templates/u".$blog['user_id']."-b".$blog['id']."-desktop.xml"))
unlink("../files/templates/u".$blog['user_id']."-b".$blog['id']."-desktop.xml");
$files = glob("../files/blogs/u".$blog['user_id']."-b".$blog['id']."-*");
if ($files != false) { for($f = 0;$f<count($files);$f++) { unlink($files[$f]); }
}
unset($_SESSION['key']);
if($blog['user_id'] == $user_id)
header("Location: index.php");
else
header("Location: ../users/profile.php?user=".$blog['user_id']);
exit;
}
$textl = $lng['hapus_blog'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['hapus_blog'] . '</div>';
echo '<div class="menu"><h3><img src="../images/blogs.png" width="16" height="16" class="left" />&#160;<a href="'.functions::blog_link($blog['url1']).'">'.htmlspecialchars($blog['title']).'</a></h3><form method="post" action="index.php?act=edit_blog&amp;mod=delete&amp;blog_id='.$blog_id.'"><p>' . $lng['hapus_blog_notif'] . '</p><p><input type="submit" name="'.$submit.'" value="' . $lng['ya'] . '"/><input type="submit" name="no" value="' . $lng['tidak'] . '" onclick="javascript:window.history.back()"/></p></form></div>';
require('../incfiles/end.php');
break;

default:
if ($set['blogediturl'] == "yes") {
$buname = explode(".",str_replace("http://www.","",$blog['url2']),2);
$usname = $buname[0];
$usdom = $buname[1];
$subdomain = isset($_POST['subdomain']) ? strtolower($_POST['subdomain']) : $usname;
$subdomain = preg_replace('#([\W_]+)#',' ',$subdomain);
$subdomain = str_replace(' ','-',$subdomain);
$domain = isset($_POST['domain']) ? strtolower($_POST['domain']) : $usdom;
}
$bset = explode("^",$blog['settings']);
$ttl = isset($_POST['title']) ? $_POST['title'] : rep_text($blog['title'],true);
$dcs = isset($_POST['description']) ? str_replace("^"," ",$_POST['description']) : rep_text($bset[0],true);
$ico = isset($_POST['favicon']) ? str_replace("^"," ",$_POST['favicon']) : rep_text($bset[1],true);
$keywords = isset($_POST['keywords']) ? str_replace("^"," ",$_POST['keywords']) : rep_text($bset[2],true);
$logo = isset($_POST['logo']) ? str_replace("^"," ",$_POST['logo']) : rep_text($bset[3],true);
$category = isset($_POST['category']) ? $_POST['category'] : $blog['category'];
$metagoogle = isset($_POST['metagoogle']) ? str_replace("^"," ",$_POST['metagoogle']) : rep_text($bset[4],true);
$modcomment = isset($_POST['modcomment']) ? str_replace("^"," ",$_POST['modcomment']) : rep_text($bset[5],true);
$comcaptcha = isset($_POST['comcaptcha']) ? str_replace("^"," ",$_POST['comcaptcha']) : rep_text($bset[6],true);
$comemail = isset($_POST['comemail']) ? str_replace("^"," ",$_POST['comemail']) : rep_text($bset[7],true);
$perpage = isset($_POST['perpage']) ? $_POST['perpage'] : $bset[8];
if (isset($_POST['save'])) {
$error = array();
if ($set['blogediturl'] == "yes") {
$url1 = 'http://'.$subdomain.'.'.$domain;
$url2 = 'http://www.'.$subdomain.'.'.$domain;
if ($url2 == $blog['url2']) {
$url1 = $blog['url1'];
$url2 = $blog['url2'];
}
else {
if (substr($subdomain,0,1) == "-" OR substr($subdomain,-1) == "-")
$error[] = "Subdomain harus diawali dan diakhiri huruf atau angka.";
$dof = explode(",",$set['blogsubdomaindisallow']);
if(in_array($subdomain,$dof) || is_dir("../".$subdomain))
$error[] = "Subdomain tidak diijinkan.";
if (is_array($sitedomain)) {
if (!in_array($domain,$sitedomain))
$error[] = "Domain tidak benar.";
}
else {
if ($domain != $sitedomain)
$error[] = "Domain tidak benar.";
}
$tb = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_sites` WHERE `url1`='".mysql_real_escape_string($url1)."' OR `url1`='".mysql_real_escape_string($url2)."' OR `url2`='".mysql_real_escape_string($url1)."' OR `url2`='".mysql_real_escape_string($url2)."'"),0);
if ($tb != 0)
$error[] = 'Alamat blog '.$url1.' sudah terdaftar. (<a href="'.$set['homeurl'].'/pages/whois.php?domain='.$subdomain.'.'.$domain.'">WHOIS</a>)';
if (mb_strlen($subdomain) < 4 OR mb_strlen($subdomain) > 30)
$error[] = "Subdomain minimal 4 dan maksimal 30 karakter.";
}
}
else {
$url1 = $blog['url1'];
$url2 = $blog['url2'];
}
if (mb_strlen($ttl) < 2 OR mb_strlen($ttl) > 30)
$error[] = "Judul minimal 2 dan maksimal 30 karakter.";
if (mb_strlen($dcs) < 2 OR mb_strlen($dcs) > 200)
$error[] = "Deskripsi minimal 2 dan maksimal 100 karakter";
if (mb_strlen($ico) > 200)
$error[] = "Favicon maksimal 200 karakter";
if (mb_strlen($keywords) > 200)
$error[] = "Keywords maksimal 200 karakter";
if (mb_strlen($logo) > 200)
$error[] = "Logo maksimal 200 karakter";
if (mb_strlen($metagoogle) > 100)
$error[] = "Meta tag Google maksimal 100 karakter";
if (empty($error)) {
$dcs = strip_tags(rep_text($dcs));
$settings = $dcs."^".rep_text(strip_tags($ico))."^".rep_text(strip_tags($keywords))."^".rep_text(strip_tags($logo))."^".rep_text(strip_tags($metagoogle))."^".rep_text($modcomment)."^".rep_text($comcaptcha)."^".rep_text($comemail)."^".(ctype_digit($perpage) ? $perpage : 10);
$moduls = $rights >= 7 ? $_POST['moduls'] : $blog['moduls'];
mysql_query("UPDATE `blog_sites` SET `title` = '".mysql_real_escape_string(strip_tags(rep_text($ttl)))."', `url1`='".mysql_real_escape_string($url1)."', `url2`='".mysql_real_escape_string($url2)."', `settings` = '".mysql_real_escape_string(strip_tags($settings))."', `category` = '".mysql_real_escape_string(strip_tags($category))."', `moduls` = '".mysql_real_escape_string($moduls)."' WHERE `id`='".$blog_id."'");
if($user_id == $blog['user_id']) {
mysql_query("UPDATE `users` SET `www`='".mysql_real_escape_string(functions::blog_link($url1))."' WHERE `id`='".$blog['user_id']."'");
}
header("location: index.php?act=my_blog");
exit;
}
else {
$result = functions::display_error($error);
}
}
$textl = $lng['edit_blog'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['edit_blog'] . '</div>';
if ($result)
echo $result;
echo'<div class="menu"><h3><img src="../images/blogs.png" width="16" height="16" class="left" />&#160;<a href="'.functions::blog_link($blog['url1']).'">'.htmlspecialchars($blog['title']).'</a></h3><form method="post" action="index.php?act=edit_blog&amp;blog_id='.$blog_id.'"><p>';
if ($set['blogediturl'] == "yes") {
echo '<h3>Subdomain / Username</h3><input type="text" name="subdomain" value="'.htmlspecialchars($subdomain).'"/><br /><h3>Domain</h3><select name="domain">';
if (is_array($sitedomain)) {
foreach($sitedomain as $domainsite) {
echo '<option value="'.$domainsite.'"'.($usdom == $domainsite ? ' selected="selected"' : '').'>'.$domainsite.'</option>';
}
}
else {
echo '<option value="'.$sitedomain.'">'.$sitedomain.'</option>';
}
echo '</select><br />';
}
echo '<h3>' . $lng['judul'] . '</h3><input type="text" name="title" value="'.htmlspecialchars($ttl).'"/><br /><h3>' . $lng['kata_kunci'] . '</h3><input type="text" name="keywords" value="'.htmlspecialchars($keywords).'"/><br /><h3>' . $lng['desk'] . '</h3><textarea rows="' . $set_user['field_h'] . '" name="description">'.htmlspecialchars($dcs).'</textarea><br /><h3>' . $lng['icon'] . '</h3><input type="text" name="favicon" value="'.htmlspecialchars($ico).'"/><br />
<h3>' . $lng['logo'] . '</h3><input type="text" name="logo" value="'.htmlspecialchars($logo).'"/><br /><h3>' . $lng['kat'] . '</h3><select name="category">';
$blog_category = explode(",",$set['blogcat']);
for($c=0;$c<count($blog_category);$c++) {
$cat = strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$blog_category[$c])));
echo '<option value="'.$cat.'"'.($category == $cat ? ' selected="selected"' : '').'>'.htmlspecialchars($blog_category[$c]).'</option>';
}
echo '</select><br /><h3>Meta tag Google</h3><input type="text" name="metagoogle" value="'.htmlspecialchars($metagoogle).'"/><br />'.($rights >= 7 ? '<h3>' . $lng['modul'] . '</h3><input type="text" name="moduls" value="'.htmlspecialchars($blog['moduls']).'"/><br />' : '').'<h3>' . $lng['jumlah_posting'] . '</h3><select name="perpage" size="2">'; 
for ($i = 1; $i <= 20; $i++) {
echo '<option value="'.$i.'"'.($perpage == $i ? ' selected="selected"' : '').'>'.$i.' posting</option>'; }
echo '</select><br /><h3>' . $lng['moderasi_kom'] . '</h3><input type="radio" name="modcomment" value="yes"'.($modcomment == "yes" ? ' checked="checked"' : '').'>' . $lng['ya'] . ' <input type="radio" name="modcomment" value="no"'.($modcomment == "no" ? ' checked="checked"' : '').'>' . $lng['tidak'] . '<br /><h3>' . $lng['cap_kom'] . '</h3><input type="radio" name="comcaptcha" value="yes"'.($comcaptcha == "yes" ? ' checked="checked"' : '').'>' . $lng['ya'] . ' <input type="radio" name="comcaptcha" value="no"'.($comcaptcha == "no" ? ' checked="checked"' : '').'>' . $lng['tidak'] . '<br /><h3>' . $lng['email_kom'] . '</h3><input type="radio" name="comemail" value="yes"'.($comemail == "yes" ? ' checked="checked"' : '').'>' . $lng['ya'] . ' <input type="radio" name="comemail" value="no"'.($comemail == "no" ? ' checked="checked"' : '').'>' . $lng['tidak'] . '</p><p><input type="submit" name="save" value="' . $lng['simpan'] . '"/></p></form></div>';
require('../incfiles/end.php');
}
}
else {
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$bc = mysql_num_rows($myb);
if ($bc == 0) {
header('location: index.php');
exit;
}

$textl = $lng['edit_blog'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['edit_blog'] . '</div>';
echo '<div class="menu"><form method="get" action="index.php"><p><input type="hidden" name="act" value="edit_blog"><h3>' . $lng['pilih_blog'] . '</h3><select name="blog_id">';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select></p><p><input type="submit" value="' . $lng['lanjukan'] . '"/></p></form></div>';
require('../incfiles/end.php');
}