<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');

function SaveTags($var) {
if ($exp = explode(",",$var)) {
$count = count($exp) -1;
for ($i = 0; $i <= $count; $i++) {
$vars[] = strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$exp[$i])));
}
$var = implode(",",$vars);
}
else {
$var = strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$var)));
}
return $var;
}
$shift = ($set['timeshift'] + $set_user['timeshift']) * 3600;


if (isset($_GET['post_id'])) {
$post_id = mysql_real_escape_string(trim($_GET['post_id']));

if ($rights == 7 || $rights == 9) {
$cpost = mysql_query("SELECT * FROM `blog_posts` WHERE `id`='".$post_id."'");
}
else {
$cpost = mysql_query("SELECT * FROM `blog_posts` WHERE `id`='".$post_id."' AND `user_id`='".$user_id."'");
}
if (mysql_num_rows($cpost) == 0) {
require('../incfiles/head.php');
echo functions::display_error('Postingan yang dipilih tidak benar','<a href="index.php?act=manage_posts">'.$lng['back'].'</a>');
require('../incfiles/end.php');
exit;
}
$post = mysql_fetch_assoc($cpost);
$puser = mysql_fetch_array(mysql_query("SELECT `rights` FROM `users` WHERE `id`='".$post['user_id']."'"));
if ($post['user_id'] != $user_id && $rights <= $puser['rights']) {
require('../incfiles/head.php');
echo functions::display_error('Kamu tidak dapat memoderasi Postingan ini.');
require('../incfiles/end.php');
exit;
}
$blog = mysql_fetch_array(mysql_query("SELECT `id`,`url1` FROM `blog_sites` WHERE `id`='".$post['site_id']."'"));
switch($mod) {
case 'delete':
if (!isset($_SESSION['key']))
$_SESSION['key'] = md5(time());
$submit = $_SESSION['key'];
if (isset($_POST[$submit])) {
mysql_query("DELETE FROM `blog_posts` WHERE `id`='".$post['id']."'");
mysql_query("DELETE FROM `blog_comments` WHERE `post_id`='".$post['id']."'");
mysql_query("UPDATE `blog_categories` SET `counts` = `counts` - 1 WHERE `site_id`='".$post['site_id']."' AND `permalink`='".mysql_real_escape_string($post['category'])."'");
unset($_SESSION['key']);
header("Location: index.php");
exit;
}
$textl = $lng['hapus_posting'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['hapus_posting'] . '</div>';echo '<div class="menu"><form method="post" action="index.php?act=edit_post&amp;mod=delete&amp;post_id='.$post_id.'"><p>' . $lng['bloggers41'] . '</p><p><input type="submit" name="'.$submit.'" value="' . $lng['ya'] . '"/><input type="submit" name="no" value="' . $lng['tidak'] . '" onclick="javascript:window.history.back()"/></p></form></div>';
require('../incfiles/end.php');
break;

default:
$ttl = isset($_POST['title']) ? $_POST['title'] : rep_text($post['title'],true);
$dcs = isset($_POST['description']) ? $_POST['description'] : rep_text($post['description'],true);
$cat = isset($_POST['category']) ? $_POST['category'] : $post['category'];
$tags = isset($_POST['tags']) ? strtolower($_POST['tags']) : $post['tags'];
$privacy = isset($_POST['privacy']) ? $_POST['privacy'] : $post['privacy'];

if (isset($_POST['publish'])) {
$update = $_POST['updatetime'];
$tags = SaveTags($tags);
if ($privacy == "publics")
$privacy = "publics";
else
$privacy = "friends";
$hh = $_POST['hh'];
$bb = $_POST['bb'];
$tttt = $_POST['tttt'];
$jj = $_POST['jj'];
$mm = $_POST['mm'];
$ss = $_POST['ss'];
$curtime = $_POST['DefaultTime'];
$key = $_POST['key'];
$waktuku = $hh." ".$bb." ".$tttt." ".$jj.":".$mm.":".$ss;
$waktu = strtotime($waktuku);
$ed = explode("^",$post['edit']);
if ($update == "no" || $ed[1] >= 2) {
$edtim = $ed[1];
$waktu = $post['time'];
$draft = $post['draft'];
}
else {
$edtim = $ed[1] + 1;
if (strtotime($waktuku) < strtotime($curtime)) {
$waktu = time();
$draft = "no";
}
else {
$waktu = $waktu - $shift;
$draft = "yes";
}
}
$edps = $ed[0] + 1;
$edit = $edps."^".$edtim;
$cfg_form = true;
require("../incfiles/lib/htmlpurifier/purify.php");
$dcs = $purifier->purify($dcs);
if (empty($_SESSION['key']) OR $_SESSION['key'] != $key)
$error = "Session tidak benar.";
$bc = mysql_query("SELECT * FROM `blog_categories` WHERE `site_id`='".mysql_real_escape_string($post['site_id'])."' AND `user_id`='".$post['user_id']."' AND `permalink`='".mysql_real_escape_string($cat)."'");
if (mysql_num_rows($bc) == 0)
$error = "Kategori yang dipilih tidak benar.";
/*
$dflood = time() - 90;
$cflood = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `user_id`='".$post['user_id']."' AND `time` > '".$dflood."'"),0);
if ($cflood != 0)
$error = "Silakan tunggu beberapa saat lagi.";
*/
if (mb_strlen($ttl) < 2 OR mb_strlen($ttl) > 100)
$error = "Judul harus 2 s/d 100 karakter.";
if (mb_strlen($dcs) < 10)
$error = "Deskripsi minimal 10 karakter";
if (empty($error)) {

mysql_query("UPDATE `blog_posts` SET `title` = '".mysql_real_escape_string(rep_text(strip_tags($ttl)))."', `description` = '".mysql_real_escape_string(rep_text($dcs))."', `category` = '".mysql_real_escape_string($cat)."', `tags` = '".mysql_real_escape_string($tags)."', `privacy` = '".mysql_real_escape_string($privacy)."', `draft` = '".mysql_real_escape_string($draft)."', `edit` = '".mysql_real_escape_string($edit)."', `time` = '".mysql_real_escape_string($waktu)."' WHERE `id`='".$post['id']."' AND `user_id`='".$post['user_id']."'");
if ($cat != $post['category']) {
mysql_query("UPDATE `blog_categories` SET `counts` = `counts` - 1 WHERE `site_id`='".mysql_real_escape_string($post['site_id'])."' AND `user_id`='".$post['user_id']."' AND `permalink`='".mysql_real_escape_string($post['category'])."'");

mysql_query("UPDATE `blog_categories` SET `counts` = `counts` + 1 WHERE `site_id`='".mysql_real_escape_string($post['site_id'])."' AND `user_id`='".$post['user_id']."' AND `permalink`='".mysql_real_escape_string($cat)."'");
}
if ($post['user_id'] == $user_id)
header("location: index.php?act=manage_posts&blog_id=".$post['site_id']."&notice=".urlencode("Posting berhasil dipubikasikan."));
else
header("location: ".functions::blog_link($blog['url1'])."/".$post['permalink'].".html");
exit;
}
else {
$error = '<div class="rmenu"><span class="red">'.$error.'</span></div>';
}
}
$textl = $lng['k_posting'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['k_posting'] . '</div>';
if ($error)
echo $error;
echo'<div class="menu"><form method="post" action="index.php?act=edit_post&amp;post_id='.$post_id.'"><p><h3>' . $lng['judul'] . 'l</h3>';
if (!$is_mobile) {
echo '<script src="/js/ckeditor.js"></script>';
echo '<script language="JavaScript" src="/js/ckeditor.js"></script>';
echo '<textarea class="form-control ckeditor" rows="8" name="description" required>'.htmlspecialchars($dcs).'</textarea><br />';
}else{
echo '<input type="text" name="title" value="'.htmlspecialchars($ttl).'"/><br /><h3>' . $lng['desk'] . '</h3><textarea rows="' . $set_user['field_h'] . '" name="description">'.htmlspecialchars($dcs).'</textarea><br />';
}
echo '<h3>' . $lng['kategori'] . '</h3>
<select name="category">';
$bcats = mysql_query("SELECT `name`,`permalink` FROM `blog_categories` WHERE `site_id`='".$blog['id']."'");
while($bcat = mysql_fetch_array($bcats)) {
echo '<option value="'.$bcat['permalink'].'"'.($cat == $bcat['permalink'] ? ' selected="selected"' : '').'>'.htmlspecialchars($bcat['name']).'</option>';
}
echo '</select><br /><h3>' . $lng['tandai'] . '</h3><input type="text" name="tags" value="'.htmlspecialchars($tags).'"/><br /><span>' . $lng['koma'] . '</span><br /><h3>' . $lng['privasi'] . '</h3><select name="privacy"><option value="publics"'.($privacy == "publics" ? ' selected="selected"' : '').'>' . $lng['publik'] . '</option><option value="friends"'.($privacy == "friends" ? ' selected="selected"' : '').'>' . $lng['friend'] . '</option></select><br />';
$taim = time();
$tm = explode("-",date("d-F-Y-H-i-s",($taim + $shift)));
echo '<h3>' . $lng['waktu_posting'] . '</h3>';
echo '<input type="radio" name="updatetime" value="no" checked="checked"/> ' . $lng['tidak_mengubah_waktu'] . '<br /><input type="radio" name="updatetime" value="yes"/> ' . $lng['perbarui_waktu'] . '<br />';
echo '<select name="hh" size="2">';
for($i=1;$i<=31;$i++) {
if (strlen($i) != 2)
$tgl = "0".$i;
else
$tgl = $i;
echo '<option' . ($tm[0] == $tgl ? ' selected="selected">' : '>') . $tgl . '</option>';
}
echo '</select>';
$bulan = array("January","February","March","April","May","June","July","August","September","October","November","December");
echo '<select name="bb" size="8">';
for($i=0;$i<=count($bulan);$i++) {
echo '<option' . ($tm[1] == $bulan[$i] ? ' selected="selected">' : '>') . $bulan[$i] . '</option>';
}
echo '</select>';
echo '<select name="tttt" size="4"><option selected="selected">'.$tm[2].'</option>';
echo '</select>';
echo '<select name="jj" size="2">';
for($i=0;$i<=23;$i++) {
if (strlen($i) != 2)
$jam = "0".$i;
else
$jam = $i;
echo '<option' . ($tm[3] == $jam ? ' selected="selected">' : '>') . $jam . '</option>';
}
echo '</select>';
echo '<select name="mm" size="2">';
for($i=0;$i<=59;$i++) {
if (strlen($i) != 2)
$mnt = "0".$i;
else
$mnt = $i;
echo '<option' . ($tm[4] == $mnt ? ' selected="selected">' : '>') . $mnt . '</option>';
}
echo '</select>';
$_SESSION['key'] = md5(time());
echo '<input type="hidden" name="ss" value="'.$tm[5].'"><input type="hidden" name="DefaultTime" value="'.date("d F Y H:i:s",($taim + $shift)).'"><input type="hidden" name="key" value="'.$_SESSION['key'].'"></p><p><input type="submit" name="publish" value="' . $lng['terbitkan'] . '"/></p></form></div>';
require('../incfiles/end.php');
}
}
else {
header("location: index.php?act=manage_posts");
}