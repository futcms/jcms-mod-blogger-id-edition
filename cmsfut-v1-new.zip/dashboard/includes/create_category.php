<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');

function permalink($var)
{
$var = preg_replace('#([\W_]+)#',' ',$var);
$var = str_replace(' ','-',$var);
$var = strtolower($var);
return $var;
}

if (isset($_GET['blog_id'])) {
$blog_id = trim($_GET['blog_id']);
$ttl = isset($_POST['title']) ? $_POST['title'] : '';
$cb = mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."'");
if (mysql_num_rows($cb) == 0) {
header('location: index.php');
exit;
}
$bl = mysql_fetch_assoc($cb);
if (isset($_POST['submit'])) {
$permalink = permalink($ttl);
if (mb_strlen($ttl) < 2 OR mb_strlen($ttl) > 30)
$error = "Nama kategori harus 2 s/d 30 karakter.";
$ck = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_categories` WHERE `site_id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".mysql_real_escape_string($user_id)."'"),0);
if ($ck >= 20)
$error = "Kategori pada blog ini sudah mencapai 20 kategori.";
$cc = mysql_query("SELECT * FROM `blog_categories` WHERE (`site_id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".mysql_real_escape_string($user_id)."') AND (`name`='".mysql_real_escape_string($ttl)."' OR `permalink`='".mysql_real_escape_string($permalink)."')");
if (mysql_num_rows($cc) != 0)
$error = "Nama kategori sudah ada.";
if (empty($error)) {
mysql_query("INSERT INTO `blog_categories` SET `site_id`='".mysql_real_escape_string($blog_id)."', `user_id`='".mysql_real_escape_string($user_id)."', `name`='".mysql_real_escape_string(rep_text(strip_tags($ttl)))."', `permalink`='".mysql_real_escape_string($permalink)."', `counts`='0'");
mysql_query("UPDATE `users` SET `lastpost` = '" . time() . "' WHERE `id` = '" . $user_id . "'");
header("location: index.php?act=manage_categories&blog_id=".$blog_id."&notice=".urlencode("Kategori berhasil dibuat."));
exit;
}
else {
$error = '<div class="rmenu"><span class="red">'.$error.'</span></div>';
}
}
$textl = $lng['kategori'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['kategori'] . '</div>';
if ($error)
echo $error;
echo'<div class="menu"><form method="post" action="index.php?act=create_category&amp;blog_id='.$blog_id.'"><p><h3>' . $lng['blog'] . '</h3><img src="../images/blogs.png" width="16" height="16" class="left" />&#160;<a href="'.functions::blog_link($bl['url1']).'/">'.htmlspecialchars($bl['title']).'</a><br /><h3>' . $lng['nama_kat'] . '</h3><input type="text" name="title" value="'.htmlspecialchars($ttl).'"/></p><p><input type="submit" name="submit" value="' . $lng['buat'] . '"/></p></form></div>';
require('../incfiles/end.php');
}
else {
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$bc = mysql_num_rows($myb);
if ($bc == 0) {
header('location: index.php');
exit;
}

$textl = $lng['kategori'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['kategori'] . '</div>';
echo '<div class="menu"><form method="get" action="index.php"><p><input type="hidden" name="act" value="create_category"><h3>' . $lng['pilih_blog'] . '</h3><select name="blog_id">';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select></p><p><input type="submit" value="' . $lng['lanjutkan'] . '"/></p></form></div>';
require('../incfiles/end.php');
}
