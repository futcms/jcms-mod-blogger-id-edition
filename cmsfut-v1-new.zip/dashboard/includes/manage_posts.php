<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');

if (isset($_GET['blog_id'])) {
$blog_id = trim($_GET['blog_id']);
$bl = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."'");
if(mysql_num_rows($bl)==0) {
header("location: index.php");
exit;
}
$bs = mysql_fetch_array($bl);
$textl = $lng['k_posting'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</b></a> | ' . $lng['k_posting'] . '</div>';
if (isset($_GET['notice']) AND $_GET['notice'] != "") {
echo '<div class="rmenu">'.htmlentities(urldecode($_GET['notice'])).'</div>';
}
echo'<div class="user"><p><h3><img src="../images/blogs.png" width="16" height="16" class="left" />&#160;<a href="'.functions::blog_link($bs['url1']).'">'.htmlspecialchars($bs['title']).'</a></h3>';
echo '</p></div>';$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."'"),0);
if($total==0) {
echo '<div class="menu"><p>' . $lng['tidak_ada_posting'] . '</p></div>';
} else {
$blg = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."' ORDER BY `time` DESC LIMIT $start,$kmess");
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('index.php?act=manage_posts&amp;blog_id='.$blog_id.'&amp;', $start, $total, $kmess).'</div>';
while($post=mysql_fetch_array($blg)){
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<b>'.($post['draft'] == "yes" ? htmlspecialchars($post['title']) : '<a href="'.$set['homeurl'].'/login.php?r='.urlencode(functions::blog_link($bs['url1']).'/'.$post['permalink'].'.html').'">'.htmlspecialchars($post['title']).'</a>').'</b><div class="sub"><div>'.($post['draft'] == "yes" ? '<a href="'.$set['homeurl'].'/login.php?r='.urlencode(functions::blog_link($bs['url1']).'/'.$post['permalink'].'.html').'">Preview</a> | ' : '').'<a href="index.php?act=edit_post&amp;post_id='.$post['id'].'">' . $lng['edit'] . '</a> | <a href="index.php?act=edit_post&amp;mod=delete&amp;post_id='.$post['id'].'">' . $lng['delete'] . '</a></div>';
$ktp = mysql_fetch_assoc(mysql_query("SELECT `name` FROM `blog_categories` WHERE `site_id`='".$post['site_id']."' AND `user_id`='".$user_id."' AND `permalink`='".mysql_real_escape_string($post['category'])."'"));
echo '<div>' . $lng['kategori'] . ': <a href="index.php?act=manage_posts&amp;blog_id='.$blog_id.'&amp;category='.$post['category'].'">'.htmlspecialchars($ktp['name']).'</a></div>';
echo '<div>'.($post['draft'] == "yes" ? '' . $lng['konsep'] . '' : '' . $lng['diterbitkan'] . '').': '.functions::display_date($post['time']).'</div>';
$ts = ($set['timeshift'] * 3600) + time();
if ($post['hits_today_date'] != date("d-m-Y",$ts)) {
$hitoday = 0;
}
else {
$hitoday = $post['hits_today'];
}
echo '<div>' . $lng['comments'] . ': '.$post['comments'].'</div><div>' . $lng['hits_hari_ini'] . ': '.$hitoday.'</div><div>' . $lng['total_hits'] . ': '.$post['hits_total'];
echo '</div></div></div>';
++$i;
}
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('index.php?act=manage_posts&amp;blog_id='.$blog_id.'&amp;', $start, $total, $kmess).'</div>';
}
require('../incfiles/end.php');
}
else {
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$bc = mysql_num_rows($myb);
if ($bc == 0) {
header('location: index.php');
exit;
}

$textl = $lng['k_posting'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['k_posting'] . '</div>';
echo '<div class="menu"><form method="get" action="index.php"><p><input type="hidden" name="act" value="manage_posts"><h3>' . $lng['pilih_blog'] . '</h3><select name="blog_id">';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select></p><p><input type="submit" value="' . $lng['lanjutkan'] . '"/></p></form></div>';
require('../incfiles/end.php');
}
