<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');

if (isset($_GET['blog_id'])) {
$blog_id = trim($_GET['blog_id']);
$cb = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."'");
if (mysql_num_rows($cb) == 0) {
header('location: index.php');
exit;
}
$blog = mysql_fetch_assoc($cb);

set_time_limit(300);
$textl = "Google Verifikasi";
require('../incfiles/head.php');
if (!$user_id)
{
header('location: index.php');
exit;
}
else
{
echo '<div class="phdr">Google Verifikasi</div>';

echo '<div class="list2">Untuk memverifikasikan blog Anda pada Google silakan <a href="https://www.google.com/webmasters/verification/verification?hl=en&siteUrl='.functions::blog_link($blog['url1']).'/&continue=https://www.google.com/webmasters/tools/dashboard?hl%3Den%26siteUrl%3D'.functions::blog_link($blog['url1']).'&pli=1">Klik di sini</a>. Setelah Anda klik link tersebut selanjutnya pilih metode <b>HTML file Upload</b> tapi anda tidak perlu mendownload dan mengupload file tersebut, hanya copy nama file html tersebut ke kolom Meta Tag Gogle di pengaturan blog. Contoh googleb0426a8724eb1923.html lalu klik <b>Verify</b>.<br/><input type="radio" name="" checked>HTML file Upload<br/>
<span style="background-color:red;display:table;color:black;font-weight:bold;padding:1px;margin:1px;">Verify</span>Untuk mengakses Google Webmaster Tools pastikan Anda sudah punya akun Google.</div>';
}
require('../incfiles/end.php');
}
else {
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$bc = mysql_num_rows($myb);
if ($bc == 0) {
header('location: index.php');
exit;
}

$textl = "Google Verifikasi";
require('../incfiles/head.php');
echo '<div class="phdr">Google Verifikasi</div>';
echo '<form method="get" action="index.php"><p><input type="hidden" name="act" value="verifikasi"><h3>Subdomain</h3><select name="blog_id">';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select></p><p><input type="submit" value="Lanjutkan"/></p></form></div>';
require('../incfiles/end.php');
}
