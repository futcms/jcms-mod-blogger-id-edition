<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');

$textl = $lng['mafut21'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="'.$set['homeurl'].'/dashboard">' . $lng['dasbor'] . '</a> | ' . $lng['erik21'] . '</b></div>';

$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$nums = mysql_num_rows($myb);
if ($nums == 0) {
echo '<div class="menu"><p>You do not already have a
blog.</p></div>';
}
else {
while($blog=mysql_fetch_array($myb)) {
echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
$query = "(SELECT COUNT(*) FROM `blog_categories` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."') UNION ALL (SELECT COUNT(*) FROM `blog_posts` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `draft`='no') UNION ALL (SELECT COUNT(*) FROM `blog_posts` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `draft`='yes') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `post_id`!='0' AND `status`='accepted') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `post_id`!='0' AND `status`='moderated') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `post_id`!='0' AND `status`='spam') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `post_id`='0' AND `status`='accepted') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `post_id`='0' AND `status`='moderated') UNION ALL (SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".mysql_real_escape_string($blog['id'])."' AND `user_id`='".$user_id."' AND `post_id`='0' AND `status`='spam')";
$sql = mysql_query($query);
$total = array();
while ($res = mysql_fetch_array($sql)) { $total[] = $res[0]; }

echo '<h3><img src="../images/blogs.png" width="16" height="16" class="left" />&#160;<a href="'.functions::blog_link($blog['url1']).'">'.htmlspecialchars($blog['title']).'</a></h3><div class="sub"><div><a href="index.php?act=edit_blog&amp;blog_id='.$blog['id'].'">' . $lng['edit'] . '</a> | <a href="index.php?act=edit_blog&amp;mod=delete&amp;blog_id='.$blog['id'].'">' . $lng['delete'] . '</a> | <a href="https://accounts.google.com/ServiceLogin?service=sitemaps&passive=1209600&continue=https://www.google.com/webmasters/verification/home?hl%3Den/&followup=https://www.google.com/webmasters/verification/home?hl%3Den/&hl=en/">Google</a></div><ul><li>' . $lng['posting'] . ': <a href="index.php?act=manage_posts&amp;blog_id='.$blog['id'].'">'.($total[1] + $total[2]).'</a> ('.$total[1].' ' . $lng['diterbitkan'] . ', '.$total[2].' ' . $lng['konsep'] . '</li><li>' . $lng['kategori'] . ': <a href="index.php?act=manage_categories&amp;blog_id='.$blog['id'].'">'.$total[0].'</a></li><li>' . $lng['comments'] . ': <a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'">'.($total[3] + $total[4] + $total[5]).'</a> (<a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;mod=accepted">'.$total[3].'</a> ' . $lng['disetujui'] . ', <a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;mod=moderated">'.$total[4].'</a> ' . $lng['menunggu_moderasi'] . ', <a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;mod=spam">'.$total[5].'</a> spam)</li><li>'.$lng['guestbook'].': <a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;in=guestbook">'.($total[6] + $total[7] + $total[8]).'</a> (<a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;in=guestbook&amp;mod=accepted">'.$total[6].'</a> ' . $lng['disetujui'] . ', <a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;in=guestbook&amp;mod=moderated">'.$total[7].'</a> ' . $lng['menunggu_moderasi'] . ' <a href="index.php?act=manage_comments&amp;blog_id='.$blog['id'].'&amp;in=guestbook&amp;mod=spam">'.$total[8].'</a> ' . $lng['spam'] . '</li><li>' . $lng['hits_hari_ini'] . ': '.($blog['hits_today_date'] == date('d-m-Y',(time() + $set['timeshift'])) ? $blog['hits_today'] : '0').'</li><li>' . $lng['total_hits'] . ': '.$blog['hits_total'].'</li>';
if (($total[1] + $total[2]) > 0) {
$last_post = mysql_fetch_array(mysql_query("SELECT `draft`,`time` FROM `blog_posts` WHERE `site_id`='".$blog['id']."' ORDER BY `time` DESC LIMIT 1"));
echo '<li>' . $lng['posting_terakhir'] . ': '.functions::display_date($last_post['time']).($last_post['draft'] == "yes" ? ' ' . $lng['konsep'] . '' : '').'</li>';
if (($total[3] + $total[4] + $total[5]) > 0) {
$last_comment = mysql_fetch_array(mysql_query("SELECT `time` FROM `blog_comments` WHERE `site_id`='".$blog['id']."' ORDER BY `time` DESC LIMIT 1"));
echo '<li>' . $lng['kom_terakhir'] . ': '.functions::display_date($last_comment['time']).'</li>';
}
}
echo '</ul></div>';
echo '</div>';
++$i;
}
}
echo'<div class="menu"><a href="index.php?act=create_blog"><b><span class="green">' . $lng['buatblog'] . '</span></b></a></div>';
echo'</div>';

require('../incfiles/end.php');
