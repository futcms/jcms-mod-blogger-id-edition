<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');
if (isset($_GET['blog_id'])) {
$blog_id = trim($_GET['blog_id']);
$bl = mysql_query("SELECT `title`,`url1` FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."'");
if(mysql_num_rows($bl)==0) {
header("location: index.php");
exit;
}
$bs = mysql_fetch_array($bl);
$textl = $lng['k_kat'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</b></a> | ' . $lng['k_kat'] . '</div>';
if (isset($_GET['notice']) AND $_GET['notice'] != "") {
echo '<div class="rmenu">'.htmlentities(urldecode($_GET['notice'])).'</div>';
}
echo'<div class="user"><p><h3><img src="../images/blogs.png" width="16" height="16" class="left" />&#160;<a href="'.functions::blog_link($bs['url1']).'">'.htmlspecialchars($bs['title']).'</a></h3>';
echo '</p></div>';$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_categories` WHERE `site_id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."'"),0);
$ctg = mysql_query("SELECT * FROM `blog_categories` WHERE `site_id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."' ORDER BY `name` ASC LIMIT $start,$kmess");
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('index.php?act=manage_categories&amp;blog_id='.$blog_id.'&amp;', $start, $total, $kmess).'</div>';
while($cat=mysql_fetch_array($ctg)){
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
$total_posts = $cat['counts'];
echo '<b>'.htmlspecialchars($cat['name']).'</b> (<a href="index.php?act=manage_posts&amp;blog_id='.$blog_id.'&amp;category='.$cat['permalink'].'">'.$total_posts.'</a> posts)';
echo '<div class="sub"><a href="index.php?act=edit_category&amp;category_id='.$cat['id'].'">' . $lng['edit'] . '</a> | <a href="index.php?act=edit_category&amp;mod=delete&amp;category_id='.$cat['id'].'">' . $lng['delete'] . '</a></div>';
echo '</div>';
++$i;
}
if ($total > $kmess) echo '<div class="topmenu">'.functions::display_pagination('index.php?act=manage_categories&amp;blog_id='.$blog_id.'&amp;', $start, $total, $kmess).'</div>';
require('../incfiles/end.php');
}
else {
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$bc = mysql_num_rows($myb);
if ($bc == 0) {
header('location: index.php');
exit;
}

$textl = $lng['k_kat'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['k_kat'] . '</div>';
echo '<div class="menu"><form method="get" action="index.php"><p><input type="hidden" name="act" value="manage_categories"><h3>' . $lng['pilih_blog'] . '</h3><select name="blog_id">';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select></p><p><input type="submit" value="' . $lng['lanjutkan'] . '"/></p></form></div>';
require('../incfiles/end.php');
}