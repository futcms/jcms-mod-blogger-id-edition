<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');

if (isset($_GET['blog_id'])) {
$blog_id = trim($_GET['blog_id']);
$cb = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='".mysql_real_escape_string($blog_id)."' AND `user_id`='".$user_id."'");
if (mysql_num_rows($cb) == 0) {
header('location: index.php');
exit;
}
$blog = mysql_fetch_assoc($cb);

set_time_limit(300);
$textl = "Costum Domain";
require('../incfiles/head.php');
if (!$user_id)
{
header('location: index.php');
exit;
}
else
{
// mulai isi data anda dari sini

$cp_user = "blogown"; // Cpanel Username
$cp_pass = "cmsfut"; // Cpanel password
$cp_theme = "3x"; // Cpanel theme default x3
$domain_ip = "158.69.118.117"; // IP your Pasaman Waps domain
$domain_cname = "cname.blogown.xyz"; // cname.contoh.com/ns1.contoh.com

$domain_main_domain = 'blogown.xyz'; // domain satu/utama

$domain_main_domain2 = 'seoku.xyz'; // domain dua bila menggunakan lebih dari satu domain

// cukup sampai disini isi data anda, yang lain tak perlu di ubah lagi

$user_site=$blog['url1'];
$usite1 = str_replace('http://www.', 'http://', $blog['url2']);
$usite2 = str_replace('http://', 'http://www.', $usite1);
if (isset($_POST['parking']))
{
$domain = htmlentities(strtolower($_POST['domain']));
$dns_a=dns_get_record($domain, DNS_A);
$dns_cname=dns_get_record($domain, DNS_CNAME);
$dns_ns=dns_get_record($domain, DNS_NS);
if ($dns_a[0]['ip'] != $domain_ip &&  $dns_cname[0]['target'] != $domain_cname)
$err .='<div class="rmenu">Invalid DNS Record / Record DNS tidak benar,</div>';
if (substr($user_site, 7) == $domain)
$err .='<div class="rmenu">Incorrect domain. / Silakan masukan domain baru Anda.</div>';
if (substr($domain, "-".strlen($domain_main_domain)) == $domain_main_domain || substr($domain, "-".strlen($domain_main_domain2)) == $domain_main_domain2)
$err .='<div class="rmenu">Incorrect domain. / Silakan masukan domain yang benar.</div>';
if (preg_match("/[^a-z0-9\.\_\-]/", $domain))
$err .='<div class="rmenu">Invalid domain!. / karakter Domain tidak benar!.</div>';
if (substr($domain, 0, 4) == 'www.')
$err .='<div class="rmenu">Incorrect domain. / Domain tidak benar.</div>';
if ($domain == 'example.com')
$err .='<div class="rmenu">Incorrect domain.</div>';
if (mb_strlen($domain) > 32 || mb_strlen($domain) < 4)
$err .='<div class="rmenu">Lenght of domain 4 up to 32 characters./ Domain minimal 4 maksimal 32 karakter.</div>';
if (empty($domain))
$err .='<div class="rmenu">Domain empty. / Domain Tidak boleh kosong</div>';
$cek_dom='http://'.$domain.'';
$sql=mysql_query("select * from blog_sites where url1='".mysql_real_escape_string($cek_dom)."'");
if (mysql_num_rows($sql) != 0)
$err .='<div class="rmenu">Domain already used by someone. / Domain telah Di gunakan.</div>';
if (empty($err))
{
$opts = array(
'http' =>array(
'method' => "GET",
'header' => "Accept-language: en\r\n" .
"Cookie: foo=bar\r\n"
)
);
$context = stream_context_create($opts);
$request=file_get_contents("http://".$cp_user.":".$cp_pass."@".$domain_main_domain.":2082/frontend/".$cp_theme."/park/doaddparked.html?domain=".$domain."&go=Add+Domain", false, $context);
if ($request)
{
$new_dom='http://'.$domain.'';
mysql_query("update following set url='".mysql_real_escape_string($new_dom)."' where url='".mysql_real_escape_string($user_site)."'");
if (substr($user_site, "-".strlen($domain_main_domain)) == $domain_main_domain || substr($user_site, "-".strlen($domain_main_domain2)) == $domain_main_domain2)

{
mysql_query("update blog_sites set url1='".mysql_real_escape_string($new_dom)."', url2='".mysql_real_escape_string($user_site)."' where id='".$blog['id']."' and user_id='".$user_id."'");
mysql_query("update users set www='".mysql_real_escape_string($new_dom)."' where id='".$user_id."'");
}
$hasil='<div class="rmenu">Domain <b>'.$domain.'</b> berhasil di parking. Mohon tunggu maksimal 48 jam untuk proses setup dan pastikan pengaturan <b>Name Server (NS)</b> atau <b>Zona Record</b> telah benar.</div>';
}
else
{
$hasil='<div class="rmenu">Unable to parking domain. / Gagal parkir domain</div>';
}
}
else
{
$hasil='<div class="rmenu">'.$err.'</div>';
}
}
if (isset($_GET['domi'])) {
echo "http://".$cp_user.":".$cp_pass."@".$domain_main_domain.":2082/frontend/".$cp_theme."/park/doaddparked.html?domain=".$domain."&go=Add+Domain"; }
if (isset($_POST['reset']))
{
if ($usite1 == $user_site)
{
$hasil='<div class="rmenu">Anda belum memparking domain.</div>';
}
else
{
$dd=str_replace('http://', '', $user_site);

$opts = array(
'http' =>array(
'method' => "GET",
'header' => "Accept-language: en\r\n" .
"Cookie: foo=bar\r\n"
)
);
$context = stream_context_create($opts);
$request=file_get_contents("http://".$cp_user.":".$cp_pass."@".$domain_main_domain.":2082/frontend/".$cp_theme."/park/dodelparked.html?domain=".$dd, false, $context);
if ($request) {
mysql_query("update following set url='".mysql_real_escape_string($usite1)."' where url='".mysql_real_escape_string($user_site)."'");

mysql_query("update blog_sites set url1='".mysql_real_escape_string($usite1)."', url2='".mysql_real_escape_string($usite2)."' where id='".$blog['id']."' and user_id='".$user_id."'");
mysql_query("update users set www='".mysql_real_escape_string($usite1)."' where id='".$user_id."'");
$hasil='<div class="gmenu">Your domain has been reset to / Domain Anda berhasi di kembalikan ke <b>'.$usite1.'</b></div>';
}
else {
$hasil='<div class="rmenu">Unable to reset your domain. Please contact Administrator. / Gagal mengembalikan Domain. Silakan hubungi Administrator.</div>';
}
}
}
echo '<div class="phdr">Custom Domain | <a href="index.php"><b>' . $lng['dasbor'] . '</b></a></div>';
if (!empty($hasil))
echo $hasil;
echo '<div class="list2">Domain pada <b>'.$blog['title'].'</b> adalah: <b>'.str_replace('http://', '', $blog['url2']).'</b>.<br/> Jika Anda ingin menggunakan custom domain sendiri silakan lihat pengaturan <b>Zona Record</b><br /><b>A</b> : '.$domain_ip.'<br /><b>CNAME</b> : '.$domain_cname.'<br /><br />Silakan edit salah satu pengaturan tersebut (NS atau Zona Record) pada hosting yang menyediakan domain Anda.
<br />
<br />
<div class="rmenu"><b>Custom Domain</b> mungkin akan pengaruhi peringkat dan trafik blog anda di mesin pencari dalam waktu sementara.
<br />Lakukan custom domain hanya jika anda benar-benar berniat untuk melakukannya.</div><br/><form style="text-align:left;" method="post" action="index.php?act=domain_parking&amp;blog_id='.$blog_id.'"><b>Custom Domain:</b><br /></div>';

if (substr($user_site, "-".strlen($domain_main_domain)) == $domain_main_domain || substr($user_site, "-".strlen($domain_main_domain2)) == $domain_main_domain2)

$dom='<input type="text" name="domain" value="example.com"/><br/><small>tanpa www</small><br/><input type="submit" name="parking" value="Parking"/>';
else
$dom = '<input type="hidden" name="domain" value="'.str_replace('http://', '', $user_site).'"/><br/>'.str_replace('http://', '', $user_site).'<br /><input type="submit" name="reset" value="Reset"/><br/>';
echo ''.$dom.'</form></div>';
}
require('../incfiles/end.php');
}
else {
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$bc = mysql_num_rows($myb);
if ($bc == 0) {
header('location: index.php');
exit;
}

$textl = "Domain Parking";
require('../incfiles/head.php');
echo '<div class="phdr">Domain Parking | <a href="index.php"><b>' . $lng['dasbor'] . '</b></a></div>';
echo '<div class="list2"><form method="get" action="index.php"><p><input type="hidden" name="act" value="domain_parking"><h3>Subdomain</h3><br/><select name="blog_id">';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select><br/><input type="submit" value="Lanjutkan"/><br/><br/></form></div>';
require('../incfiles/end.php');
}
?>