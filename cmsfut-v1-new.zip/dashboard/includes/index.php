<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');

$textl = $lng['dasbor'];
require('../incfiles/head.php');
if ($is_mobile){
require('improfile.php');
}
//require('mafut_ragil.php');
require('mafutragil.php');
require('../incfiles/end.php');
