<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error');
$headmod = "BYURL";
$headmodurl = $set['homeurl']."/dashboard?act=template";
if (isset($_GET['blog_id'])) {
$blog_id = mysql_real_escape_string($_GET['blog_id']);
$bcheck = mysql_query("SELECT * FROM `blog_sites` WHERE `id`='".$blog_id."' AND `user_id`='".$user_id."'");
if (mysql_num_rows($bcheck) == 0) {
$textl = $lng['edit_tema'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['edit_tema'] . '</div>';echo functions::display_error('Blog yang dipilih tidak benar.','<a href="index.php?act=edit_blog">'.$lng['back'].'</a>');
require('../incfiles/end.php');
exit;
}
if (!is_dir("../files/templates")) {
mkdir("../files/templates",0777);
chmod("../files/templates",0777);
file_put_contents("../files/templates/.htaccess","deny from all
AddDefaultCharset UTF-8");
}
$blog = mysql_fetch_array($bcheck);
if (isset($_GET['download'])) {
$thm = $mod == "mobile" ? "mobile" : "desktop";
if (is_file("../files/templates/u".$blog['user_id']."-b".$blog['id']."-".$thm.".xml"))
$theme = "../files/templates/u".$blog['user_id']."-b".$blog['id']."-".$thm.".xml";
else
$theme = "../incfiles/blog/".$thm.".xml";
header('Content-Description: File Transfer');
header('Content-Type: text/xml');    header('Content-Disposition: attachment; filename='.basename($theme));
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' .filesize($theme));
readfile($theme);
exit;
}
$textl = $lng['edit_tema'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | <a href="index.php?act=template&amp;blog_id='.$blog_id.'">' . $lng['edit_tema'] . '</a></div>';
echo'<div class="user"><h3><img src="../images/blogs.png" width="16" height="16" class="left" />&#160;<a href="'.functions::blog_link($blog['url1']).'">'.htmlspecialchars($blog['title']).'</a></h3></div>';
switch($mod) {
case 'mobile':
case 'desktop':
if (isset($_GET['edit'])) {
$edit = htmlentities($_GET['edit']);
switch($edit) {
case 'global':
$sub = "global";
break;
case 'header':
$sub = "header";
break;
case 'post':
$sub = "if:post";
break;
case 'singlepost':
$sub = "if:singlepost";
break;
case 'guestbook':
$sub = "if:guestbook";
break;
case 'footer':
$sub = "footer";
break;
default:
$sub = "header";
break;
}
if (is_file("../files/templates/u".$blog['user_id']."-b".$blog['id']."-".$mod.".xml"))
$tpl = "../files/templates/u".$blog['user_id']."-b".$blog['id']."-".$mod.".xml";
else
$tpl = "../incfiles/blog/".$mod.".xml";
$handle = fopen($tpl, "r");
$body = fread($handle, filesize($tpl));
fclose($handle);
$code = isset($_POST['code']) ? $_POST['code'] : "{".$sub."}".get_tpl($body,$sub)."{/".$sub."}";
if(!isset($_SESSION['key']))
$_SESSION['key'] = md5(time());
$submit = $_SESSION['key'];
if (isset($_POST[$submit])) {
unset($_SESSION['key']);
$submit = "disable";
$save_code = get_tpl($body,$sub,$code);
if(file_put_contents("../files/templates/u".$blog['user_id']."-b".$blog['id']."-".$mod.".xml",$save_code)) {
echo '<div class="rmenu">Templates saved successfully.</div>';
} else {
echo '<div class="rmenu">Template fails saved.</div>';
}
}
echo '<div class="menu"><p><h3>Bagian</h3><ul><li><a href="index.php?act=template&amp;blog_id='.$blog_id.'&amp;mod='.$mod.'&amp;edit=global">Global</a></li><li><a href="index.php?act=template&amp;blog_id='.$blog_id.'&amp;mod='.$mod.'&amp;edit=header">Header</a></li><li><a href="index.php?act=template&amp;blog_id='.$blog_id.'&amp;mod='.$mod.'&amp;edit=post">Post</a></li><li><a href="index.php?act=template&amp;blog_id='.$blog_id.'&amp;mod='.$mod.'&amp;edit=singlepost">Single Post</a></li><li><a href="index.php?act=template&amp;blog_id='.$blog_id.'&amp;mod='.$mod.'&amp;edit=guestbook">Guestbook</a></li><li><a href="index.php?act=template&amp;blog_id='.$blog_id.'&amp;mod='.$mod.'&amp;edit=footer">Footer</a></li></ul></p></div><div class="gmenu"><p><h3>Edit '.$sub.'</h3><form method="post" action="index.php?act=template&amp;blog_id='.$blog_id.'&amp;mod='.$mod.'&amp;edit='.$edit.'"/><textarea rows="'.$set_user['field_h'].'" name="code">'.htmlentities($code,ENT_QUOTES).'</textarea><p><input type="submit" name="'.$submit.'" value="' . $lng['simpan'] . '"/></p></form></p></div><p><a href="index.php?act=template&amp;blog_id='.$blog['id'].'">'.$lng['back'].'</a></p>';
require('../incfiles/end.php');
exit;
}

if (isset($_GET['reset']) AND !empty($_GET['reset']) AND $_GET['reset'] == $_SESSION['key']) {
unset($_SESSION['key']);
$thm = $mod;
if (is_file("../files/templates/u".$blog['user_id']."-b".$blog['id']."-".$mod.".xml"))
unlink("../files/templates/u".$blog['user_id']."-b".$blog['id']."-".$mod.".xml");
echo '<div class="rmenu">Template berhasil direset.<br /><a href="index.php?act=template&amp;blog_id='.$blog_id.'">'.$lng['back'].'</a></div>';
require('../incfiles/end.php');
exit;
}
if (isset($_GET['upload'])) {
if (isset($_POST['upload'])) {
$body = $_FILES['filetpl']['tmp_name'];
$key = $_POST['key'];
if ($_FILES['filetpl']['type'] != "text/xml" AND $_FILES['filetpl']['type'] != "text/html") {
$error = "Jenis file tidak benar.";
}
elseif ($_FILES['filetpl']['name'] == "") {
$error = "Silakan pilih file.";
}
elseif ($_FILES['filetpl']['size'] > 301024) {
$error = "Maksimal ukuran 30kb.";
}
elseif ($key != $_SESSION['key']) {
$error = "Sesi tidak benar.";
}
elseif (substr($_FILES['filetpl']['name'],-4) != ".xml"){
$error = "Ekstensi file tidak benar.";
}
unset($_SESSION['key']);
if (empty($error)) {

$handle = fopen($body, "r");
$body = fread($handle, $_FILES['filetpl']['size']);
fclose($handle);

$tpl_keys = array(
"#http\:\/\/indowapblog\.com\/bbsm\.php#is",
"#\{site\:url\}\/mod\/shoutbook\.php#is",
"#\{site\:url\}\/content\/\{site\:icon\}#is",
"#http\:\/\/indowapblog\.com\/img\.php\?img\=#is"
);

$tpl_values = array(
$set['homeurl']."/pages/faq.php?act=smileys",
"{site:url}/guestbook.html",
"{site:icon}",
$set['homeurl']."/users/avatar.php?user="
);
$body = preg_replace($tpl_keys,$tpl_values,$body);

if (file_put_contents("../files/templates/u".$blog['user_id']."-b".$blog['id']."-".$mod.".xml",$body)) {
echo '<div class="menu"><p>Template berhasil diupload</p></div>';
}
else {
echo functions::display_error('Gagal mengupload file.','<a href="index.php?act=template&amp;mod='.$mod.'&amp;blog_id='.$blog_id.'&amp;upload=true">'.$lng['back'].'</a>');
}
}
else {
echo functions::display_error($error,'<a href="index.php?act=template&amp;mod='.$mod.'&amp;blog_id='.$blog_id.'&amp;upload=true">'.$lng['back'].'</a>');
}
}
else {
$_SESSION['key'] = md5(time());
echo '<form action="index.php?act=template&amp;mod='.$mod.'&amp;blog_id='.$blog_id.'&amp;upload=true" method="POST" enctype="multipart/form-data">
    <input name="MAX_FILE_SIZE" value="302880" type="hidden"/><p><h3>' . $lng['edit_tema'] . '</h3><input type="file" name="filetpl"><input type="hidden" name="key" value="'.$_SESSION['key'].'"/></p><p><input type="submit" name="upload" value="' . $lng['upload'] . '"/></p></form><p><a href="index.php?act=template&amp;blog_id='.$blog['id'].'">'.$lng['back'].'</a></p>';
require('../incfiles/end.php');
exit;
}
}

default:
$_SESSION['key'] = md5(time());
echo '<div class="phdr"><b>Mobile ' . $lng['theme'] . '</b></div>
<div class="menu"><a href="index.php?act=template&amp;mod=mobile&amp;blog_id='.$blog_id.'&amp;edit=header">' . $lng['edit'] . '</a></div>
<div class="menu"><a href="index.php?act=template&amp;mod=mobile&amp;blog_id='.$blog_id.'&amp;upload=true">' . $lng['upload'] . '</a></div>
<div class="menu"><a href="index.php?act=template&amp;mod=mobile&amp;blog_id='.$blog_id.'&amp;download=true">' . $lng['unduh'] . '</a></div>
<div class="menu"><a href="/share-templates">' . $lng['erik8'] . '</a></div>
<div class="menu"><a href="index.php?act=template&amp;mod=mobile&amp;blog_id='.$blog_id.'&amp;reset='.$_SESSION['key'].'">' . $lng['kembalikan'] . '</a></div>';

echo '<div class="phdr"><b>Desktop ' . $lng['theme'] . '</b></div>
<div class="menu"><a href="index.php?act=template&amp;mod=desktop&amp;blog_id='.$blog_id.'&amp;edit=header">' . $lng['edit'] . '</a></div>
<div class="menu"><a href="index.php?act=template&amp;mod=desktop&amp;blog_id='.$blog_id.'&amp;upload=true">' . $lng['upload'] . '</a></div>
<div class="menu"><a href="index.php?act=template&amp;mod=desktop&amp;blog_id='.$blog_id.'&amp;download=true">' . $lng['unduh'] . '</a></div>
<div class="menu"><a href="/share-templates">' . $lng['erik8'] . '</a></div>
<div class="menu"><a href="index.php?act=template&amp;mod=desktop&amp;blog_id='.$blog_id.'&amp;reset='.$_SESSION['key'].'">' . $lng['kembalikan'] . '</a></div>';
}
echo '</div>';
require('../incfiles/end.php');
}
else {
$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$bc = mysql_num_rows($myb);
if ($bc == 0) {
header('location: index.php');
exit;
}

$textl = $lng['edit_tema'];
require('../incfiles/head.php');echo '<div class="phdr"><a href="index.php"><b>' . $lng['dasbor'] . '</a></b> | ' . $lng['edit_tema'] . '</div>';
echo '<div class="menu"><form method="get" action="index.php"><p><input type="hidden" name="act" value="template"><h3>' . $lng['pilih_blog'] . '</h3><select name="blog_id">';
while($blog=mysql_fetch_array($myb)) {
echo '<option value="'.$blog['id'].'">'.htmlspecialchars($blog['title']).'</option>';
}
echo '</select></p><p><input type="submit" value="' . $lng['lanjutkan'] . '"/></p></form></div>';
require('../incfiles/end.php');
}