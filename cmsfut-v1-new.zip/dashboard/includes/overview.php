<?php

/*
* Modded by
* Name: Mafut Ragil
* Web name: BlogOwn and CmsFut
* Website: ngeblog.gq and www.blogown.xyz
* Email: my@blogown.xyz
* Phone: 085643716621
* Social network: https://twitter.com/mafutragil and https://facebook.com/mafut.harmony
* Powered by: Cmsfut and JohnCMS
*/

if (isset($_GET['blog_id'])) {
$blog_id = trim($_GET['blog_id']);
// content="text/plain; charset=utf-8"
require_once ('../incfiles/src/jpgraph.php');
require_once ('../incfiles/src/jpgraph_bar.php');

$myb = mysql_query("SELECT * FROM `blog_sites` WHERE `user_id`='".$user_id."'");
$blog=mysql_fetch_array($myb);
// Data perhist
$day = $blog['hits_today'];
$link = $blog['url1'];
$datay=array($day,0,0);

//dino
$array_hr= array(1=>"Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu");
$hari = $array_hr[date('N')];

// Buat grafik. Kedua panggilan selalu diperlukan
$graph = new Graph(250,150,'auto');
$graph->SetScale("textlin");

//$theme_class="DefaultTheme";
//$graph->SetTheme(new $theme_class());

// Mengatur posisi tick mayor dan minor secara manual
$graph->yaxis->SetTickPositions(array($day,0,0), array(10));
$graph->SetBox(false);

//$graph->ygrid->SetColor('gray');
$graph->ygrid->SetFill(false);
$graph->xaxis->SetTickLabels(array(''.$hari.'','Today: '.$blog['hits_today'].'',' Total: '.$blog['hits_total'].''));
$graph->yaxis->HideLine(false);
$graph->yaxis->HideTicks(false,false);

// Hasil bar plot yang tampil
$b1plot = new BarPlot($datay);

// ...and add it to the graPH
$graph->Add($b1plot);


$b1plot->SetColor("white");
$b1plot->SetFillcolor("#FF0000","#FF0000","#FF0000");
$b1plot->SetWidth(45);
$graph->title->Set("$link");

// Menampilkan data grafik
$graph->Stroke();
header("Content-Type: application/octet-stream");
header('Content-Disposition: attachment; filename="'.$_GET['blog_id'].'.gif');
}else{
header('location: index.php');
exit;
}
?>