<?php
header("Location: ".$set['homeurl']."/users/profile.php?act=friends&do=add&id=".$bsite['user_id']);
