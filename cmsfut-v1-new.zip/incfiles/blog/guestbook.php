<?php

defined('_IN_JOHNCMS') or die('Error');

if (!isset($_SESSION['comm']))
$_SESSION['comm'] = md5(time().$bsite['id']);
$html .= str_replace("{header:title}","Buku Tamu | ".$bsite['title'],get_tpl($tpl,"header"));

$cf_result = false;
$submit = $_SESSION['comm'];
$back = isset($_POST['back']) ? $_POST['back'] : md5(time());
if (($back == $submit) OR isset($_POST[$submit]) OR isset($_POST['submit'])) {
$cf_name = functions::checkin(strip_tags(rep_text($_POST['name'])));
$cf_email = functions::checkin(strip_tags(rep_text($_POST['email'])));
$cf_site = functions::checkin(strip_tags(rep_text($_POST['site'])));
if (isset($_POST['message']))
$cf_msg = $_POST['message'];
elseif (isset($_POST['msg']))
$cf_msg =$_POST['msg'];
else
$cf_msg = $_POST['comment'];
$cf_msg = functions::checkin(rep_text($cf_msg));
require_once("incfiles/lib/htmlpurifier/HTMLPurifier.standalone.php");
$cfg = HTMLPurifier_Config::createDefault();
$cfg->set('Core.Encoding','UTF-8');
$cfg->set('Cache.DefinitionImpl',null);
$cfg->set('HTML.Doctype','XHTML 1.0 Transitional');
$cfg->set('HTML.Allowed','a[href],b,u,i,s,font[color]');
$cfg->set('Attr.EnableID',true);
$purifier = new HTMLPurifier($cfg);
$cf_msg = $purifier->purify($cf_msg);
if ($user_id) {
$flood = functions::antiflood();
if ($flood)
$error = $lng['error_flood']." ".$flood." ".$lng['seconds'];
$author_id = $user_id;
$cf_name = $datauser['name'];
$cf_email = $datauser['mail'];
if (strlen($cf_msg) < 2 OR strlen($cf_msg) > 5000)
$cf_error = "Komentar minimal 2 dan maksimal 5000 karakter.";
if (empty($cf_site))
$cf_site = $datauser['www'];
}
else {
$author_id = 0;
if (strlen($cf_msg) < 2 OR strlen($cf_msg) > 1024)
$cf_error = "Komentar minimal 2 dan maksimal 1024 karakter.";
}

if (strlen($cf_name) < 2 OR strlen($cf_name) > 30)
$cf_error = "Nama minimal 2 dan maksimal 30 karakter.";

if ($bsite['user_id'] == $user_id || $rights == 9 || $rights == 7)
$cocap = "no";
else
$cocap = $bsite_set[6];
if (($cocap == "yes" OR !$user_id) AND (!isset($_POST['captcha']) OR $_SESSION['code'] != $_POST['captcha'])) {
unset($_SESSION['code']);
$form = '<form id="captcha_form" method="POST" action="http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'">'.($cf_name != "" ? '<input type="hidden" name="name" value="'.htmlentities($cf_name).'"/>' : '<h3>Nama</h3><input type="text" name="name" value="'.htmlentities($cf_name).'"/><br />').($cf_email != "" ? '<input type="hidden" name="email" value="'.htmlentities($cf_email).'"/>' : '<h3>Email</h3><input type="text" name="email" value="'.htmlentities($cf_email).'"/><br />').($cf_site != "" ? '<input type="hidden" name="site" value="'.htmlentities($cf_site).'"/>' : '<h3>Situs</h3><input type="text" name="site" value="'.htmlentities($cf_site).'"/><br />').($cf_msg != "" ? '<input type="hidden" name="message" value="'.htmlentities($cf_msg).'"/>' : '<h3>Pesan</h3><textarea name="message" rows="5"/>'.htmlentities($cf_msg).'</textarea><br />').'<h3>Kode Keamanan</h3><img src="http://'.$_SERVER['HTTP_HOST'].'/captcha.php?r='.rand(1000,9999).'" border="1" alt="captcha"/><br />'.$lng['enter_code'].'<br /><input type="text" name="captcha" maxlength="5" size="5"/><br /><input type="submit" name="'.$submit.'" value="'.$lng['continue'].'"/></form>';
$html .= get_tpl(get_tpl($tpl,"if:post"),"post:entry",$form);
$html .= get_tpl($tpl,"footer");
echo get_tpl_etc($html);
exit;
}


if (empty($cf_error)) {
unset($_SESSION['comm']);
$submit = md5(time());
if ($bsite_set[5] == "yes" OR !$user_id) { $sts = "moderated"; } else { if (strpos($cf_msg,"http://") !== false) { if (count(explode("http://",$cf_msg)) > 5)
$sts = "spam";
else
$sts = "accepted"; } else {
$sts = "accepted"; } }
if ($bsite['user_id'] == $user_id || $rights == 9 || $rights == 7)
$sts = "accepted";
if ($bsite['user_id'] == $user_id)
$read = 1;
else
$read = 0;
mysql_query("INSERT INTO `blog_comments` SET `site_id`='".$bsite['id']."',`user_id`='".$bsite['user_id']."',`post_id`='0',`author_id`='".mysql_real_escape_string($author_id)."',`author_name`='".mysql_real_escape_string($cf_name)."',`author_email`='".mysql_real_escape_string($cf_email)."',`author_homepage`='".mysql_real_escape_string($cf_site)."',`text`='".mysql_real_escape_string(functions::smileys($cf_msg))."',`status`='".$sts."',`adminread`='".$read."',`time`='".time()."'");
if ($user_id) {
mysql_query("UPDATE `users` SET `lastpost` = '" . time() . "' WHERE `id` = '" . $user_id . "'");
}
if ($sts == "accepted") { $cf_result = str_replace("{success:message}","Komentar Anda berhasil ditambahkan",get_tpl($tpl,"success")); } elseif ($sts == "moderated" OR $sts == "spam") { $cf_result = str_replace("{info:message}","Komentar Anda berhasil ditambahkan dan akan ditampilkan setelah disetujui Administrator.",get_tpl($tpl,"info")); }
if (isset($_POST['msg']) AND !empty($_SERVER['HTTP_REFERER'])) { header("Location: ".$_SERVER['HTTP_REFERER']); exit;} }
else {
$cf_result = str_replace("{error:message}",$cf_error,get_tpl($tpl,"error"));
}
}

$gb_tpl = get_tpl($tpl,"if:guestbook");
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_comments` WHERE `site_id` = '".$bsite['id']."' AND `post_id`='0' AND `status`='accepted'"),0);
if ($total == 0) {
$pagination = false;
$gb_tpl = get_tpl($gb_tpl,"guestbook:entry",str_replace("{info:message}",$lng['list_empty'],get_tpl($tpl,"info")));
}
else {
$tpl_entry = get_tpl($gb_tpl,"guestbook:entry");

$gb_que = mysql_query("SELECT * FROM `blog_comments` WHERE `site_id` = '".$bsite['id']."' AND `post_id`='0' AND `status`='accepted' ORDER BY `time` DESC LIMIT $start,$kmess");
while($post=mysql_fetch_assoc($gb_que)) {
$entry_keys = array(
"#\{guestbook\:entry\:homepage\}#is",
"#\{guestbook\:entry\:userid\}#is",
"#\{guestbook\:entry\:name\}#is",
"#\{guestbook\:entry\:date\}#is",
"#\{guestbook\:entry\:message\}#is"
);
$entry_values = array(
$post['author_homepage'],
$post['author_id'],
$post['author_name'],
functions::display_date($post['time']),
nl2br($post['text'])
);
$entrys .= preg_replace($entry_keys,$entry_values,$tpl_entry);
}

$gb_tpl = get_tpl($gb_tpl,"guestbook:entry",$entrys);
if ($total > $kmess) {
$pagination = '<div class="pagination">'.preg_replace("#page\=([0-9]+)#is","$1.html",functions::display_pagination(functions::blog_link($bsite['url1'])."/guestbook/page/", $start, $total, $kmess)).'</div>';
}
else {
$pagination = false;
}
}
$form['back'] = $submit;
$form['action'] = functions::blog_link($bsite['url1'])."/guestbook.html";
if($user_id) {
$form['auth'] = '<a href="'.$set['homeurl'].'/exit.php?r='.urlencode(functions::blog_link($bsite['url1']).'/guestbook.html').'">Keluar</a>';
$form['name'] = $login;
$form['email'] = $datauser['mail'];
$form['site'] = $datauser['www'];
}
else {
$form['auth'] = '<a href="'.$set['homeurl'].'/login.php?r='.urlencode(functions::blog_link($bsite['url1']).'/guestbook.html').'" rel="nofollow">Masuk</a>';
$form['name'] = "";
$form['email'] = "";
$form['site'] = "";
}
$form_keys = array(
"#\{guestbook\:form\:auth\}#is",
"#\{guestbook\:form\:action\}#is",
"#\{guestbook\:form\:name\}#is",
"#\{guestbook\:form\:email\}#is",
"#\{guestbook\:form\:site\}#is",
"#\{site\:id\}#is",
"#\{guestbook\:form\:back\}#is",
"#\{guestbook\:form\:js\}#is"
);
$form_values = array(
$form['auth'],
$form['action'],
$form['name'],
$form['email'],
$form['site'],
"",
$form['back'],
""
);
$gb_form = preg_replace($form_keys,$form_values,get_tpl($gb_tpl,"guestbook:form"));
if ($cf_result)
$gb_form = str_ireplace("<form",$cf_result."<form",$gb_form);
if ($pagination) {
if (strpos($gb_tpl,"{pagination}") !== false) {
$html .= str_replace("{pagination}",$pagination,get_tpl($gb_tpl,"guestbook:form",$gb_form));
}
else {
$html .= get_tpl($gb_tpl.$pagination,"guestbook:form",$gb_form);
}
}
else {
$html .= str_replace("{pagination}","",get_tpl($gb_tpl,"guestbook:form",$gb_form));
}
$html .= get_tpl($tpl,"footer");
echo get_tpl_etc($html);