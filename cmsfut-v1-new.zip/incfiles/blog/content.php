<?php

defined('_IN_JOHNCMS') or die('Error');
$filename = strip_tags($_GET['filename']);
if (is_file("files/blogs/u".$bsite['user_id']."-b".$bsite['id']."-".$filename)) {
$file = "files/blogs/u".$bsite['user_id']."-b".$bsite['id']."-".$filename;
$name = $filename;
$ex = explode(".",$filename);
if(in_array($ex[1],array_keys($mime_types)))
$type = $mime_types[$ex[1]];
else
$type = "application/octet-stream";
} else { $file = "theme/default/images/logo.gif"; $name = "www.fastblog.net.gif"; $type = "image/gif";
}
header('Content-Description: File Transfer');
header('Content-Type: '.$type);    header('Content-Disposition: attachment; filename='.$name);
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' .filesize($file));
readfile($file);
exit;
