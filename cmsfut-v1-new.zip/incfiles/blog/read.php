<?php

defined('_IN_JOHNCMS') or die('Error');
$lastpost = false;
$permalink = trim($_GET['permalink']);
$q_tpl = get_tpl($tpl,"quote");
if ($q_tpl == "")
$q_tpl = '<fieldset style="border:1px solid red;"><legend style="padding: 0.2em 0.5em; border:1px solid red; color:green; font-size:90%; text-align:right;">{quote:name}</legend><div>{quote:message}</div></fieldset><br />';
$ptpl = get_tpl($tpl,"if:singlepost");
if ($bsite['user_id'] == $user_id) {
$preq = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id` = '".$bsite['id']."' AND `permalink` = '".mysql_real_escape_string($permalink)."' LIMIT 1"); } else { $preq = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id` = '".$bsite['id']."' AND `permalink` = '".mysql_real_escape_string($permalink)."' AND `draft`='no' LIMIT 1");
}
if (mysql_num_rows($preq) == 0) {
$html .= get_tpl($tpl,"header");
$html .= str_replace("{error:message}","Postingan tidak ditemukan.",get_tpl($tpl,"error"));
$html .= get_tpl($tpl,"footer");
}
else {
$post = mysql_fetch_array($preq);
if ($post['draft'] == "no") { if ($user_id) {
mysql_query("UPDATE `users` SET `place` = '".mysql_real_escape_string("bspost_".$post['id'])."', `lastdate` = '".time()."' WHERE `id` = '".$user_id."'"); } else {
$session = md5(core::$ip . core::$ip_via_proxy . core::$user_agent);
    $req = mysql_query("SELECT * FROM `cms_sessions` WHERE `session_id` = '".$session."' LIMIT 1");
    if (mysql_num_rows($req)) {
mysql_query("UPDATE `cms_sessions` SET `place` = '".mysql_real_escape_string("bspost_".$post['id'])."', `lastdate` = '".time()."' WHERE `session_id` = '".$session."'");
    } else {
mysql_query("INSERT INTO `cms_sessions` SET `session_id` = '".$session."', `ip` = '".core::$ip."', `ip_via_proxy` = '".core::$ip_via_proxy."', `browser` = '".mysql_real_escape_string($agn)."', `lastdate` = '".time()."', `sestime` = '".time()."', `place` = '".mysql_real_escape_string("bspost_".$post['id'])."'"); }
}
}
$post_author = mysql_query("SELECT `name`,`friends` FROM `users` WHERE `id`='".$post['user_id']."'");
$author = mysql_fetch_assoc($post_author);
if (strpos($author['friends'],"<".$user_id.">") !== false AND strpos($post['friend_views'],"<".$user_id.">") === false AND $post['time'] > (time() - (3600 * 48)))
$userviews = "<".$user_id.">".$post['friend_views'];
else
$userviews = $post['friend_views'];
if ($post['draft'] == "no") { if ($post['hits_today_date'] == date("d-m-Y",$tshift)) {
mysql_query("UPDATE `blog_posts` SET `friend_views` = '".mysql_real_escape_string($userviews)."', `hits_today` = `hits_today` + 1, `hits_total` = `hits_total` + 1, `lastview`='".time()."' WHERE `id`='".$post['id']."'");
}
else {
mysql_query("UPDATE `blog_posts` SET `friend_views` = '".mysql_real_escape_string($userviews)."', `hits_today` = 1, `hits_today_date` = '".date("d-m-Y",$tshift)."', `hits_total` = `hits_total` + 1, `lastview`='".time()."' WHERE `id`='".$post['id']."'");
}
}
if (strpos($author['friends'],"<".$user_id.">") !== false)
$is_friend = 1;
else
$is_friend = 0;

if ($post['privacy'] == "publics") {
$desc = $post['description'];
}
else {
if (!$user_id) {
$desc = "This post only for friends.";
}
else {
if ($bsite['user_id'] == $user_id || $is_friend == 1 || $rights == 9 || $rights == 7) {
$desc = $post['description'];
}
else {
$desc = "This post only for friends.";
}
}
}
$h_key = array("#{header:title}#is","#{header:description}#is","#{header:keywords}#is");
$h_val = array($post['title']." | ".$bsite['title'],substr(strip_tags($desc),0,200),str_replace("-"," ",$post['tags'])." ".$bsite_set[2]);
$html .= preg_replace($h_key,$h_val,get_tpl($tpl,"header"));


if (!isset($_SESSION['comm'])) {
$_SESSION['comm'] = md5(time().$post['id']);
}
$submit = $_SESSION['comm'];
$back = isset($_POST['back']) ? $_POST['back'] : md5(time());
if (($back == $submit OR isset($_POST[$submit])) AND $post['draft'] == "no") {
$cf_name = functions::checkin(strip_tags(rep_text($_POST['name'])));
$cf_email = functions::checkin(strip_tags(rep_text($_POST['email'])));
$cf_site = functions::checkin(strip_tags(rep_text($_POST['site'])));
$cf_msg = functions::checkin(rep_text($_POST['comment']));
$cf_ntf = $cf_msg;
require_once("incfiles/lib/htmlpurifier/HTMLPurifier.standalone.php");
$cfg = HTMLPurifier_Config::createDefault();
$cfg->set('Core.Encoding','UTF-8');
$cfg->set('Cache.DefinitionImpl',null);
$cfg->set('HTML.Doctype','XHTML 1.0 Transitional');
$cfg->set('HTML.Allowed','a[href],b,u,i,s,font[color]');
$cfg->set('Attr.EnableID',true);
$purifier = new HTMLPurifier($cfg);
$cf_msg = $purifier->purify($cf_msg);
if ($user_id) {
$flood = functions::antiflood();
if ($flood)
$error = $lng['error_flood']." ".$flood." ".$lng['seconds'];
$author_id = $user_id;
$cf_name = $datauser['name'];
if (strlen($cf_msg) < 2 OR strlen($cf_msg) > 5000)
$cf_error = "Komentar minimal 2 dan maksimal 5000 karakter.";
}
else {
$author_id = 0;
if (strlen($cf_msg) < 2 OR strlen($cf_msg) > 1024)
$cf_error = "Komentar minimal 2 dan maksimal 1024 karakter.";
}
if ($post['privacy'] == "publics" || $bsite['user_id'] == $user_id || $is_friend == 1 || $rights == 9 || $rights == 7) {
}
else {
$cf_error = "Anda tidak diijinkan berkomentar. Postingan ini hanya untuk teman.";
}
if (strlen($cf_name) < 2 OR strlen($cf_name) > 30)
$cf_error = "Nama minimal 2 dan maksimal 30 karakter.";
if ($bsite['user_id'] == $user_id || $rights == 9 || $rights == 7)
$cocap = "no";
else
$cocap = $bsite_set[6];
if (($cocap == "yes" OR !$user_id) AND empty($cf_error) AND (!isset($_POST['captcha']) OR $_SESSION['code'] != $_POST['captcha'])) {
unset($_SESSION['code']);
$form = '<form id="captcha_form" method="POST" action="http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'"><input type="hidden" name="name" value="'.htmlentities($cf_name).'"/><input type="hidden" name="email" value="'.htmlentities($cf_email).'"/><input type="hidden" name="site" value="'.htmlentities($cf_site).'"/><input type="hidden" name="comment" value="'.htmlentities($cf_msg).'"/><h3>Kode Keamanan</h3><img src="http://'.$_SERVER['HTTP_HOST'].'/captcha.php?r='.rand(1000,9999).'" border="1" alt="captcha"/><br />'.$lng['enter_code'].'<br /><input type="text" name="captcha" maxlength="5" size="5"/><br /><input type="submit" name="'.$submit.'" value="'.$lng['continue'].'"/></form>';
$html .= get_tpl(get_tpl($tpl,"if:post"),"post:entry",$form);
$html .= get_tpl($tpl,"footer");
echo get_tpl_etc($html);
exit;
}

if (empty($cf_error)) {
unset($_SESSION['comm']);
$submit = md5(time());
if ($bsite_set[5] == "yes" OR !$user_id) { $sts = "moderated"; } else { if (strpos($cf_msg,"http://") !== false) { if (count(explode("http://",$cf_msg)) > 5)
$sts = "spam";
else
$sts = "accepted"; } else {
$sts = "accepted"; } }
if ($bsite['user_id'] == $user_id || $rights == 9 || $rights == 7)
$sts = "accepted";
if ($sts == "accepted") { mysql_query("UPDATE `blog_posts` SET `comments` = `comments` + 1, `lastcomment`='".time()."' WHERE `id`='".$post['id']."'"); $cf_result = str_replace("{success:message}","Komentar Anda berhasil ditambahkan.",get_tpl($tpl,"success"));
} elseif ($sts == "moderated" OR $sts == "spam") { $cf_result = str_replace("{info:message}","Komentar Anda berhasil ditambahkan dan akan ditampilkan setelah disetujui Administrator.",get_tpl($tpl,"info")); }
if ($bsite['user_id'] == $user_id)
$read = 1;
else
$read = 0;
$notification = false;
if (strpos($_SERVER['REQUEST_URI'],"quote=") !== false) {
$pid = substr("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'],strlen(functions::blog_link($bsite['url1'])."/".$post['permalink'].".html?quote="));
if (ctype_digit($pid)) {
$pc = mysql_query("SELECT `id`,`author_id`,`author_name`,`text` FROM `blog_comments` WHERE `id`='".mysql_real_escape_string($pid)."' AND `post_id` = '".$post['id']."' AND `status`='accepted'");
if (mysql_num_rows($pc) > 0) { $cp = mysql_fetch_array($pc); $quote = $cp['author_name']."<!-- quote -->".$cp['text']; 
if($cp['author_id'] != $bsite['user_id'] AND $cp['author_id'] != 0 AND $cp['author_id'] != $user_id)
$notification = true;
} else { $quote = ""; } } else {  $quote = ""; } }
else { $quote = ""; }
mysql_query("INSERT INTO `blog_comments` SET `site_id`='".$bsite['id']."',`user_id`='".$bsite['user_id']."',`post_id`='".$post['id']."',`author_id`='".mysql_real_escape_string($author_id)."',`author_name`='".mysql_real_escape_string($cf_name)."',`author_email`='".mysql_real_escape_string($cf_email)."',`author_homepage`='".mysql_real_escape_string($cf_site)."',`quote`='".mysql_real_escape_string($quote)."',`text`='".mysql_real_escape_string(functions::smileys($cf_msg))."',`status`='".$sts."',`adminread`='".$read."',`time`='".time()."'");
$psid = mysql_insert_id();
if ($notification == true) {
$theme = "Balasan komentar";
$ntf = "[b]".$cf_name."[/b] membalas komentar Anda pada postingan [url=".functions::blog_link($bsite['url1'])."/".$post['permalink'].".html]".htmlspecialchars($post['title']." | ".$bsite['title'])."[/url]\r\n".$cf_ntf." [[url=".functions::blog_link($bsite['url1'])."/".$post['permalink'].".html?quote=".$psid."]Balas[/url]]";
mysql_query("INSERT INTO `cms_mail` SET
			    `user_id` = '0',
			    `from_id` = '" . $cp['author_id'] . "',
			    `text` = '" . mysql_real_escape_string($ntf) . "',
			    `time` = '" . time() . "',
			    `sys` = '1',
			    `them` = '" . mysql_real_escape_string($theme) . "'
			");
}
if ($user_id) {
mysql_query("UPDATE `users` SET `lastpost` = '" . time() . "' WHERE `id` = '" . $user_id . "'");
}
} else {
$cf_result = str_replace("{error:message}",$cf_error,get_tpl($tpl,"error"));
}
$lastpost = true;
}



if ($bsite['user_id'] == $user_id || $rights == 9 || $rights == 7) {
$desc = $desc.' [<a href="'.$set['homeurl'].'/panel-blog/index.php?act=edit_post&amp;post_id='.$post['id'].'">Edit</a> | <a href="'.$set['homeurl'].'/panel-blog/index.php?act=edit_post&amp;mod=delete&amp;post_id='.$post['id'].'">Hapus</a>]';
}
if (!empty($post['tags'])) {
if (strpos($post['tags'],",") !== false) {$tags = explode(",", $post['tags']);
foreach ($tags as $item) {
$istag[] = '<a href="' . functions::blog_link($bsite['url1']) . '/tag/' . $item . '/1.xhtml">' . str_replace('-', ' ', $item) . '</a>';
}
$tag = implode(", ",$istag);
}
else {
$tag = '<a href="'.functions::blog_link($bsite['url1']).'/tag/'.$post['tags'].'/1.xhtml">'.str_replace('-',' ',$post['tags']).'</a>';
}
}
else {
$tag = "";
}

$k_arr = array(
"#{singlepost:views}#is",
"#{singlepost:comments}#is",
"#{singlepost:tag}#is",
"#{singlepost:title}#is",
"#{singlepost:description}#is",
"#{singlepost:date}#is",
"#{singlepost:link}#is",
"#{singlepost:category}#is",
"#{singlepost:category:link}#is",
"#{singlepost:category:name}#is",
"#{singlepost:author}#is"
);
$cat = mysql_fetch_array(mysql_query("SELECT `name` FROM `blog_categories` WHERE `site_id`='".$bsite['id']."' AND `permalink`='".mysql_real_escape_string($post['category'])."'"));
$v_arr = array(
$post['hits_total'],
$post['comments'],
$tag,
$post['title'],
functions::smileys($desc),
functions::display_date($post['time']),
functions::blog_link($bsite['url1'])."/".$post['permalink'].".html",
"<a href=\"".functions::blog_link($bsite['url1'])."/category/".$post['category']."/1.html\">".htmlspecialchars($cat['name'])."</a>",
functions::blog_link($bsite['url1'])."/category/".$post['category']."/1.html",
htmlspecialchars($cat['name']),
"<a href=\"".$set['homeurl']."/users/profile.php?user=".$post['user_id']."\">".rep_text($author['name'])."</a>"
);
$sphtml = preg_replace($k_arr,$v_arr,$ptpl);
$count_related = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_posts` WHERE `site_id`='".$bsite['id']."' AND `category`='".mysql_real_escape_string($post['category'])."' AND `draft`='no'"),0);
if ($count_related == 0) {
$sphtml = get_tpl($sphtml,"singlepost:related","<!-- related posts -->");
}
else {
$r_que = mysql_query("SELECT `title`,`permalink`,`time` FROM `blog_posts` WHERE `site_id`='".$bsite['id']."' AND `category`='".mysql_real_escape_string($post['category'])."' AND `draft`='no' ORDER BY `time` DESC LIMIT 5");
$r_tpl = get_tpl($sphtml,"singlepost:related");
$r_entry_tpl = get_tpl($r_tpl,"singlepost:related:entry");
while($related = mysql_fetch_assoc($r_que)) {
$r_keys = array("#\{singlepost\:related\:entry\:link\}#is","#\{singlepost\:related\:entry\:title\}#is");
$r_values = array(functions::blog_link($bsite['url1'])."/".$related['permalink'].".html",$related['title']);
$entrys .= preg_replace($r_keys,$r_values,$r_entry_tpl);
}
$rtpl = get_tpl($r_tpl,"singlepost:related:entry",$entrys);
$sphtml = get_tpl($sphtml,"singlepost:related",$rtpl);
}
$xhtml = $sphtml;
$count_comments = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_comments` WHERE `site_id`='".$bsite['id']."' AND `post_id`='".$post['id']."' AND `status`='accepted'"),0);
$com_tpl = get_tpl($sphtml,"singlepost:comment");
if ($count_comments == 0) {
$com_tpl = get_tpl($com_tpl,"singlepost:comment:entry",str_replace("{info:message}","Belum ada komentar.",get_tpl($tpl,"info")));
}
else {
$com_entry_tpl = get_tpl($com_tpl,"singlepost:comment:entry");
$com_que = mysql_query("SELECT * FROM `blog_comments` WHERE `site_id`='".$bsite['id']."' AND `post_id`='".$post['id']."' AND `status`='accepted' ORDER BY `time` ASC");
while($comment = mysql_fetch_assoc($com_que)) {
$com_keys = array("#{singlepost:comment:entry:id}#is","#{singlepost:comment:entry:homepage}#is","#{singlepost:comment:entry:userid}#is","#{singlepost:comment:entry:name}#is","#{singlepost:comment:entry:date}#is","#{singlepost:comment:entry:message}#is");
if (substr($_SERVER['REQUEST_URI'],"-".strlen("quote=".$comment['id'])) == "quote=".$comment['id'] AND $lastpost == false) {
$cotext = $comment['text'];
$com_values = array($comment['id'],$comment['author_homepage'],$comment['author_id'],$comment['author_name'],functions::display_date($comment['time']),nl2br($cotext));
$com_entrys .= preg_replace($com_keys,$com_values,$com_entry_tpl);
} else { 
if (strpos($_SERVER['REQUEST_URI'],"quote=") !== false AND $lastpost == false) {
$com_entrys .= "<!-- hidden -->";
}
else {
if ($comment['quote'] != "") {
$qu = explode("<!-- quote -->",$comment['quote']);
$quot = str_replace("{quote:name}",$qu[0],str_replace("{quote:message}",$qu[1],$q_tpl));
} else {
$quot = ""; }
$cotext = $quot.$comment['text'].' <a class="reply" href="'.functions::blog_link($bsite['url1']).'/'.$post['permalink'].'.html?quote='.$comment['id'].'">[Balas]</a>';
$com_values = array($comment['id'],$comment['author_homepage'],$comment['author_id'],$comment['author_name'],functions::display_date($comment['time']),nl2br($cotext));
$com_entrys .= preg_replace($com_keys,$com_values,$com_entry_tpl);
}
}
}
$com_tpl = get_tpl($com_tpl,"singlepost:comment:entry",$com_entrys);
}


if ($lastpost == false)
$comform['action'] = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
else
$comform['action'] = functions::blog_link($bsite['url1'])."/".$post['permalink'].".html";
if ($user_id) {
$comform['auth'] = '<a
href="'.$set['homeurl'].'/exit.php?r='.urlencode(functions::blog_link($bsite['url1'])."/".$post['permalink'].".html#comment_form").'" rel="nofollow">Keluar</a>';
$comform['name'] = rep_text(strip_tags($datauser['name']));
$comform['site'] = rep_text(strip_tags($datauser['www']));
$comform['email'] = rep_text($datauser['mail']);
$comform['captcha'] = "";
}
else {
$comform['auth'] = '<a
href="'.$set['homeurl'].'/login.php?r='.urlencode(functions::blog_link($bsite['url1'])."/".$post['permalink'].".html#comment_form").'" rel="nofollow">Masuk</a>';
$comform['name'] = "";
$comform['site'] = "";
$comform['email'] = "";
$comform['captcha'] = "";
}
$comform['submit'] = $submit;
$comform['secure'] = "http://".$_SERVER['HTTP_HOST']."/captcha.php?r=".rand(1000,9999);
$comform['blogid'] = "";
$comform['back'] = $submit;
$k_arr = array("#\{singlepost\:comment\:form\:js\}#is","#\{singlepost\:comment\:form\:submit\}#is","#\{singlepost\:comment\:form\:captcha\}#is","#\{singlepost\:comment\:form\:secure\}#is","#\{singlepost\:comment\:form\:auth\}#is","#\{singlepost\:comment\:form\:action\}#is","#\{singlepost\:comment\:form\:name\}#is","#\{singlepost\:comment\:form\:site\}#is","#\{singlepost\:comment\:form\:email\}#is","#\{singlepost\:comment\:form\:blogid\}#is","#\{singlepost\:comment\:form\:back\}#is");
$v_arr = array("",$comform['submit'],$comform['captcha'],$comform['secure'],$comform['auth'],$comform['action'],$comform['name'],$comform['site'],$comform['email'],$comform['blogid'],$comform['back']);
$com_form_tpl = get_tpl($com_tpl,"singlepost:comment:form");
if ($cf_result)
$com_form_tpl = str_ireplace("<form",$cf_result."<form",$com_form_tpl);

$com_form_tpl = preg_replace($k_arr,$v_arr,$com_form_tpl);
$com_tpl = get_tpl($com_tpl,"singlepost:comment:form",$com_form_tpl);

$sphtml = get_tpl($sphtml,"singlepost:comment",$com_tpl);
if ($post['privacy'] == "publics" || $bsite['user_id'] == $user_id || $is_friend == 1 || $rights == 9 || $rights == 7) {
$html .= $sphtml;
}
else {
$html .= get_tpl($xhtml,"singlepost:comment","<!-- comment -->");
}
$html .= get_tpl($tpl,"footer");
}
echo get_tpl_etc($html);
?>