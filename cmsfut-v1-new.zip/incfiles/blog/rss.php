<?php

defined('_IN_JOHNCMS') or die('Error');
$tshift = $set['timeshift'] * 3600;
if ($mod=="comments"){
$title = "Komentar: ".$bsite['title'];
$link = functions::blog_link($bsite['url1']);
$description = $bsite_set[0];
$pubDate = date("r",(time()+$tshift));
$query = mysql_query("SELECT * FROM `blog_comments` WHERE `site_id` = '".$bsite['id']."' AND `post_id`!='0' AND `status`='accepted' ORDER BY `time` DESC LIMIT 15;");
if (mysql_num_rows($query) == 0) {$item="";} else { while ($res = mysql_fetch_assoc($query)) { $post = mysql_fetch_assoc(mysql_query("SELECT `title`,`permalink`,`privacy` FROM `blog_posts` WHERE `id`='".$res['post_id']."'"));
if($post['privacy']!="publics"){if(!$user_id){$co=0;} else {if(strpos($datauser['friends'],"<".$res['user_id'].">")!==false OR $user_id==$bsite['user_id'] OR $rights==9 OR $rights==7)$co=1; else $co=0;}} else {$co = 1;}
if ($co = 1)
$item .= '<item><title>'.htmlspecialchars($res['author_name'].": ".$post['title'], ENT_QUOTES).'</title><link>'.functions::blog_link($bsite['url1']).'/'.$post['permalink'].'.html</link><pubDate>'.date('r',($res['time']+$tshif)).'</pubDate><description><![CDATA['.functions::smileys(nl2br($res['text'])).']]></description></item>'; else $item .= "";
}}
} elseif($mod=="post_comments"){
$q = mysql_query("SELECT `id`,`title`,`description`,`permalink`,`privacy`,`time` FROM `blog_posts` WHERE `site_id` = '".$bsite['id']."' AND `permalink`='".mysql_real_escape_string($_GET['permalink'])."' AND `draft`='no'");
if (mysql_num_rows($q) == 0) {$title = "Komentar: ".$bsite['title'];
$link = functions::blog_link($bsite['url1']);
$description = $bsite_set[0];
$item="";} else {$post=mysql_fetch_array($q);$title = "Komentar: ".$post['title'];
$link = functions::blog_link($bsite['url1'])."/".$post['permalink'].".html";
if($post['privacy']!="publics"){if(!$user_id){$co=0;} else {if(strpos($datauser['friends'],"<".$res['user_id'].">")!==false OR $user_id==$bsite['user_id'] OR $rights==9 OR $rights==7)$co=1; else $co=0;}} else {$co = 1;}
if ($co==1)
$description = $post['description'];
else
$description = 'Postingan ini hanya untuk Teman';
$pubDate = date("r",($post['time']+$tshift));
if ($co=0) { $item="";} else {$query = mysql_query("SELECT * FROM `blog_comments` WHERE `post_id` = '".$post['id']."' AND `status`='accepted' ORDER BY `time` DESC LIMIT 15;");
if (mysql_num_rows($query) == 0) { $item="";} else { while ($res = mysql_fetch_assoc($query)) {
$item .= '<item><title>'.htmlspecialchars($res['author_name'].": ".$post['title'], ENT_QUOTES).'</title><link>'.functions::blog_link($bsite['url1']).'/'.$post['permalink'].'.html</link><pubDate>'.date('r',($res['time']+$tshif)).'</pubDate><description><![CDATA['.functions::smileys(nl2br($res['text'])).']]></description></item>';}}}}} else {
$title = $bsite['title'];
$link = functions::blog_link($bsite['url1']);
$description = $bsite_set[0];
$pubDate = date("r",(time()+$tshift));
$query = mysql_query("SELECT * FROM `blog_posts` WHERE `site_id` = '".$bsite['id']."' AND `draft`='no' ORDER BY `time` DESC LIMIT 15;");
if (mysql_num_rows($query) == 0) {$item="";} else { while ($res = mysql_fetch_assoc($query)) { $item .= '<item><title>'.htmlspecialchars($res['title'], ENT_QUOTES).'</title><link>'.functions::blog_link($bsite['url1']).'/'.$res['permalink'].'.html</link><pubDate>'.date('r', $res['time']).'</pubDate>';
if($res['privacy']!="publics"){if(!$user_id){$des="Postingan ini hanya untuk Teman.";} else {if(strpos($datauser['friends'],"<".$res['user_id'].">")!==false OR $user_id==$bsite['user_id'] OR $rights==9 OR $rights==7)$des=$res['description']; else $des="Postingan ini hanya untuk Teman.";}} else {$des = $res['description'];}
$item .= '<description><![CDATA['.functions::smileys($des).']]></description></item>';}}
}

header("Content-Type: application/xml");
echo '<?xml version="1.0" encoding="iso-8859-1"?><rss version="2.0"
xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:wfw="http://wellformedweb.org/CommentAPI/"
><channel><title>'.htmlentities($title, ENT_QUOTES).'</title>
<link>'.$link.'</link><description><![CDATA['.htmlentities(strip_tags($description), ENT_QUOTES).']]></description><pubDate>'.$pubDate.'</pubDate>';
echo $item;
echo '</channel></rss>';
?>
