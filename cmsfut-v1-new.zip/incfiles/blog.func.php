<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');
function filter_user1($tpl) {
global $user_id;
if ($user_id)
return $tpl;
else
return "";
}
function filter_user2($tpl) {
global $user_id;
if (!$user_id)
return $tpl;
else
return "";
}
function get_thumb($text,$w=60,$h=80,$default_thumb=false) { if (strpos($text,'<img src="') !== false) { $x = explode("<img src=\"",$text);
$y = explode('"',$x[1]);
return '<img class="thumb" src="'.$y[0].'" width="'.$w.'" height="'.$h.'" alt=""/> '; } else {
if($default_thumb==false)
return "";
else
return '<img class="thumb" src="'.$default_thumb.'" width="'.$w.'" height="'.$h.'" alt=""/> ';}}

function rep_text($text,$re=false){ if ($re == false)
return str_replace("{","{ ",str_replace("}"," }",$text));
else
return str_replace("{ ","{",str_replace(" }","}",$text)); }

function get_tpl($tpl_file,$item,$replace="") { if(strpos($tpl_file,"{".$item."}") === false OR strpos($tpl_file,"{/".$item."}") === false)
$tpl_file = "<!-- template error -->";
if ($replace == "") { $tpl = preg_replace("#(.*)\{".$item."\}(.*)\{\/".$item."\}(.*)#is","$2",$tpl_file); }
else { $tpl = preg_replace("#(.*)\{".$item."\}(.*)\{\/".$item."\}(.*)#is","$1".$replace."$3",$tpl_file); }
return $tpl; }

function get_tpl_etc($tpl) {
global $set,$bsite,$bsite_set,$user_id,$datauser,$login;

// start modul lastviews
if (strpos($tpl,"{modul:lastviews}") !== false AND strpos($tpl,"{/modul:lastviews}") !== false) {
$lvw_q = mysql_query("SELECT `title`,`permalink` FROM `blog_posts` WHERE `site_id`='".$bsite['id']."' AND `draft`='no' ORDER BY `lastview` DESC LIMIT 5;");
if (mysql_num_rows($lvw_q) > 0 AND strpos($bsite['moduls'],"<lastviews>") !== false) { $lvw_tpl = get_tpl($tpl,"modul:lastviews");
$lvw_tpl_e = get_tpl($lvw_tpl,"lastviews:entry");
while($lvw_r=mysql_fetch_array($lvw_q)) { $lvw_e .= str_replace("{lastviews:entry:link}",$bsite['url']."/".$lvw_r['permalink'].".html",str_replace("{lastviews:entry:title}",htmlspecialchars($lvw_r['title']),$lvw_tpl_e));
}
$lvw_tpl = get_tpl($lvw_tpl,"lastviews:entry",$lvw_e);
$tpl = get_tpl($tpl,"modul:lastviews",$lvw_tpl); } else { $tpl = get_tpl($tpl,"modul:lastviews","<!-- modul lastviews hidden -->"); }
}
// end modul lastviews


// start modul lastcommented
if (strpos($tpl,"{modul:lastcommented}") !== false AND strpos($tpl,"{/modul:lastcommented}") !== false) {
$lcm_q = mysql_query("SELECT `title`,`permalink` FROM `blog_posts` WHERE `site_id`='".$bsite['id']."' AND `draft`='no' ORDER BY `lastcomment` DESC LIMIT 5;");
if (mysql_num_rows($lcm_q) > 0 AND strpos($bsite['moduls'],"<lastcommented>") !== false) { $lcm_tpl = get_tpl($tpl,"modul:lastcommented");
$lcm_tpl_e = get_tpl($lcm_tpl,"lastcommented:entry");
while($lcm_r=mysql_fetch_array($lcm_q)) { $lcm_e .= str_replace("{lastcommented:entry:link}",$bsite['url']."/".$lcm_r['permalink'].".html",str_replace("{lastcommented:entry:title}",htmlspecialchars($lcm_r['title']),$lcm_tpl_e));
}
$lcm_tpl = get_tpl($lcm_tpl,"lastcommented:entry",$lcm_e);
$tpl = get_tpl($tpl,"modul:lastcommented",$lcm_tpl); } else { $tpl = get_tpl($tpl,"modul:lastcommented","<!-- modul lastcommented hidden -->"); }
}
// end modul lastcommented


// start modul topcomments
if (strpos($tpl,"{modul:topcomments}") !== false AND strpos($tpl,"{/modul:topcomments}") !== false) {
$tc_q = mysql_query("SELECT `title`,`permalink` FROM `blog_posts` WHERE `site_id`='".$bsite['id']."' AND `draft`='no' ORDER BY `comments` DESC LIMIT 5;");
if (mysql_num_rows($tc_q) > 0 AND strpos($bsite['moduls'],"<topcomments>") !== false) { $tc_tpl = get_tpl($tpl,"modul:topcomments");
$tc_tpl_e = get_tpl($tc_tpl,"topcomments:entry");
while($tc_r=mysql_fetch_array($tc_q)) { $tc_e .= str_replace("{topcomments:entry:link}",$bsite['url']."/".$tc_r['permalink'].".html",str_replace("{topcomments:entry:title}",htmlspecialchars($tc_r['title']),$tc_tpl_e));
}
$tc_tpl = get_tpl($tc_tpl,"topcomments:entry",$tc_e);
$tpl = get_tpl($tpl,"modul:topcomments",$tc_tpl); } else { $tpl = get_tpl($tpl,"modul:topcomments","<!-- modul topcomments hidden -->"); }
}
// end modul topcomments

// start modul topviews
if (strpos($tpl,"{modul:topviews}") !== false AND strpos($tpl,"{/modul:topviews}") !== false) {
$tv_q = mysql_query("SELECT `title`,`permalink` FROM `blog_posts` WHERE `site_id`='".$bsite['id']."' AND `draft`='no' ORDER BY `hits_total` DESC LIMIT 5;");
if (mysql_num_rows($tv_q) > 0 AND strpos($bsite['moduls'],"<topviews>") !== false) { $tv_tpl = get_tpl($tpl,"modul:topviews");
$tv_tpl_e = get_tpl($tv_tpl,"topviews:entry");
while($tv_r=mysql_fetch_array($tv_q)) { $tv_e .= str_replace("{topviews:entry:link}",$bsite['url']."/".$tv_r['permalink'].".html",str_replace("{topviews:entry:title}",htmlspecialchars($tv_r['title']),$tv_tpl_e));
}
$tv_tpl = get_tpl($tv_tpl,"topviews:entry",$tv_e);
$tpl = get_tpl($tpl,"modul:topviews",$tv_tpl); } else { $tpl = get_tpl($tpl,"modul:topviews","<!-- modul topviews hidden -->"); }
}
// end modul topviews

$tpl = preg_replace(array('#\{if\:user\}(.*?)\{\/if\:user\}#si'), array(filter_user1('$1')), $tpl);
$tpl = preg_replace(array('#\{if\:notuser\}(.*?)\{\/if\:notuser\}#si'), array(filter_user2('$1')), $tpl);
$tpl = preg_replace("#\{following\}(.*)\{\/following\}#is","",$tpl);

if (preg_match("#\{shoutbook\}#i",$tpl) AND preg_match("#\{\/shoutbook\}#i",$tpl)) { $sb_tpl = get_tpl($tpl,"shoutbook");
$total_gb = mysql_result(mysql_query("SELECT COUNT(*) FROM `blog_comments` WHERE `user_id` = '".$bsite['user_id']."' AND `post_id` = '0' AND `status` = 'accepted'"),0);
if ($total_gb == 0) { $sb = "<!-- shoutbook empty -->"; } else { $stpl = get_tpl($sb_tpl,"shoutbook:entry");
$req = mysql_query("SELECT `author_id`,`author_name`,`author_homepage`,`text`,`time` FROM `blog_comments` WHERE `user_id` = '".$bsite['user_id']."' AND `post_id` = '0' AND `status` = 'accepted' ORDER BY `time` DESC LIMIT 3");
while ($res = mysql_fetch_array($req)) { $sk_arr = array("#\{shoutbook\:entry\:userid\}#is","#\{shoutbook\:entry\:homepage\}#is","#\{shoutbook\:entry\:name\}#is","#\{shoutbook\:entry\:date\}#is","#\{shoutbook\:entry\:message\}#is");
$sv_arr = array($res['author_id'],$res['author_homepage'],$res['author_name'],functions::display_date($res['time']),functions::smileys(nl2br($res['text'])));
$sb .= preg_replace($sk_arr,$sv_arr,$stpl); } }
$s_tpl = get_tpl($sb_tpl,"shoutbook:entry",$sb);
$tpl = get_tpl($tpl,"shoutbook",$s_tpl); }

/*
if (preg_match("#\{if\:user\}#i",$tpl) AND preg_match("#\{\/if\:user\}#i",$tpl)) { $uex = explode("{/if:user}",$tpl);
for($i=0;$i<count($uex);$i++) { if ($user_id) { $foruser = get_tpl($uex[$i]."{/if:user}","if:user");
$ustpl .= get_tpl($uex[$i]."{/if:user}","if:user",$foruser); } else { $ustpl .= get_tpl($uex[$i]."{/if:user}","if:user","<!-- hidden -->");
} } $tpl = $ustpl; }

if (preg_match("#\{if\:notuser\}#i",$tpl) AND preg_match("#\{\/if\:notuser\}#i",$tpl)) { $gex = explode("{/if:notuser}",$tpl);
for($i=0;$i<count($gex);$i++) { if (!$user_id) { $forguest = get_tpl($gex[$i]."{/if:notuser}","if:notuser");
$gstpl .= get_tpl($gex[$i]."{/if:notuser}","if:notuser",$forguest); }
else { $gstpl .= get_tpl($gex[$i]."{/if:notuser}","if:notuser","<!-- hidden -->"); } }
$tpl = $gstpl; }
*/
if (strpos($tpl,"{navigation}") !== false AND strpos($tpl,"{/navigation}") !== false) { if (empty($bsite['navigations'])) { $tpl = get_tpl($tpl,"navigation","<!-- navigation -->"); } else { $nav_tpl = get_tpl($tpl,"navigation");
$expn = explode("^",$bsite['navigations']);
if ($expn == false) { $ntpl = str_replace("{navigation:entry:code}",$bsite['navigations'],get_tpl($nav_tpl,"navigation:entry"));
$ntpl = get_tpl($nav_tpl,"navigation:entry",$ntpl);
$tpl = get_tpl($tpl,"navigation",$ntpl); } else { $nxtpl = get_tpl($nav_tpl,"navigation:entry");
foreach($expn as $nav) { $nvtpl .= str_replace("{navigation:entry:code}",$nav,$nxtpl); }
$ntpl = get_tpl($nav_tpl,"navigation:entry",$nvtpl);
$tpl = get_tpl($tpl,"navigation",$ntpl); } } }

if (strpos($tpl,"{category}") !== false AND strpos($tpl,"{/category}") !== false) { $c_tpl = get_tpl($tpl,"category");
$c_entry_tpl = get_tpl($c_tpl,"category:entry");
$c_que = mysql_query("SELECT * FROM `blog_categories` WHERE `site_id` = '".$bsite['id']."' ORDER BY `name` ASC");
while($cat = mysql_fetch_assoc($c_que)) { $count_posts = $cat['counts'];
$c_keys = array("#\{category\:entry\:count\}#is","#\{category\:entry\:link\}#is","#\{category\:entry\:name\}#is");
$c_values = array($count_posts,functions::blog_link($bsite['url1'])."/category/".$cat['permalink']."/1.html",strip_tags(rep_text($cat['name'])));
$c_entry .= preg_replace($c_keys , $c_values, $c_entry_tpl); }
$ctpl = get_tpl($c_tpl,"category:entry",$c_entry);
$tpl = get_tpl($tpl,"category",$ctpl); }

if ($user_id){$uid=$user_id;$uname=$datauser['name'];$usite=$datauser['www'];} else {$uid=0;$uname=$login;$usite="";}
$k_arr = array(
"#\{user\:id\}#is",
"#\{user\:name\}#is",
"#\{user\:site\}#is",
"#\{site\:id\}#is",
"#\{site\:url\}#is",
"#\{site\:icon\}#is",
"#\{site\:logo\}#is",
"#\{site\:name\}#is",
"#\{site\:statistics\:today\}#is",
"#\{site\:statistics\:all\}#is",
"#\{site\:description\}#is",
"#\{header\:title\}#is",
"#\{header\:keywords\}#is",
"#\{header\:description\}#is",
"#\{site\:metagoogle\}#is"
);
$v_arr = array(
$uid,
$uname,
$usite,
$bsite['user_id'],
functions::blog_link($bsite['url1']),
$bsite_set[1],
'<img src="'.$bsite_set[3].'" alt="Logo"/>',
$bsite['title'],
$bsite['hits_today'],
$bsite['hits_total'],
$bsite_set[0],
$bsite['title'],
$bsite_set[2],
$bsite_set[0],
$bsite_set[4]
);
$tpl = preg_replace($k_arr,$v_arr,$tpl);
$a_arr = array("#\{post\:pagination\}#is","#\{\/if\:user\}#is","#\{\/if\:notuser\}#is");
$b_arr = array("","","");
return preg_replace($a_arr,$b_arr,$tpl);
}