<?php

defined('_IN_JOHNCMS') or die('Restricted access');

class counters
{ 
/* update time ago */
static function update_time($jam) {
global $set_user;
$realtime = time();
$lng_time = core::load_lng('time');
$waktu = $jam + ($set_user['sdvig'] * 3600);
$waktu = $jam + ($set_user['sdvig'] * 3600);
$lama=round(($realtime-$waktu)/60);
if($lama==0){
$lama= $lng_time['just_now'];
}
if($lama >0 && $lama < 60){
$lama= ''.$lama.' '.$lng_time['minutes_ago'].'';
}
if($lama>=60*1 && $lama<60*24){
$lama=round($lama/60);
$lama=''.$lama.' '.$lng_time['hours_ago'].'';
}
// Jika lebih dari 24 jam
if($lama>=60*24*1 && $lama<60*24*2){
$lama= $lng_time['yesterday'];
}
// Jika lebih dari 2 hari
if($lama>=60*24*2 && $lama <=60*24*7){
$lama =round($lama/60/24);
$lama = ''.$lama.' '.$lng_time['days_ago'].'';
}
if($lama>=60*24*7 && $lama <=60*24*30) {
$lama =round($lama/60/24/7);
$lama = ''.$lama.' '.$lng_time['weeks_ago'].'';
}
if($lama>=60*24*30*1 && $lama <=60*24*30*12) {
$lama =round($lama/60/24/30);
$lama = ''.$lama.' '.$lng_time['months_ago'].'';
}
if($lama>=60*24*30*12){
$lama = date("d F Y", $waktu);
}
return $lama;
}

    // Foto album 
    static function album() 
    { 
        global $rootpath; 
        $file = $rootpath . 'files/cache/count_album.dat'; 
        if (file_exists($file) && filemtime($file) > (time() - 600)) {
            $res = unserialize(file_get_contents($file));
            $album = $res['album'];
            $photo = $res['photo'];
            $new = $res['new'];
        } else {
            $album = mysql_result(mysql_query("SELECT COUNT(DISTINCT `user_id`) FROM `cms_album_files`"), 0);
            $photo = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files`"), 0);
            $new = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_album_files` WHERE `time` > '" . (time() - 259200) . "' AND `access` > '1'"), 0);
            file_put_contents($file, serialize(array('album' => $album, 'photo' => $photo, 'new' => $new)));
        }
        return $album . '&#160;/&#160;' .$photo . ($new ? '&#160;/&#160;<span class="red"><a href="' . core::$system_set['homeurl'] . '/users/album.php?act=top">+' . $new . '</a></span>' : '');
    }

   // Berbagi File
    static function archive()
    {
        $file = ROOTPATH . 'files/cache/count_archive.dat';
        if (file_exists($file) && filemtime($file) > (time() - 900)) {
            $res = unserialize(file_get_contents($file));
            $total = $res['total'];
            $new = $res['new'];
        } else {
            $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `erik_berbagi` WHERE `type` = 'file'"), 0);
            $new = mysql_result(mysql_query("SELECT COUNT(*) FROM `erik_berbagi` WHERE `time` > '" . (time() - 259200) . "' AND `type` = 'file'"), 0);
            file_put_contents($file, serialize(array('total' => $total, 'new' => $new)));
        }
        if ($new) $total .= '&#160;/&#160;<span class="red"><a href="/archive/?act=new">+' . $new . '</a></span>';
        return $total;
    }

    // Forum
    static function forum()
    {
        global $rootpath;
        $file = $rootpath . 'files/cache/count_forum.dat';
        $new = '';
        if (file_exists($file) && filemtime($file) > (time() - 600)) {
            $res = unserialize(file_get_contents($file));
            $top = $res['top'];
            $msg = $res['msg'];
        } else {
            $top = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 't' AND `close` != '1'"), 0);
            $msg = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type` = 'm' AND `close` != '1'"), 0);
            file_put_contents($file, serialize(array('top' => $top, 'msg' => $msg)));
        }
        if (core::$user_id && ($new_msg = self::forum_new()) > 0) {
            $new = '&#160;/&#160;<span class="red"><a href="' . core::$system_set['homeurl'] . '/forum/index.php?act=new">+' . $new_msg . '</a></span>';
        }
        return $top . '&#160;/&#160;' . $msg . $new;
    }

    // Topik baru
    static function forum_new($mod = 0)
    {
        if (core::$user_id) {
            $req = mysql_query("SELECT COUNT(*) FROM `forum`
                LEFT JOIN `cms_forum_rdm` ON `forum`.`id` = `cms_forum_rdm`.`topic_id` AND `cms_forum_rdm`.`user_id` = '" . core::$user_id . "'
                WHERE `forum`.`type`='t'" . (core::$user_rights >= 7 ? "" : " AND `forum`.`close` != '1'") . "
                AND (`cms_forum_rdm`.`topic_id` Is Null
                OR `forum`.`time` > `cms_forum_rdm`.`time`)");
            $total = mysql_result($req, 0);
            if ($mod)
                return '<a href="index.php?act=new">' . core::$lng['unread'] . '</a>&#160;' . ($total ? '<span class="red">(<b>' . $total . '</b>)</span>' : '');
            else
                return $total;
        } else {
            if ($mod)
                return '<a href="index.php?act=new">' . core::$lng['last_activity'] . '</a>';
            else
                return false;
        }
    }

    // Galeri
    static function gallery($mod = 0)
    {
        $new = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery` WHERE `time` > '" . (time() - 259200) . "' AND `type` = 'ft'"), 0);
        if ($mod == 0) {
            $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery` WHERE `type` = 'ft'"), 0);
            $out = $total;
            if ($new > 0)
                $out .= '&#160;/&#160;<span class="red"><a href="/gallery/index.php?act=new">+' . $new . '</a></span>';
        } else {
            $out = $new;
        }
        return $out;
    }

    // Buku tamu
    static function guestbook($mod = 0,$type = 0)
    {
        $count = 0;
        switch ($mod) {
            case 1:
                $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='0' AND `time` > '" . (time() - 86400) . "' AND `type` = '".$type."'"), 0);
                break;

            case 2:
                if (core::$user_rights >= 1)
                    $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='1' AND `time` > '" . (time() - 86400) . "' AND `type` = '".$type."'"), 0);
                break;

            default:
                $count = mysql_result(mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='0' AND `time` > '" . (time() - 86400) . "' AND `type` = '".$type."'"), 0);
                if (core::$user_rights >= 1) {
                    $req = mysql_query("SELECT COUNT(*) FROM `guest` WHERE `adm`='1' AND `time`>'" . (time() - 86400) . "' AND `type` = '".$type."'");
                    $count = $count . '&#160;/&#160;<span class="red"><a href="guestbook/index.php?act=ga&amp;do=set">' . mysql_result($req, 0) . '</a></span>';
                }
        }
        return $count;
    }

    // Perpustakaan

    static function library()
    {
        $file = ROOTPATH . 'files/cache/count_library.dat';
        if (file_exists($file) && filemtime($file) > (time() - 3200)) {
            $res = unserialize(file_get_contents($file));
            $total = $res['total'];
            $new = $res['new'];
            $mod = $res['mod'];
        } else {
            $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `library_texts` WHERE `premod` = '1'"), 0);
            $new = mysql_result(mysql_query("SELECT COUNT(*) FROM `library_texts` WHERE `time` > '" . (time() - 259200) . "' AND `premod` = '1'"), 0);
            $mod = mysql_result(mysql_query("SELECT COUNT(*) FROM `library_texts` WHERE `premod` = '0'"), 0);
            file_put_contents($file, serialize(array('total' => $total, 'new' => $new, 'mod' => $mod)));
        }
        if ($new) $total .= '&#160;/&#160;<span class="red"><a href="' . core::$system_set['homeurl'] . '/library/index.php?act=new">+' . $new . '</a></span>';
        if ((core::$user_rights == 5 || core::$user_rights >= 6) && $mod) {
            $total .= '&#160;/&#160;<span class="red"><a href="' . core::$system_set['homeurl'] . '/library/index.php?act=premod">M:' . $mod . '</a></span>';
        }
        return $total;
    }

    // Pengguna aktif
    static function online()
    {
        $users = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `lastdate` > '" . (time() - 300) . "'"), 0);
        $guests = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_sessions` WHERE `lastdate` > '" . (time() - 300) . "'"), 0);
        return (core::$user_id || core::$system_set['active'] ? '<a href="' . core::$system_set['homeurl'] . '/users/index.php?act=online">' . functions::image('menu_online.png') . $users . ' / ' . $guests . '</a>' : core::$lng['online'] . ': ' . $users . ' / ' . $guests);
    }

    // Toko

  static function store()
  {
      $total = mysql_result(mysql_query("select count(*) from `store_categories`"), 0);
      $goods = mysql_result(mysql_query("select count(*) from `store_goods`"), 0);
      if ($goods)
          $total .= '&nbsp;/&nbsp;' . $goods;
      $new = mysql_result(mysql_query("select count(*) from `store_goods` where `time` > " . (time() - 3600 * 24) . ";"), 0);
      if ($new)
          $total .= '&nbsp;/&nbsp;<span class="red"><a href="store/index.php?act=new">+' . $new . '</a></span>';
      return $total;
  }

    // Pengguna
    static function users()
    {
        global $rootpath;
        $file = $rootpath . 'files/cache/count_users.dat';
        if (file_exists($file) && filemtime($file) > (time() - 600)) {
            $res = unserialize(file_get_contents($file));
            $total = $res['total'];
            $new = $res['new'];
        } else {
            $total = mysql_result(mysql_query("SELECT COUNT(*) FROM `users`"), 0);
            $new = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `datereg` > '" . (time() - 86400) . "'"), 0);
            file_put_contents($file, serialize(array('total' => $total, 'new' => $new)));
        }
        if ($new) $total .= '&#160;/&#160;<span class="red">+' . $new . '</span>';
        return $total;
    }
}