<?php

// ANTI XSS

defined('_IN_JOHNCMS') or die('FORBIDDEN');
require_once($rootpath."incfiles/lib/htmlpurifier/HTMLPurifier.standalone.php");
$cfg = HTMLPurifier_Config::createDefault();
$cfg->set('Core.Encoding','UTF-8');
$cfg->set('Cache.DefinitionImpl',null);
$cfg->set('HTML.Doctype','XHTML 1.0 Transitional');
$cfg->set('HTML.Allowed','abbr[id|class|style|title],address[id|class|style],button[id|class|style|value],caption[id|class|style],cite[id|class|style],code[id|class|style],col[id|class|style],colgroup[id|class|align|style],legend[id|class|style],menu[id|class|style],ins[id|class|style],kbd[id|class|style],option[id|class|style|value|selected],select[id|class|style|name],sub[id|class|style],div[id|class|align|style],form,table[border|cellspacing|cellpadding|width|id|class|style],p[id|class|align|style],img[src|width|height|alt],span[id|class|style],strong[id|class|style],small[id|class|style],font[style|color],big[id|class|style],s[id|class|style],strike[id|class|style],a[href|title|id|class|style|rel],b[id|class|style],u[id|class|style],em[id|class|style],i[id|class|style],tbody[id|class|align|style],thead[id|class|align|style],tfoot[id|class|align|style],tr[id|class|align|style],td[valign|id|class|align|style],dd[id|class|style],dl[id|class|style],dt[id|class|style],label,hr,br,li[id|class|style],ol[id|class|style],ul[id|class|style],fieldset[id|class|style],input[type|name|id|class|value|src],textarea[name|cols|rows|id|class],h1[id|class|align|style],h2[id|class|align|style],h3[id|class|align|style],h4[id|class|align|style],h5[id|class|align|style],h6[id|class|align|style],center,pre');
$cfg->set('Attr.EnableID',true);

$cfg->set('HTML.Trusted',true);
$purifier = new HTMLPurifier($cfg);
?>