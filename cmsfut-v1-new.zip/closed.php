<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Silakan, coba lagi nanti</title>
</head>
<body>
<div style="text-align: center">
<h2 style="color:red"> Perhatian! </h2> <br/> Situs melakukan pekerjaan teknis. <br/>, Coba
lagi nanti
</div>
</body>
</html>