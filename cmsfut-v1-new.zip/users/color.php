<?php

define('_IN_JOHNCMS', 1);
$headmod = 'color';
$textl = 'Pembelian Warna nick';
require ("../incfiles/core.php");
require ("../incfiles/head.php");
$user = functions::get_user($user);
$user = $datauser;
if (!$user_id) {
    display_error('Hanya untuk pengguna yang terdaftar! ONLY MEMBER!');
    require_once ('../incfiles/end.php');
    exit;
}

switch($act){
case 'gradient' :
echo '<div class="phdr">Warna dasar:</div>';
if($user['balance']>=5000){
echo '<div><form action="color.php?act=gradientbuy" name="color" method="post"> 
<input type="radio" name="color" value="006400"/><font color="#006400"> Namamu</font><br />
<input type="radio" name="color" value="0000FF"/><font color="#0000FF"> Namamu</font><br />
<input type="radio" name="color" value="000080"/><font color="#000080"> Namamu</font><br />
<input type="radio" name="color" value="00FFFF"/><font color="#00FFFF"> Namamu</font><br />
<input type="radio" name="color" value="FFFF00"/><font color="#FFFF00"> Namamu</font><br />
<input type="radio" name="color" value="808080"/><font color="#808080"> Namamu</font><br />
<input type="radio" name="color" value="C0C0C0"/><font color="#C0C0C0"> Namamu</font><br />
<input type="radio" name="color" value="9ACD32"/><font color="#9ACD32"> Namamu</font><br />
<input type="radio" name="color" value="7FFF00"/><font color="#7FFF00"> Namamu</font><br />
<input type="radio" name="color" value="90EE90"/><font color="#90EE90"> Namamu</font><br />
<input type="radio" name="color" value="D1E231"/><font color="#D1E231"> Namamu</font><br/>
<input type="radio" name="color" value="4B0082"/><font color="#4B0082"> Namamu</font><br />
<input type="radio" name="color" value="8A2BE2"/><font color="#8A2BE2"> Namamu</font><br />
<input type="radio" name="color" value="991199"/><font color="#991199"> Namamu</font><br />
<input type="radio" name="color" value="008B8B"/><font color="#008B8B"> Namamu</font><br />
<input type="radio" name="color" value="4682B4"/><font color="#4682B4"> Namamu</font><br />
<input type="radio" name="color" value="87CEEB"/><font color="#87CEEB"> Namamu</font><br />
<input type="radio" name="color" value="FF7F50"/><font color="#FF7F50"> Namamu</font><br />
<input type="radio" name="color" value="8B4513"/><font color="#8B4513"> Namamu</font><br />
<input type="radio" name="color" value="FF2400"/><font color="#FF2400"> Namamu</font><br />
<input type="radio" name="color" value="DC143C"/><font color="#DC143C"> Namamu</font><br />
<input type="radio" name="color" value="FF1493"/><font color="#FF1493"> Namamu</font><br />
<input type="radio" name="color" value="FF69B4"/><font color="#FF69B4"> Namamu</font><br />
<input type="radio" name="color" value="FF8C00"/><font color="#FF8C00"> Namamu</font><br />
<input type="radio" name="color" value="FFD700"/><font color="#FFD700"> Namamu</font><br />
<input type="radio" name="color" value="BDB76B"/><font color="#BDB76B"> Namamu</font><br />
<input type="radio" name="color" value="FFA07A"/><font color="#FFA07A"> Namamu</font><br />
<input type="radio" name="color" value="008080"/><font color="#008080"> Namamu</font><br />
<input type="radio" name="color" value="FFDB58"/><font color="#FFDB58"> Namamu</font><br />
<input type="radio" name="color" value="40826D"/><font color="#40826D"> Namamu</font><br />
<input type="radio" name="color" value="1E90FF"/><font color="#1E90FF"> Namamu</font><br />
<input type="radio" name="color" value="808000"/><font color="#808000"> Namamu</font><br />
<input type="radio" name="color" value="660000"/><font color="#660000"> Namamu</font><br />
<input type="radio" name="color" value="D2B48C"/><font color="#D2B48C"> Namamu</font><br />


<div class="phdr">Warna yang dihasilkan:</div>
<input type="radio" name="color2" value="006400"/><font color="#006400"> Namamu</font><br />
<input type="radio" name="color2" value="0000FF"/><font color="#0000FF"> Namamu</font><br />
<input type="radio" name="color2" value="000080"/><font color="#000080"> Namamu</font><br />
<input type="radio" name="color2" value="00FFFF"/><font color="#00FFFF"> Namamu</font><br />
<input type="radio" name="color2" value="FFFF00"/><font color="#FFFF00"> Namamu</font><br />
<input type="radio" name="color2" value="808080"/><font color="#808080"> Namamu</font><br />
<input type="radio" name="color2" value="C0C0C0"/><font color="#C0C0C0"> Namamu</font><br />
<input type="radio" name="color2" value="9ACD32"/><font color="#9ACD32"> Namamu</font><br />
<input type="radio" name="color2" value="7FFF00"/><font color="#7FFF00"> Namamu</font><br />
<input type="radio" name="color2" value="90EE90"/><font color="#90EE90"> Namamu</font><br />
<input type="radio" name="color2" value="D1E231"/><font color="#D1E231"> Namamu</font><br/>
<input type="radio" name="color2" value="4B0082"/><font color="#4B0082"> Namamu</font><br />
<input type="radio" name="color2" value="8A2BE2"/><font color="#8A2BE2"> Namamu</font><br />
<input type="radio" name="color2" value="991199"/><font color="#991199"> Namamu</font><br />
<input type="radio" name="color2" value="008B8B"/><font color="#008B8B"> Namamu</font><br />
<input type="radio" name="color2" value="4682B4"/><font color="#4682B4"> Namamu</font><br />
<input type="radio" name="color2" value="87CEEB"/><font color="#87CEEB"> Namamu</font><br />
<input type="radio" name="color2" value="FF7F50"/><font color="#FF7F50"> Namamu</font><br />
<input type="radio" name="color2" value="8B4513"/><font color="#8B4513"> Namamu</font><br />
<input type="radio" name="color2" value="FF2400"/><font color="#FF2400"> Namamu</font><br />
<input type="radio" name="color2" value="DC143C"/><font color="#DC143C"> Namamu</font><br />
<input type="radio" name="color2" value="FF1493"/><font color="#FF1493"> Namamu</font><br />
<input type="radio" name="color2" value="FF69B4"/><font color="#FF69B4"> Namamu</font><br />
<input type="radio" name="color2" value="FF8C00"/><font color="#FF8C00"> Namamu</font><br />
<input type="radio" name="color2" value="FFD700"/><font color="#FFD700"> Namamu</font><br />
<input type="radio" name="color2" value="BDB76B"/><font color="#BDB76B"> Namamu</font><br />
<input type="radio" name="color2" value="FFA07A"/><font color="#FFA07A"> Namamu</font><br />
<input type="radio" name="color2" value="008080"/><font color="#008080"> Namamu</font><br />
<input type="radio" name="color2" value="FFDB58"/><font color="#FFDB58"> Namamu</font><br />
<input type="radio" name="color2" value="40826D"/><font color="#40826D"> Namamu</font><br />
<input type="radio" name="color2" value="1E90FF"/><font color="#1E90FF"> Namamu</font><br />
<input type="radio" name="color2" value="808000"/><font color="#808000"> Namamu</font><br />
<input type="radio" name="color2" value="660000"/><font color="#660000"> Namamu</font><br />
<input type="radio" name="color2" value="D2B48C"/><font color="#D2B48C"> Namamu</font><br/>


<input type="submit" name="submit" value="Membeli"/></form></div>';
echo '<div class="menu"><a href="color.php?act=entergradient">Pilih secara manual</a></div>';
}else{
echo '<div class="menu">Poin Anda '.$user['balance'].', dan kebutuhan 5000. Poin</div>';
}
break;
case 'gradientbuy' :
if($user['balance']>=5000){
$color = ($_POST['color']); 
$color2 = ($_POST['color2']); 
mysql_query("UPDATE `users` SET `colornick` = '$color', `colornick2` = '$color2' ,`balance`=`balance`-5000  WHERE `id` = '$user_id' LIMIT 1");
echo '<div class="menu">Mengucapkan selamat dengan membeli 
nickname berwarna, sekarang telah menjadi begitu: '.functions::gradient(''.$login.'', '' .$color. '',''.$color2.'').'. Dengan tembakan saldo Anda 5000 Poin</div>';
}else{
echo '<div class="menu">Poin Anda '.$user['balance'].', dan kebutuhan 5000. Poin</div>';
}
break;




case 'color' :
if($user['balance']>=3000){
echo '<div><form action="color.php?act=colorbuy" name="color" method="post"> 
<input type="radio" name="color" value="006400"/><font color="#006400"> Namamu</font><br />
<input type="radio" name="color" value="0000FF"/><font color="#0000FF"> Namamu</font><br />
<input type="radio" name="color" value="000080"/><font color="#000080"> Namamu</font><br />
<input type="radio" name="color" value="00FFFF"/><font color="#00FFFF"> Namamu</font><br />
<input type="radio" name="color" value="FFFF00"/><font color="#FFFF00"> </font><br />
<input type="radio" name="color" value="808080"/><font color="#808080"> Namamu</font><br />
<input type="radio" name="color" value="C0C0C0"/><font color="#C0C0C0"> Namamu</font><br />
<input type="radio" name="color" value="9ACD32"/><font color="#9ACD32"> Namamu</font><br />
<input type="radio" name="color" value="7FFF00"/><font color="#7FFF00"> Namamu</font><br />
<input type="radio" name="color" value="90EE90"/><font color="#90EE90"> Namamu</font><br />
<input type="radio" name="color" value="D1E231"/><font color="#D1E231"> Namamu</font><br/>
<input type="radio" name="color" value="4B0082"/><font color="#4B0082"> Namamu</font><br />
<input type="radio" name="color" value="8A2BE2"/><font color="#8A2BE2"> Namamu</font><br />
<input type="radio" name="color" value="991199"/><font color="#991199"> Namamu</font><br />
<input type="radio" name="color" value="008B8B"/><font color="#008B8B"> Namamu</font><br />
<input type="radio" name="color" value="4682B4"/><font color="#4682B4"> Namamu</font><br />
<input type="radio" name="color" value="87CEEB"/><font color="#87CEEB"> Namamu</font><br />
<input type="radio" name="color" value="FF7F50"/><font color="#FF7F50"> Namamu</font><br />
<input type="radio" name="color" value="8B4513"/><font color="#8B4513"> Namamu</font><br />
<input type="radio" name="color" value="FF2400"/><font color="#FF2400"> Namamu</font><br />
<input type="radio" name="color" value="DC143C"/><font color="#DC143C"> Namamu</font><br />
<input type="radio" name="color" value="FF1493"/><font color="#FF1493"> Namamu</font><br />
<input type="radio" name="color" value="FF69B4"/><font color="#FF69B4"> Namamu</font><br />
<input type="radio" name="color" value="FF8C00"/><font color="#FF8C00"> Namamu</font><br />
<input type="radio" name="color" value="FFD700"/><font color="#FFD700"> Namamu</font><br />
<input type="radio" name="color" value="BDB76B"/><font color="#BDB76B"> Namamu</font><br />
<input type="radio" name="color" value="FFA07A"/><font color="#FFA07A"> Namamu</font><br />
<input type="radio" name="color" value="008080"/><font color="#008080"> Namamu</font><br />
<input type="radio" name="color" value="FFDB58"/><font color="#FFDB58"> Namamu</font><br />
<input type="radio" name="color" value="40826D"/><font color="#40826D"> Namamu</font><br />
<input type="radio" name="color" value="1E90FF"/><font color="#1E90FF"> Namamu</font><br />
<input type="radio" name="color" value="808000"/><font color="#808000"> Namamu</font><br />
<input type="radio" name="color" value="660000"/><font color="#660000"> Namamu</font><br />
<input type="radio" name="color" value="D2B48C"/><font color="#D2B48C"> Namamu</font><br />

<input type="submit" name="submit" value="Membeli"/></form></div>';
echo '<div class="menu"><a href="color.php?act=entercolor">Pilih secara manual</a></div>';
}else{
echo '<div class="menu">Poin Anda '.$user['balance'].', dan kebutuhan 3000. Poin</div>';

}
break;
case 'colorbuy' :
if($user['balance']>=3000){
$color = ($_POST['color']); 
mysql_query("UPDATE `users` SET `colornick` = '$color', `colornick2` = '$color' ,`balance`=`balance`-3000  WHERE `id` = '$user_id' LIMIT 1");
echo '<div class="menu">Mengucapkan selamat dengan membeli nickname berwarna, sekarang telah menjadi begitu: '.functions::gradient(''.$login.'', '' .$color. '',''.$color.'').'. Dengan tembakan saldo Anda 3000 Poin</div>';
}else{
echo '<div class="menu">Poin Anda '.$user['balance'].', dan kebutuhan 3000. Ayo ketika menumpuk</div>';
}
break;



case 'entercolor' :

if($user['balance']>=3000){
echo'<div class="phdr"><b>Memilih secara manual</b></div>';
echo'<span style="color:red"><b>Warna diberikan tanpa # <br/>Misalnya: FF0000</b></span><br/>';
echo'<a href="?act=tablcolors">Tabel warna</a>';
echo'<div><form action="color.php?act=entercolorbuy" name="color" method="post">
Warna: # <textarea name="color" rows="1"></textarea><br/>
<input type="submit" name="submit" value="Membeli"/></form></div>';
echo '<div class="menu"><a href="color.php?act=color">Pilih dari daftar</a></div>';
}else{
echo '<div class="menu">Poin Anda '.$user['balance'].', dan kebutuhan 3000. Poin</div>';
}
break;

case 'entercolorbuy' :
if($user['balance']>=3000){
$color = ($_POST['color']); 
if ($color && mb_strlen($color) > 6  || $color && mb_strlen($color) < 6 ){
echo '<div class="bmenu">Jumlah karakter yang tidak valid!</div>';
echo '<div class="menu"><a href="../users/color.php?act=entercolor">Kembali</a></div>';
 require_once ('../incfiles/end.php');
    exit;
}
if (preg_match("/[^a-z,A-Z,0-9]/", mb_strtolower($color))){
echo '<div class="bmenu">Karakter yang tidak valid!</div>';
echo '<div class="menu"><a href="../users/color.php?act=entercolor">Kembali</a></div>';
 require_once ('../incfiles/end.php');
    exit;
}
mysql_query("UPDATE `users` SET `colornick` = '$color', `colornick2` = '$color' ,`balance`=`balance`-3000  WHERE `id` = '$user_id' LIMIT 1");
echo '<div class="menu">Mengucapkan selamat dengan membeli 
nickname berwarna, sekarang telah menjadi begitu: '.functions::gradient(''.$login.'', '' .$color. '',''.$color.'').'. Dengan tembakan saldo Anda 3000 Poin</div>';
echo '<div class="menu"><a href="../users/color.php">Dengan memilih</a></div>';
}else{
echo '<div class="menu">Poin Anda '.$user['balance'].', dan kebutuhan 3000. Poin</div>';
}
break;


case 'entergradient' :

if($user['balance']>=5000){
echo'<div class="phdr"><b>Memilih secara manual</b></div>';
echo'<span style="color:red"><b>Warna diberikan tanpa # <br/>Misalnya: FF0000</b></span><br/>';
echo'<a href="?act=tablcolors">Tabel warna</a>';
echo'<div><form action="color.php?act=entergradientbuy" name="color" method="post">
Warna dasar: # <textarea name="color"  rows="1"></textarea><br/>
Warna yang dihasilkan: # <textarea name="color2"  rows="1"></textarea><br/>
<input type="submit" name="submit" value="Membeli"/></form></div>';
echo '<div class="menu"><a href="color.php?act=gradient">Pilih dari daftar</a></div>';
}else{
echo '<div class="menu">Poin Anda '.$user['balance'].', dan kebutuhan 5000. Poin</div>';
}
break;

case 'entergradientbuy' :
if($user['balance']>=5000){
$color = ($_POST['color']); 
$color2 = ($_POST['color2']); 
if ($color && mb_strlen($color) > 6 || $color2 &&  mb_strlen($color2) > 6 || $color && mb_strlen($color) < 6 || $color2 &&  mb_strlen($color2) < 6){
echo '<div class="bmenu">Jumlah karakter yang tidak valid!</div>';
echo '<div class="menu"><a href="../users/color.php?act=entergradient">Kembali</a></div>';
 require_once ('../incfiles/end.php');
    exit;
}
if (preg_match("/[^a-z,A-Z,0-9]/", mb_strtolower($color)) || preg_match("/[^a-z,A-Z,0-9]/", mb_strtolower($color2))){
echo '<div class="bmenu">Karakter yang tidak valid!</div>';
echo '<div class="menu"><a href="../users/color.php?act=entergradient">Kembali</a></div>';
 require_once ('../incfiles/end.php');
    exit;
}
mysql_query("UPDATE `users` SET `colornick` = '$color', `colornick2` = '$color2' ,`balance`=`balance`-5000  WHERE `id` = '$user_id' LIMIT 1");

echo '<div class="menu">Mengucapkan selamat dengan membeli nickname berwarna, sekarang telah menjadi begitu: '.functions::gradient(''.$login.'', '' .$color. '',''.$color2.'').'. Dengan tembakan saldo Anda 5000 Poin</div>';
}else{
echo '<div class="menu">Poin Anda '.$user['balance'].', dan kebutuhan 5000. Poin</div>';
}
break;




case 'tablcolors' :
            include ('colors.inc');
            break;  
            

default :
echo '<div class="menu">';
echo '<li><a href="color.php?act=color"><span style="color:#' . $colornick['colornick'] . '">Warna solid</span></a> 3000 Poin</li>';
echo'<li><a href="color.php?act=gradient">'.functions::gradient('Lereng', ''.$colornick['colornick'].'',''.$colornick['colornick2'].'').'</a> 5000 Poin</li>';
echo'</div>';
}
 echo '<div class="phdr"><a href="color.php">Ke warna</a></div>';
require ("../incfiles/end.php");