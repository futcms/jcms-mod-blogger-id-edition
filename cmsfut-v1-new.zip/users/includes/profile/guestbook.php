<?php

defined('_IN_JOHNCMS') or die('Error: restricted access');

$textl = $lng['profile'] . ' | ' . $lng['guestbook'];
$headmod = 'my_guest';
if($user_id && $user['id'] == $user_id)
    $datauser['comm_old'] = $datauser['comm_count'];
require('../incfiles/head.php');

$context_top = '<div class="phdr"><a href="profile.php?user=' . $user['id'] . '"><b>' . $lng['profile'] . '</b></a> | ' . $lng['guestbook'] . '</div>' .
    '<div class="user"><p>' . functions::display_user($user, array ('iphide' => 1,)) . '</p></div>';

$arg = array (
    'comments_table' => 'cms_users_guestbook',
    'object_table' => 'users',
    'script' => 'profile.php?act=guestbook',
    'sub_id_name' => 'user',
    'sub_id' => $user['id'],
    'owner' => $user['id'],
    'owner_delete' => true,
    'owner_reply' => true,
    'title' => $lng['comments'],
    'context_top' => $context_top
);

$comm = new comments($arg);

if(!$mod && $user['id'] == $user_id && $user['comm_count'] != $user['comm_old']){
    mysql_query("UPDATE `users` SET `comm_old` = '" . $user['comm_count'] . "' WHERE `id` = '$user_id'");
}

?>