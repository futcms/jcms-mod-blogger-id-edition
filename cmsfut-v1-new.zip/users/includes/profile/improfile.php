<?php

/*
* Modded by
* Name: Erik Supratman
* Web name: PasamanWaps and PasamanStar
* Website: www.pasaman-waps.ga and www.pasamanstar.ga
* Email: eriksupratman@gmail.com
* Phone: 085374228648
* Social network: https://twitter.com/eric_supratman and https://facebook.com/eric.supratman
* Powered by: PasamanStar and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');

if ($user_id) {
 $lng_profile = core::load_lng('profile');

 $arg = array(
 'iphist' => 0,
 'iphide' => 0,
 );
echo '<div class="user"><a href="/users/profile.php?user=' . $user_id . '">' . functions::display_user($datauser,$arg) . '</a> &#160;<a href="' . $set['homeurl'] . '/users/profile.php?act=office"><button class="phdr10">' . $lng['profile'] . '</button></a>&#160; <a href="' . $set['homeurl'] . '/dashboard"><button class="phdr10">' . $lng['dasbor'] . '</button></a>&#160; <a href="' . $set['homeurl'] . '/exit.php"><button class="phdr10">' . $lng['exit'] . '</button></a></div>';
}
?>