<?php

/*
* Modded by
* Name: Erik Supratman
* Web name: PasamanWaps and PasamanStar
* Website: www.pasaman-waps.ga and www.pasamanstar.ga
* Email: eriksupratman@gmail.com
* Phone: 085374228648
* Social network: https://twitter.com/eric_supratman and https://facebook.com/eric.supratman
* Powered by: PasamanStar and JohnCMS
*/

 define('_IN_JOHNCMS', 1);
 $headmod = 'friend';
 $textl = 'Friends';
 require('../incfiles/core.php');
 require_once ("../incfiles/head.php");

 if (!$user_id) {
 echo functions::display_error('Only for registered users');
 require('../incfiles/end.php');
 exit;
 }
 $user = functions::get_user($user);
 if (!$user) {
 echo functions::display_error('Only for registered users');
 require('../incfiles/end.php');
 exit;
 }
 $t[0] = date('jmy');
 $t[1] = date('jmy',$realtime - 86400);
 $t[2] = date('jmy',$realtime - 172800);
 function sdata($i){ global $t;
 if ( $t[0] == date('jmy',$i) ) { $i = 'Today: '.date('H:i',$i); }
 elseif ( $t[1] == date('jmy',$i) ){ $i = 'Yesterday: '.date('H:i',$i); }
 elseif( $t[2] == date('jmy',$i) ){ $i = 'Day before yesterday: '.date('H:i',$i); }
 else{ $i = date('j.m.Y / H:i',$i); } return $i; }
 if (!empty($_GET['act'])) {
 }
 switch ($act) {
 case 'del':
 if (isset($_GET['yes'])) {
 mysql_query("DELETE FROM `friend` WHERE (`user` = '$user_id' AND `friend` = '$id') OR (`user` = '$id' AND `friend` = '$user_id')");
 mysql_query("INSERT INTO `friend_notice` SET `user` = '" . $id . "', `to` = '" . $user_id . "', `type` = 'del', `time` = '$realtime'");
 header('location: friend.php');
 }
 echo '<div class="phdr">Remove friend!</div>';
 $res = mysql_fetch_array(mysql_query("SELECT `id`, `name`, `sex`, `rights`, `lastdate`, `datereg` FROM `users` WHERE `id` = '$id'"));
 echo '<div class="rmenu">';
 echo '' . functions::display_user($res, array ('iphide' => 1,)) . '';
 echo '<p align="center">Are you sure you want to remove this friend from your list of friends?</p><a href="friend.php?act=del&amp;id='.$id.'&amp;yes">Yes</a> | <a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">No</a></div>';
 break;
 case 'add':
 if ($user['id'] != $user_id) {
 $req = mysql_query("SELECT * FROM `friend_notice` WHERE (`user` = '".$user['id']."' AND `to` = '$user_id') OR (`user` = '$user_id' AND `to` = '".$user['id']."') LIMIT 1;");
 if (mysql_num_rows($req) > 0) {
 echo display_error('Application has been sent!');
 require_once ("../incfiles/end.php");
 exit;
 }
 $friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `friend` WHERE (`user` = '" . $user['id'] . "' AND `friend` = '$user_id') OR (`user` = '$user_id' AND `friend` = '" . $user['id'] . "')"), 0);
if ($friends > 0){
 echo display_error('You can not add those who are friends.');
 require_once ("../incfiles/end.php");
 exit;
 }
 mysql_query("INSERT INTO `friend_notice` SET `user` = '" . $user['id'] . "', `to` = '" . $user_id . "', `type` = 'add', `time` = '$realtime'");
 echo '<div class="gmenu"><p align="center">Your invitation has been sent.</p></div>';
 }else{
 echo display_error('You can not add yourself to friends!');
 }
 break;
 case 'new':
 if (isset($_GET['ok'])) {
 $id = intval($_GET['ok']);   
 mysql_query("INSERT INTO `friend` SET
   `user` = '$user_id',
   `friend` = '$id',
   `time` = '$realtime';");
 mysql_query("INSERT INTO `friend` SET
   `user` = '$id',
   `friend` = '$user_id',
   `time` = '$realtime';");

 mysql_query("DELETE FROM `friend_notice` WHERE (`user` = '$id' AND `to` = '$user_id') OR (`user` = '$user_id' AND `to` = '$id')");
 mysql_query("OPTIMIZE TABLE `friend`, `friend_notice`");
 $sql = mysql_result(mysql_query("SELECT COUNT(*) FROM `friend_notice` WHERE `user` = '$user_id'"),0);
 if ($sql > 0){
 echo '<form action="' . htmlspecialchars(getenv("HTTP_REFERER")) . '" method="post">';
 }else {
 echo '<form action="friend.php?" method="post">';
 }
 $res = mysql_fetch_array(mysql_query("SELECT `id`, `name`, `sex`, `rights`, `lastdate`, `datereg` FROM `users` WHERE `id` = '$id'"));
 echo '<div class="phdr">Do you have a new friend!</div><div class="menu">';
 echo '' . functions::display_user($res, array ('iphide' => 1,)) . '';
 echo '<p align="center">Has been added to your list of friends<br /><br /><input type="submit" value="Close " /></p></div></form>';
 require_once ("../incfiles/end.php");
 exit;
} elseif(isset($_GET['no'])) {
  $id = intval($_GET['no']);
  mysql_query("DELETE FROM `friend` WHERE (`user` = '$user_id' AND `friend` = '$id') OR (`user` = '$id' AND `friend` = '$user_id')");
  mysql_query("DELETE FROM `friend_notice` WHERE (`user` = '$id' AND `to` = '$user_id') OR (`user` = '$user_id' AND `to` = '$id')");  
  mysql_query("OPTIMIZE TABLE `friend`, `friend_notice`");
  $sql = mysql_result(mysql_query("SELECT COUNT(*) FROM `friend_notice` WHERE `user` = '$user_id'"),0);
  if ($sql > 0){
  header("Location: " . htmlspecialchars(getenv("HTTP_REFERER")) . "");
  }else {
  header("Location: friend.php?");
  }
  exit;
} else {
    $req = mysql_query("SELECT * FROM `friend_notice` WHERE `user` = '$user_id' ORDER BY `time` LIMIT 1");
    while ($res = mysql_fetch_array($req)){
   echo '<div class="phdr">' . ($res['type'] == 'del' ? 'You have removed the!' : 'Invite friends!') . '</div>';
   echo '<div class="list2">';
    $req_u = mysql_query("SELECT `id`, `name`, `sex`, `rights`, `lastdate`, `datereg` FROM `users` WHERE `id` = '" . $res['to'] . "'");
    $res_u = mysql_fetch_assoc($req_u);
   echo '' . functions::display_user($res_u, array ('iphide' => 1,)) . '';
   echo '<center>User ' . ($res['type'] == 'del' ? 'deleted you from the' : 'wants to add you as a') . ' my friends</center>';
    echo '<br/>' . sdata($res['time'] + $set_user['sdvig'] * 3600) . '<br/>';
   if ($res['type'] =='add'){
   echo '<div class="sub"><a href="friend.php?act=new&amp;ok='.$res_u['id'].'">Be Friends</a> | <a href="friend.php?act=new&amp;no='.$res_u['id'].'">Reject</a></div>';
   } else {
    echo '<p align="center"><form action="friend.php?act=new&amp;no='.$res_u['id'].'" method="post"><input type="submit" value="Close " /></form></p>';
}
echo '</div>';
}
}
echo '<div class="phdr"><a href="friend.php">My Friends</a></div>';
break;
default:
   $total = mysql_result(mysql_query("SELECT COUNT(user) FROM `friend` WHERE `user` = '" . $user['id'] . "'"), 0);
   echo '<div class="phdr">' . ($user['id'] != $user_id ? 'Friends' : 'My Friends') . ' &nbsp;' . $total . '';
   echo '</div>';
   if ($total) {
   $req = mysql_query("SELECT `friend`.*, `users`.`name`, `users`.`rights`, `users`.`lastdate`, `users`.`status`, `users`.`id`, `users`.`sex`, `users`.`datereg` FROM `friend` LEFT JOIN `users` ON `friend`.`friend` = `users`.`id` WHERE `friend`.`user`='".$user['id']."' ORDER BY `friend`.`time` DESC LIMIT $start, $kmess");  
   while ($res = mysql_fetch_array($req)) {
   echo ($i % 2) ? '<div class="list2">' : '<div class="list1">';
   echo '' . functions::display_user($res, array ('iphide' => 1,)) . '';
   echo '<div style="text-align: right; font-size: x-small;">' . ($res['id'] != $user_id ? '<a href="../users/pradd.php?act=write&amp;adr=' . $res['friend'] . '">Write</a>' : '') . '</div>';
   echo '<div class="sub">Make Friends: ' . sdata($res['time'] + $set_user['sdvig'] * 3600) . '</div>';
   echo'</div>';
   ++$i;
   }
   } else {
   echo '<div class="menu"> ' . ($user['id'] != $user_id ? 'Users' : 'You') . ' have no friends...</div>';
   }
   echo '<div class="phdr">' . ($user['id'] != $user_id ? '<a href="../users/profile.php?user=' . $user['id'] .'">Friend Profile</a>' : '<a href="../users/profile.php?user='.$user_id.'">My Page</a>') . '</div>';
   if ($total > $kmess){
   echo '<div class="str">Pages: ' . pagenav('friend.php?id=' . $id . '&amp;', $start, $total, $kmess) . '</div>';   
        }
}
require_once ("../incfiles/end.php");
?>