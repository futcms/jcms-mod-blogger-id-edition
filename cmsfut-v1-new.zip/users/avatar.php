<?php

function angka($var)
{
if (ctype_digit($var))
return $var;
else
return '0';
}
$id = isset($_GET['user']) ? $_GET['user'] : '0';

if (substr($id,-4) == ".jpg" OR substr($id,-4) == ".png" OR substr($id,-4) == ".gif")
$id = substr($id,0,-4);
$image = angka($id);
$image = "../files/users/avatar/".$image.".png";
if (file_exists($image))  {
$file_location = $image;
}
else {
$file_location = "../images/empty.png";
}

header('Content-Description: File Transfer');
header('Content-Type: image/png');    header('Content-Disposition: attachment; filename='.basename($file_location));
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' .$size);
readfile($file_location);
exit;
?>