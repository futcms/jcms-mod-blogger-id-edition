<?php

/*
* Modded by
* Name: Erik Supratman
* Web name: PasamanWaps and PasamanStar
* Website: www.pasaman-waps.ga and www.pasamanstar.ga
* Email: eriksupratman@gmail.com
* Phone: 085374228648
* Social network: https://twitter.com/eric_supratman and https://facebook.com/eric.supratman
* Powered by: PasamanStar and JohnCMS
*/

defined('_IN_JOHNCMS') or die('Error: restricted access');
if($user_id && $user['id'] == $user_id)
$datauser['comm_old'] = $datauser['comm_count'];
/*
-----------------------------------------------------------------
dinding pengguna tamu
-----------------------------------------------------------------
*/
$arg = array (
'comments_table' => 'cms_users_guestbook', // tamu nyo
'object_table' => 'users',                 // asal nyo dagi sikoa
'script' => '../users/profile.php?act=mod&guestbook',   // id)
'sub_id_name' => 'user',                   // ka 2
'sub_id' => $user['id'],                   // yg punyo
'owner' => $user['id'],                    // yg punyo ma hapuih e
'owner_delete' => true,                    // yg punyo mam baleh e
'owner_reply' => true,                     // yg tulisan komen
'title' => $lng['comments'],               // text
'context_top' => $context_top              // garis sajo
);
/*
-----------------------------------------------------------------
Pasaman Waps
-----------------------------------------------------------------
*/
$comm = new comments($arg);
/*
-----------------------------------------------------------------
Pasaman Waps
-----------------------------------------------------------------
*/
if(!$mod && $user['id'] == $user_id && $user['comm_count'] != $user['comm_old']){
mysql_query("UPDATE `users` SET `comm_old` = '" . $user['comm_count'] . "' WHERE `id` = '$user_id'");
}
?>
