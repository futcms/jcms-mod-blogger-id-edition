<?php

/**
 * Created by PhpStorm.
 * User: Valeriy Shikuta aka Str@nnik
 * Date: 30.09.2015
 * Time: 12:43
 * File: index.php
 * ICQ: 609-745-227
 * E-mail: valera_shikuta@mail.ru
 * E-mail: eriksupratman@gmail.com
 * ID langguage by: Erik Supratman 
 * Date Update: 10.02.2016
 * Time: 12:43 - Timezone 07: Pasaman barat 
*/

define('_IN_JOHNCMS', 1);
$headmod = 'store';
$textl = 'Toko';
require_once('../incfiles/core.php');
require_once('../incfiles/head.php');

$pos = isset($_REQUEST['pos']) ? abs(intval($_REQUEST['pos'])) : false;

switch ($act) {
    case 'view':
        $category = mysql_fetch_assoc(mysql_query("select * from `store_categories` where `id` = " . $id . ";"));
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;' . functions::checkout($category['name']) . '</div>';
        if ($rights == 9)
            echo '<div class="menu"><a href="admin.php?mod=add_good&amp;id=' . $id . '">Tambahkan item</a></div>';

        $total = mysql_result(mysql_query("select count(*) from `store_goods` where `category_id` = " . $id . ";"), 0);
        if ($total) {
            echo '<div class="gmenu"><form action="index.php?act=view&amp;id=' .$id . '" method="post">
                <select name="sort">
                <option value="viewed" ' . (isset($_POST['sort']) && $_POST['sort'] == 'viewed' ? 'selected' : '') . '>Populer</option>
                <option value="price" ' . (isset($_POST['sort']) && $_POST['sort'] == 'price' ? 'selected' : '') . '>Harga</option>
                <option value="new" ' . (isset($_POST['sort']) && $_POST['sort'] == 'new' ? 'selected' : '') . '>Terbaru</option>
                <input type="submit" name="sorts" value="Cari">
                </select>
                </form> </div>';

            if (isset($_POST['sorts'])) {
                if ($_POST['sort'] == 'viewed')
                    $req = mysql_query("select * from `store_goods` where `category_id` = " . $id . " order by `view` desc limit $start, $kmess;");
                if ($_POST['sort'] == 'price')
                    $req = mysql_query("select * from `store_goods` where `category_id` = " . $id . " order by `price` asc limit $start, $kmess;");
                if ($_POST['sort'] == 'new')
                    $req = mysql_query("select * from `store_goods` where `category_id` = " . $id . " order by `time` desc limit $start, $kmess;");
                $i = 0;
                while ($res = mysql_fetch_assoc($req)) {
                    echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
                    echo $res['img'] ? '<img src="img/small/' . $res['img'] . '.png" align="middle" alt="' . $res['name'] . '" />' : '<img src="img/small/foto.png" align="middle" alt="foto" />';
                    echo '&nbsp;<a href="?act=good&amp;id=' . $res['id'] . '"><b>' . functions::checkout($res['name']) . '</b></a>';
                    if ($rights == 9) {
                        echo '<div class="sub"><a href="admin.php?mod=edit_good&amp;id=' .$res['id'] . '">Ubah</a> | <a href="admin.php?mod=delete_good&amp;id=' .$res['id'] . '">Hapus</a></div>';
                    }
                    echo '</div>';
                    $i++;
                }
                echo '<div class="phdr">Produk dalam kategori ini: ' . $total . '</div>';
if ($total > $kmess) {
                    echo '<div class="topmenu">' . functions::display_pagination('index.php?act=view&amp;id=' . $id . '&amp;', $start, $total, $kmess) . '</div>';
                }
            } else {
                $req = mysql_query("select * from `store_goods` where `category_id` = " . $id . " order by `time` desc limit $start, $kmess;");
                $i = 0;
                while ($res = mysql_fetch_assoc($req)) {
                    echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
                    echo $res['img'] ? '<img src="img/small/' . $res['img'] . '.png" align="middle" alt="' . $res['name'] . '" />' : '<img src="img/small/foto.png" align="middle" alt="foto" />';
                    echo '&nbsp;<a href="?act=good&amp;id=' . $res['id'] . '"><b>' . functions::checkout($res['name']) . '</b></a>';
                    if ($rights == 9) {
                        echo '<div class="sub"><a href="admin.php?mod=edit_good&amp;id=' .$res['id'] . '">Ubah</a> | <a href="admin.php?mod=delete_good&amp;id=' .$res['id'] . '">Hapus</a></div>';
                    }
                    echo '</div>';
                    $i++;
                }
                echo '<div class="phdr">Produk dalam kategori ini: ' . $total . '</div>';
                if ($total > $kmess) {
                    echo '<div class="topmenu">' . functions::display_pagination('index.php?act=view&amp;id=' . $id . '&amp;', $start, $total, $kmess) . '</div>';
                }
            }
        } else {
            echo '<div class="menu">Barang tidak dapat ditambahkan!</div>';
        }
        echo '<div class="menu"><a href="index.php">Kembali</a></div>';
        break;

    case 'new':
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;Produk baru</div>';
        $new = mysql_result(mysql_query("select count(*) from `store_goods` where `time` > " . (time() - 3600 * 24) . ";"), 0);
        if ($new) {
            $req = mysql_query("select * from `store_goods` where `time` > " . (time() - 3600 * 24) . " order by `time` desc limit $start, $kmess;");
            $i = 0;
            while ($res = mysql_fetch_assoc($req)) {
                echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
                echo $res['img'] ? '<img src="img/small/' . $res['img'] . '.png" align="middle" alt="' . $res['name'] . '" />' : '<img src="img/small/foto.png" align="middle" alt="foto" />';
                echo '&nbsp;<a href="?act=good&amp;id=' . $res['id'] . '"><b>' . functions::checkout($res['name']) . '</b></a>';
                if ($rights == 9) {
                    echo '<div class="sub"><a href="admin.php?mod=edit_good&amp;id=' .$res['id'] . '">Ubah</a> | <a href="admin.php?mod=delete_good&amp;id=' .$res['id'] . '">Hapus</a></div>';
                }
                echo '</div>';
                $i++;
            }
            echo '<div class="phdr">Jumlah produk baru: ' . $new . '</div>';
            if ($new > $kmess) {
                echo '<div class="topmenu">' . functions::display_pagination('index.php?act=new&amp;', $start, $new, $kmess) . '</div>';
            }
        } else {
            echo '<div class="menu">Produk tidak ada yang baru!</div>';
        }
        echo '<div class="menu"><a href="index.php">Kembali</a></div>';
        break;

    case 'good':
        $good = mysql_fetch_assoc(mysql_query("select * from `store_goods` where `id` = " . $id . ";"));
        mysql_query("update `store_goods` set `view` = `view` + 1 where `id` = " . $id . ";");
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;' . functions::checkout($good['name']) . '</div>';
        echo '<div class="menu">';
        echo $good['img'] ? '<a href="' . $home . '/store/img/' . $good['img'] . '.jpg"><img src="img/' . $good['img'] . '.jpg" height="150" weight="150" alt="' . $good['name'] . '" /></a>' : '<img src="img/foto.png" height="150" weight="150" alt="foto" />';
        echo '</div>';
        echo '<div class="menu">';
        echo '<p><b>Penilaian:</b> ';
        $total = mysql_result(mysql_query("select count(*) from `store_votes` where `good_id` = " . $id . ";"), 0);
        $sum = mysql_result(mysql_query("select sum(`vote`) from `store_votes` where `good_id` = " . $id . ";"), 0);

        if ($total)
            $rating = round($sum / $total);
        else
            $rating = 0;

        if ($rating == 1)
            echo '<img src="img/rating/star.1.gif" align="middle" alt="1" />';
        if ($rating == 2)
            echo '<img src="img/rating/star.2.gif" align="middle" alt="2" />';
        if ($rating == 3)
            echo '<img src="img/rating/star.3.gif" align="middle" alt="3" />';
        if ($rating == 4)
            echo '<img src="img/rating/star.4.gif" align="middle" alt="4" />';
        if ($rating == 5)
            echo '<img src="img/rating/star.5.gif" align="middle" alt="5" />';
        if ($rating == 0)
            echo '<img src="img/rating/star.0.gif" align="middle" alt="5" />';
        echo '</p></div>';
        echo '<div class="gmenu">
            <p><b>Nama:</b> ' . functions::checkout($good['name']) . '</p>' .
            '<p><b>Model:</b> ' . functions::checkout($good['model']) . '</p>' .
            '<p><b>Keterangan:</b> ' . functions::checkout($good['description']) . '</p>' .
            '<p><b>Harga:</b> ' . functions::checkout($good['price']) . '</p>' .
            '<p><b>Dilihat:</b> ' . functions::checkout($good['view']) . '</p>' .
            '</div>';
        echo '<div class="phdr"><a href="index.php?act=add_cart&amp;id=' . $id . '">Tambahkan ke keranjang</a></div>';

        echo '<div class="bmenu">Ulasan:</div>';
        if ($user_id) {
            if (isset($_POST['submit'])) {
                $review = isset($_POST['review']) ? functions::checkin(mb_substr(trim($_POST['review']), 0, 500)) : '';
                $assessment = isset($_POST['assessment']) ? abs(intval($_POST['assessment'])) : 0;
                if (empty($review) || empty($assessment)) {
                    echo functions::display_error('Isi semua kolom', '<a href="?act=good&amp;id=' . $id . '">ulangi</a>');
                } else {
                    mysql_query("insert into `store_votes` set
                        `good_id` = " . $id . ",
                        `user_id` = " . $user_id . ",
                        `vote` = " . $assessment . ",
                        `review` = '" . mysql_real_escape_string($review) . "';") or die(mysql_error());
                    header('location: ?act=good&id=' . $id . '');
                }
            } else {
                $vote = mysql_fetch_assoc(mysql_query("select * from `store_votes` where `good_id` = " . $id . " and `user_id` = " . $user_id . ";"));
                if (!$vote) {
                    echo '<div class="gmenu">';
                    echo bbcode::auto_bb('form', 'review');
                    echo '<form action="index.php?act=good&amp;id=' .  $id . '" method="post" name="form">
                    <textarea rows="' . $set_user['field_h'] . '" name="review"></textarea><br />
                    Beri nilai: <select name="assessment">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    </select>
                    <br /><input type="submit" name="submit" value="Tinggalkan komentar" /></form></div>';
                }
            }
        }
        $total = mysql_result(mysql_query("select count(*) from `store_votes` where `good_id` = " . $id . ";"), 0);
if ($total) {
$req = mysql_query("select * from `store_votes` where `good_id` = " . $id . " order by `id` desc limit $start, $kmess");
            $i = 0;
            while ($res = mysql_fetch_assoc($req)) {
                $User = mysql_fetch_assoc(mysql_query("select * from `users` where `id` = " . $res['user_id'] . ";"));
                echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
                echo '<a href="' . $home . '/users/profile.php?user=' . $User['id'] . '"><b>' . $User['name'] . '</b></a>&nbsp;';
                $post = functions::checkout($res['review'], 1, 1);
                if ($set_user['smileys'])
                    $post = functions::smileys($post, $user['rights'] >= 1 ? 1 : 0);
                echo $post . '<br />';
                if ($res['vote'] == 1)
                    echo '<img src="img/rating/star.1.gif" align="middle" alt="1" />';
                if ($res['vote'] == 2)
                    echo '<img src="img/rating/star.2.gif" align="middle" alt="2" />';
                if ($res['vote'] == 3)
                    echo '<img src="img/rating/star.3.gif" align="middle" alt="3" />';
                if ($res['vote'] == 4)
                    echo '<img src="img/rating/star.4.gif" align="middle" alt="4" />';
                if ($res['vote'] == 5)
                    echo '<img src="img/rating/star.5.gif" align="middle" alt="5" />';
                echo '</div>';
                $i++;
            }
            echo '<div class="phdr">Semua ulasan: ' . $total . '</div>';
            if ($total > $kmess) {
                echo '<div class="topmenu">' . functions::display_pagination('index.php?act=good&amp;id=' . $id . '&amp;', $start, $total, $kmess) . '</div>';
            }
} else {
echo '<div class="menu">Belum ada ulasan!</div>';
}
        echo '<div class="menu"><a href="index.php?act=view&amp;id=' . $good['category_id'] . '">Kembali</a></div>';
        break;

    case 'my_cart':
        if (!$user_id) {
            header('location: index.php');
        } else {
            echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;Keranjang belanja</div>';
            $total = mysql_result(mysql_query("select count(*) from `store_cart` where `user_id` = " . $user_id . " and `status` = '0';"), 0);
            if ($total) {
                $req = mysql_query("select * from `store_cart` where `user_id` = " . $user_id . " and `status` = '0';");
                $i = 0;
                while($res = mysql_fetch_assoc($req)) {
                    $q = mysql_fetch_assoc(mysql_query("select * from `store_goods` where `id` = " . $res['good_id'] . ";"));
                    echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
                    echo $q['img'] ? '<img src="img/small/' . $q['img'] . '.png" align="middle" alt="' . $q['name'] . '" />' : '<img src="img/small/foto.png" align="middle" alt="foto" />';
                    echo '&nbsp;<a href="?act=good&amp;id=' . $q['id'] . '"><b>' . functions::checkout($q['name']) . '</b></a>';
                    echo '<div class="sub"><a href="?act=order&amp;id=' .$res['good_id'] . '">Pesan sekarang</a> | <a href="?act=delete&amp;id=' .$res['id'] . '">Hapus pesanan</a></div>';
                    echo '</div>';
                    $i++;
                }
                echo '<div class="phdr">Produk dalam keranjang: ' . $total . '</div>';
                if ($total > $kmess) {
                    echo '<div class="topmenu">' . functions::display_pagination('index.php?act=my_cart', $start, $total, $kmess) . '</div>';
                }
            } else {
                echo '<div class="menu">Permintaan Anda telah terkirim.. <b>spesialis kami akan menghubungi Anda</b></div>';
            }
            echo '<div class="menu"><a href="index.php">Kembali</a></div>';
        }
        break;

    case 'add_cart':
        if (!$user_id) {
            header('location: ../registration.php');
        } else {
            echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;Keranjang</div>';
            if (isset($_GET['yes'])) {
                mysql_query("insert into `store_cart` set `user_id` = " . $user_id . ", `good_id` = " . $id . ";");
                header('location: index.php?act=good&id=' . $id . '');
            } else {
                echo '<div class="gmenu">Apakah Anda yakin ingin menambahkan produk ke keranjang?<br />
                <a href="?act=add_cart&amp;id=' . $id . '&amp;yes">Ya</a> | <a href="index.php?act=good&amp;id=' . $id . '">Tidak</a></div>';
            }
            echo '<div class="menu"><a href="index.php?act=good&amp;id=' . $id . '">Kembali</a></div>';
        }
        break;

    case 'order':
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;<a href="index.php?act=my_cart">Keranjang belanja</a>&nbsp;|&nbsp;Membuat pesanan</div>';
        if (isset($_POST['submit'])) {
            $name = isset($_POST['name']) ? functions::checkin(mb_substr(trim($_POST['name']), 0, 50)) : '';
            $number = isset($_POST['number']) ? abs(intval($_POST['number'])) : 0;
            $email = isset($_POST['email']) ? functions::checkin(mb_substr(trim($_POST['email']), 0, 30)) : '';
            if (empty($name) || empty($number) || empty($email)) {
                echo functions::display_error('Isi semua kolom', '<a href="?act=order&amp;id=' . $id . '">Kembali</a>');
            } else {
                mysql_query("update `store_cart` set `status` = 1 where `good_id` = " . $id . " and `user_id` = " . $user_id . ";");
                mysql_query("insert into `store_orders` set
                    `good_id` = " . $id . ",
                    `user_id` = " . $user_id . ",
                    `name` = '" . mysql_real_escape_string($name) . "',
                    `number` = '" . $number . "',
                    `email` = '" . mysql_real_escape_string($email) . "';") or die(mysql_error());
                header('location: ?act=my_cart');
            }
        } else {
            echo '<div class="gmenu"><form action="?act=order&amp;id=' . $id . '" method="post">
                <p>Nama Anda: <input type="text" name="name" /></p>
                <p>Nomor ponsel: <input type="text" name="number" /></p>
                <p>E-mail: <input type="text" name="email" /></p>
                <input type="submit" name="submit" value="Pembuat pesanan" />
                <p><b>Spesialis kami akan menghubungi Anda</b></p>
                </form></div>';
        }
        echo '<div class="menu"><a href="index.php?act=my_cart">Kembali ke keranjang</a></div>';
        break;

    case 'delete':
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;<a href="index.php?act=delete">Keranjang belanja</a>&nbsp;|&nbsp;Hapus rangka</div>';
        if (isset($_GET['delete'])) {
            mysql_query("delete from `store_cart` where `id` = " . $id . ";");
            header('location: ?act=my_cart');
        } else {
            echo '<div class="rmenu">Apakah Anda yakin ingin menghapus pesanan ini?<br />
                <a href="?act=delete&amp;id=' . $id . '&amp;delete">Ya</a> | <a href="index.php?act=my_cart">Tidak</a></div>';
        }
        echo '<div class="menu"><a href="index.php?act=my_cart">Kembali</a></div>';
        break;

    case 'search':
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;Pencarian</div>';
        if (isset($_POST['submit'])) {
            if ($_POST['type'] == 'name')
                $search = htmlspecialchars(mysql_real_escape_string(trim($_POST['search'])));
            else
                $search = abs(intval($_POST['search']));
            $array = explode(' ', $search);

            $error = array();
            if (mb_strlen($search) < 2)
                $error[] = 'Terlalu pendek penyelidikan!';
            if (mb_strlen($search) > 40)
                $error[] = 'Permintaan judul terlalu panjang!';
            if (mb_strlen($search) == 0)
                $error[] = 'Permintaan judul kosong!';
            if (!$error) {
                if ($_POST['type'] == 'name')
                    $req = mysql_query("select * from `store_goods` where `name` like '%$search%' order by `time` desc");
                else
                    $req = mysql_query("select * from `store_goods` where `price` like '%$search%' order by `time` desc");
                $total = mysql_num_rows($req);
                if ($total) {
                    echo '<div class="gmenu">Hasil pencarian untuk <b>'.$search.'</b></div>';
                    $i = 0;
                    while ($res = mysql_fetch_assoc($req)) {
                        echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
                        echo $res['img'] ? '<img src="img/small/' . $res['img'] . '.png" align="middle" alt="' . $res['name'] . '" />' : '<img src="img/small/foto.png" align="middle" alt="foto" />';
                        echo '&nbsp;<a href="?act=good&amp;id=' . $res['id'] . '"><b>' . functions::checkout($res['name']) . '</b></a>';
                        if ($rights == 9) {
                            echo '<div class="sub"><a href="admin.php?mod=edit_good&amp;id=' .$res['id'] . '">Ubah</a> | <a href="admin.php?mod=delete_good&amp;id=' .$res['id'] . '">Hapus</a></div>';
                        }
                        echo '</div>';
                        $i++;
                    }
                    echo '<div class="phdr">Total ditemukan: <b>'.$total.'</b></div>';
                } else {
                    echo '<div class="menu">Pencarian tidak cocok! <a href="index.php?act=search">ulangi</a></div>';
                }
            } else {
                echo functions::display_error($error, '<a href="?act=search">ulangi</a>');
            }
        } else {
            echo '<div class="gmenu"><form action="?act=search" method="post">
            <select name="type">
            <option value="name">Dengan nama</option>
            <option value="price">Dengan harga</option>
            </select>
            <input type="search" name="search" /><br />
            <input type="submit" name="submit" value="Mulai mencari" />
            </form></div>';
        }
        echo '<div class="menu"><a href="index.php">Ke Toko</a></div>';
        break;

    default:
        echo '<div class="phdr">Toko</div>';
        $total = mysql_result(mysql_query("select count(*) from `store_categories`"), 0);
        if ($total) {
            echo '<div class="gmenu"><a href="index.php?act=search">Pencarian</a>';
            $new = mysql_result(mysql_query("select count(*) from `store_goods` where `time` > " . (time() - 3600 * 24) . ";"), 0);
            if ($new)
                echo '&nbsp;|&nbsp;<a href="index.php?act=new">Produk baru</a> (<span class="red">' . $new . '</span>)';
            echo '</div>';
            $req = mysql_query("select * from `store_categories` order by `pos` asc limit $start, $kmess;");
            $i = 0;
            while ($res = mysql_fetch_assoc($req)) {
                $category = mysql_result(mysql_query("select count(*) from `store_goods` where `category_id` = " . $res['id'] . ";"), 0);
                echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
                echo '&nbsp;<a href="index.php?act=view&amp;id=' . $res['id'] . '"> <b>' . $res['name'] . '</b></a>&nbsp;[' . $category . ']';
                if ($rights == 9) {
                    echo '<div class="sub">' . ($res['pos'] > 1 ? '<a href="?up&amp;pos=' . $res['pos'] . '&amp;id=' . $res['id'] . '">Atas</a>' : 'Atas') . '&nbsp;|&nbsp;' . ($res['pos'] != $total ? '<a href="?down&amp;pos=' . $res['pos'] . '&amp;id=' . $res['id'] . '">Bawah</a>' : 'Bawah') . '
                        &nbsp;|&nbsp;<a href="admin.php?mod=edit_category&amp;id=' . $res['id'] . '">Ubah</a>&nbsp;|&nbsp;<a href="admin.php?mod=delete_category&amp;id=' . $res['id'] . '">Hapus</a></div>';
                }
                echo '</div>';
                $i++;
            }
            echo '<div class="phdr">Semua Kategori: ' . $total . '</div>';
            if ($total > $kmess) {
                echo '<div class="topmenu">' . functions::display_pagination('index.php?', $start, $total, $kmess) . '</div>';
            }
        } else {
            echo '<div class="menu">Kategori belum ada!</div>';
        }
        
        if ($user_id) {
$my_cart = mysql_result(mysql_query("select count(*) from `store_cart` where `user_id` = " . $user_id . " and `status` = 0;"), 0);
echo '<div class="gmenu"><div class="quote"><a href="?act=my_cart">Keranjang belanja</a> (' . $my_cart . ')</div></div>';
}
         
        if ($rights == 9) {
            $total = mysql_result(mysql_query("select count(*) from `store_orders`"), 0);
            $new = mysql_result(mysql_query("select count(*) from `store_orders` where `status` = 0"), 0);
            if ($new)
                $total .= '&nbsp;/&nbsp;<span class="red">+' . $new . '</span>';
            echo '<div class="menu"><a href="admin.php?mod=orders">Pesanan</a> (' . $total . ')</div>';
            echo '<div class="menu"><a href="admin.php?mod=add_category">Tambahkan kategori</a></div>';
        }

        if (isset($_GET['up'])) {
            $posup = $pos - 1;
            mysql_query("update `store_categories` set `pos` = " . $pos . " where `pos` = " . $posup . ";");
            mysql_query("update `store_categories` set `pos` = " . $posup . " where `id` = " . $id . ";");
            header('location: index.php');
        }

        if (isset($_GET['down'])) {
            $posdown = $pos + 1;
            mysql_query("update `store_categories` set `pos` = " . $pos . " where `pos` = " . $posdown . ";");
            mysql_query("update `store_categories` set `pos` = " . $posdown . " where `id` = " . $id . ";");
            header('location: index.php');
        }
        break;
}

require_once('../incfiles/end.php');