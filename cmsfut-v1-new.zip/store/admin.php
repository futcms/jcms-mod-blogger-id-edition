<?php

/**
 * Created by PhpStorm.
 * User: Valeriy Shikuta aka Str@nnik
 * Date: 30.09.2015
 * Time: 12:43
 * File: index.php
 * ICQ: 609-745-227
 * E-mail: valera_shikuta@mail.ru
 * E-mail: eriksupratman@gmail.com
 * ID langguage by: Erik Supratman 
 * Date Update: 10.02.2016
 * Time: 12:43 - Timezone 07: Pasaman barat 
*/

define('_IN_JOHNCMS', 1);
$headmod = 'store';
$textl = 'Toko | Admin Panel';
require_once('../incfiles/core.php');
require_once ('../incfiles/lib/class.upload.php');
require_once('../incfiles/head.php');

if (!$user_id || $rights < 9) {
    header ("location: index.php");
}

switch ($mod) {
    case 'add_category':
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;Tambahkan kategori</div>';
        if (isset($_POST['submit'])) {
            $name = isset($_POST['name']) ? functions::checkin(mb_substr(trim($_POST['name']), 0, 50)) : '';
            if (empty($name)) {
                echo functions::display_error("Masukkan nama untuk kategori!", '<a href="?mod=add_category">Tambah</a>');
            } else {
                $total = mysql_result(mysql_query("select count(*) from `store_categories`"), 0);
                $pos = $total + 1;
                mysql_query("insert into `store_categories` set `name` = '" . mysql_real_escape_string($name) . "', `pos` = " . $pos . ";");
                header('location: index.php');
            }
        } else {
            echo '<div class="gmenu"><form action="admin.php?mod=add_category" method="post">
                <p>Nama: <input type="text" name="name" /></p>
                <input type="submit" name="submit" value="Menambahkan" />
            </form></div>';
        }
        echo '<div class="menu"><a href="index.php">Kembali</a></div>';
        break;

    case 'edit_category':
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;Mengedit kategori</div>';
        if (isset($_POST['submit'])) {
            $name = isset($_POST['name']) ? functions::checkin(mb_substr(trim($_POST['name']), 0, 50)) : '';
            if (empty($name)) {
                echo functions::display_error("Masukkan nama untuk kategori!", '<a href="?mod=edit_category&amp;id=' . $id . '">Lihat</a>');
            } else {
                mysql_query("update `store_categories` set `name` = '" . mysql_real_escape_string($name) . "' where `id` = " . $id . ";");
                header('location: index.php');
            }
        } else {
            $category = mysql_fetch_assoc(mysql_query("select * from `store_categories` where `id` = " . $id . ";"));
            echo '<div class="gmenu"><form action="admin.php?mod=edit_category&amp;id=' . $id . '" method="post">
                <p>Nama: <input type="text" name="name" value="' . functions::checkout($category['name']) . '" /></p>
                <input type="submit" name="submit" value="Simpan" />
            </form></div>';
        }
        echo '<div class="menu"><a href="index.php">Kembali</a></div>';
        break;

    case 'delete_category':
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;Hapus kategori</div>';
        if (isset($_GET['delete'])) {
            mysql_query("delete from `store_categories` where `id` = " . $id . ";");
            header('location: index.php');
        } else {
            echo '<div class="rmenu">Apakah Anda yakin ingin menghapus kategori ini?<br />
                <a href="admin.php?mod=delete_category&amp;id=' . $id . '&amp;delete">Ya</a> | <a href="index.php">Tidak</a>';
        }
        break;

    case 'add_good':
        $category = mysql_fetch_assoc(mysql_query("select * from `store_categories` where `id` = " . $id . ";"));
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;<a href="index.php?act=view&amp;id=' . $id . '">' . functions::checkout($category['name']) . '</a>&nbsp;|&nbsp;Tambahkan item</div>';
        if (isset($_POST['submit'])) {
            $name = isset($_POST['name']) ? functions::checkin(mb_substr(trim($_POST['name']), 0, 100)) : '';
            $model = isset($_POST['model']) ? functions::checkin(mb_substr(trim($_POST['model']), 0, 50)) : '';
            $description = isset($_POST['description']) ? functions::checkin(mb_substr(trim($_POST['description']), 0, 1000)) : '';
            $price = isset($_POST['price']) ? abs(intval($_POST['price'])) : 0;
            if (empty($name) || empty($model) || empty($description) || empty($price)) {
                echo functions::display_error('Semua bidang yang diperlukan!', '<a href="?mod=add_good&amp;id=' . $id . '">Kembali</a>');
            } else {
                $handle = new upload($_FILES['file']);
                if ($handle->uploaded) {
                    $fname = time();
                    $handle->file_new_name_body = $fname;
                    $handle->allowed = array (
                        'image/jpeg',
                        'image/jpg',
                        'image/gif',
                        'image/png'
                    );
                    $handle->file_max_size = 1024 * $set['flsz'];
                    $handle->file_overwrite = true;
                    $handle->image_convert = 'jpg';
                    $handle->process('img/');

                    $handle->file_new_name_body = $fname;
                    $handle->file_overwrite = true;
                    $handle->image_resize = true;
                    $handle->image_x = 50;
                    $handle->image_y = 50;
                    $handle->image_convert = 'png';
                    $handle->process('img/small/');

                    if ($handle->processed) {
                        mysql_query("insert into `store_goods` set
                            `category_id` = " . $id . ",
                            `img` = '" . $fname  . "',
                            `time` =  " . time() . ",
                            `name` = '" . mysql_real_escape_string($name) . "',
                            `model` = '" . mysql_real_escape_string($model) . "',
                            `description` = '" . mysql_real_escape_string($description) . "',
                            `price` = " . $price . ";") or die(mysql_error());
                    } else {
                        echo display_error($handle->error);
                    }
                    $handle->clean();
                } else {
                    mysql_query("insert into `store_goods` set
                            `category_id` = " . $id . ",
                            `time` =  " . time() . ",
                            `name` = '" . mysql_real_escape_string($name) . "',
                            `model` = '" . mysql_real_escape_string($model) . "',
                            `description` = '" . mysql_real_escape_string($description) . "',
                            `price` = " . $price . ";") or die(mysql_error());
                }
               header('location: index.php?act=view&id=' . $id . '');
            }
        } else {
            echo '<div class="gmenu"><form action="admin.php?mod=add_good&amp;id=' . $id . '" method="post" enctype="multipart/form-data">
                <p>Foto <input type="file" name="file" /></p>
                <p>Nama: <input type="text" name="name" /></p>
                <p>Model: <input type="text" name="model" /></p>
                <p>Deskripsi: <input  type="text" name="description" /></p>
                <p>Harga (Rupiah): <input type="text" name="price" size="4" /></p>
                <input type="submit" name="submit" value="Buat" />
            </form></div>';
        }
        echo '<div class="menu"><a href="index.php?act=view&amp;id=' . $id . '">Kembali</a></div>';
        break;

    case 'edit_good':
        $good = mysql_fetch_assoc(mysql_query("select * from `store_goods` where `id` = " . $id . ";"));
        $category = mysql_fetch_assoc(mysql_query("select * from `store_categories` where `id` = " . $good['category_id'] . ";"));
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;<a href="index.php?act=view&amp;id=' . $id . '">' . functions::checkout($category['name']) . '</a>&nbsp;|&nbsp;' . functions::checkout($good['name']) . '</div>';
        if (isset($_POST['submit'])) {
            $name = isset($_POST['name']) ? functions::checkin(mb_substr(trim($_POST['name']), 0, 100)) : '';
            $model = isset($_POST['model']) ? functions::checkin(mb_substr(trim($_POST['model']), 0, 50)) : '';
            $description = isset($_POST['description']) ? functions::checkin(mb_substr(trim($_POST['description']), 0, 1000)) : '';
            $price = isset($_POST['price']) ? abs(intval($_POST['price'])) : 0;
            if (empty($name) || empty($model) || empty($description) || empty($price)) {
                echo functions::display_error('Semua bidang yang diperlukan!', '<a href="?mod=add_good&amp;id=' . $id . '">Kembali</a>');
            } else {
                $handle = new upload($_FILES['file']);
                if ($handle->uploaded) {
                    $fname = time();
                    $handle->file_new_name_body = $fname;
                    $handle->allowed = array (
                        'image/jpeg',
                        'image/jpg',
                        'image/gif',
                        'image/png'
                    );
                    $handle->file_max_size = 1024 * $set['flsz'];
                    $handle->file_overwrite = true;
                    $handle->image_convert = 'jpg';
                    $handle->process('img/');

                    $handle->file_new_name_body = $fname;
                    $handle->file_overwrite = true;
                    $handle->image_resize = true;
                    $handle->image_x = 50;
                    $handle->image_y = 50;
                    $handle->image_convert = 'png';
                    $handle->process('img/small/');

                    if ($handle->processed) {
                        mysql_query("update `store_goods` set
                            `img` = '" . $fname  . "',
                            `name` = '" . mysql_real_escape_string($name) . "',
                            `model` = '" . mysql_real_escape_string($model) . "',
                            `description` = '" . mysql_real_escape_string($description) . "',
                            `price` = " . $price . " where `id` = " . $id . ";") or die(mysql_error());
                    } else {
                        echo display_error($handle->error);
                    }
                    $handle->clean();
                } else {
                    mysql_query("update `store_goods` set
                            `name` = '" . mysql_real_escape_string($name) . "',
                            `model` = '" . mysql_real_escape_string($model) . "',
                            `description` = '" . mysql_real_escape_string($description) . "',
                            `price` = " . $price . " where `id` = " . $id . ";") or die(mysql_error());
                }
                header('location: index.php?act=view&id=' . $category['id'] . '');
            }
        } else {
            echo '<div class="gmenu"><form action="admin.php?mod=edit_good&amp;id=' . $id . '" method="post" enctype="multipart/form-data">
                <p>Foto: <input type="file" name="file" /></p>
                <p>Nama: <input type="text" name="name" value="' . $good['name'] . '" /></p>
                <p>Model: <input type="text" name="model" value="' . $good['model'] . '" /></p>
                <p>Deskripsi: <input  type="text" name="description" value="' . $good['description'] . '" /></p>
                <p>Harga (Rupiah): <input type="text" name="price" size="4" value="' . $good['price'] . '" /></p>
                <input type="submit" name="submit" value="Simpan" />
            </form></div>';
        }
        echo '<div class="menu"><a href="index.php?act=view&amp;id=' . $category['id'] . '">Kembali</a></div>';
        break;
        break;

    case 'delete_good':
        $good = mysql_fetch_assoc(mysql_query("select * from `store_goods` where `id` = " . $id . ";"));
        $category = mysql_fetch_assoc(mysql_query("select * from `store_categories` where `id` = " . $good['category_id'] . ";"));
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;<a href="index.php?act=view&amp;id=' . $id . '">' . functions::checkout($category['name']) . '</a>&nbsp;|&nbsp;' . functions::checkout($good['name']) . '</div>';
        if (isset($_GET['delete'])) {
            mysql_query("delete from `store_goods` where `id` = " . $id . ";");
//            unlink("img/' . $good['img'] . '.jpg");
//            unlink("img/small/' . $good['img'] . '.png");
            header('location: index.php?act=view&id=' . $category['id'] . '');
        } else {
            echo '<div class="rmenu">Apakah Anda yakin ingin menghapus item ini?<br />
                <a href="admin.php?mod=delete_good&amp;id=' . $id . '&amp;delete">Ya</a> | <a href="index.php?act=view&amp;id=' . $category['id'] . '">Tidak</a>';
        }
        break;

    case 'orders':
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;Pesanan</div>';
        $req = mysql_query("select * from `store_orders` order by `id` desc limit $start, $kmess;");
        $total = mysql_num_rows($req);
        if ($total) {
            $i = 0;
            while ($res = mysql_fetch_assoc($req)) {
                $good = mysql_fetch_assoc(mysql_query("select * from `store_goods` where `id` = " . $res['good_id'] . ";"));
                echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
                echo $good['img'] ? '<img src="img/small/' . $good['img'] . '.png" align="middle" alt="' . $good['name'] . '" />' : '<img src="img/small/foto.png" align="middle" alt="foto" />';
                echo '&nbsp;<a href="?mod=view_order&amp;id=' . $res['id'] . '"><b>' . functions::checkout($good['name']) . '</b></a>';
                echo ($res['status'] == 0) ? '<div class="sub"><a href="admin.php?mod=close_order&amp;id=' .$res['id'] . '">Selesaikan transaksi</a></div>' : ' [<b>selesai</b>]';
                echo '</div>';
                $i++;
            }
            echo '<div class="phdr">Artikel dalam kategori ini: ' . $total . '</div>';
            if ($total > $kmess) {
                echo '<div class="topmenu">' . functions::display_pagination('admin.php?act=orders&amp;', $start, $total, $kmess) . '</div>';
            }
        } else {
            echo '<div class="menu">Pesanan belum dilaporkan</div>';
        }
        echo '<div class="menu"><a href="index.php">Kembali</a></div>';
        break;

    case 'view_order':
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp;jumlah' . $id . '</div>';
        $res = mysql_fetch_assoc(mysql_query("select * from `store_orders` where `id` = " . $id . ";"));
        echo '<div class="gmenu">' .
            '<p><b>barang:</b> <a href="index.php?act=good&amp;id=' . $res['good_id'] . '">link</a></p>' .
            '<p><b>Nama Pelanggan:</b> ' . functions::checkout($res['name']) . '</p>' .
            '<p><b>Nomor:</b> ' . functions::checkout($res['number']) . '</p>' .
            '<p><b>E-mail:</b> ' . functions::checkout($res['email']) . '</p>' .
            '</div>';
        echo '<div class="menu"><a href="admin.php?mod=orders">Kembali</a></div>';
        break;

    case 'close_order':
        echo '<div class="phdr"><a href="index.php">Toko</a>&nbsp;|&nbsp; jumlah' . $id . '</div>';
        if (isset($_GET['yes'])) {
            mysql_query("update `store_orders` set `status` = '1' where `id` = " . $id . ";");
            header('location: ?mod=orders');
        } else {
            echo '<div class="rmenu">Apakah Anda yakin ingin menyelesaikan transaksi ini?<br />
                <a href="admin.php?mod=close_order&amp;id=' . $id . '&amp;yes">Ya</a> | <a href="admin.php?mod=orders">Tidak</a>';
        }
        break;
}
require_once('../incfiles/end.php');