<script type="text/javascript">
var uid ='35508';
var wid ='117508';
</script>
<script type="text/javascript"
src="http://cdn.popcash.net/pop.js"></script>  