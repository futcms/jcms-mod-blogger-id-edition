<?php
/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */
define('_IN_JOHNCMS', 1);
$headmod = "kuis";
require('../incfiles/core.php');
if (!$user_id)
{
	header('Location: ../index.php');
	exit;
}
$tm = time();
$req = mysql_query("SELECT * FROM `kuis_tanya` WHERE `id` = '".mysql_real_escape_string($id)."' AND `waktu_mulai` < '".$tm."'");
if(mysql_num_rows($req) == 0)
{
	$textl = "Kuis";
	require('../incfiles/head.php');
	echo '<div class="phdr"><a href="index.php">Kuis</a> | <a href="create.php">Buat Kuis</a></div>';
	echo functions::display_error('Kuis tidak ada atau telah kadaluarsa!','<a href="index.php">Kembali</a>');
	require('../incfiles/end.php');
	exit;
}
$kuis = mysql_fetch_array($req);
unset($req);
$result = false;
if(isset($_POST['submit']))
{
	$err = false;
	$jawaban = $_POST['jawaban'];
	if($kuis['waktu_berakhir'] < $tm)
	{
		$err = 'Kuis sudah kadaluarsa';
	}
	if($kuis['user_id'] == $user_id)
	{
		$err = 'Kamu tidak diperbolehkan menjawab kuis ini';
	}
	elseif($kuis['datar_hitam'] != "")
	{
		$blocked = unserialize($kuis['daftar_hitam']);
		if (in_array($user_id,$blocked))
			$err = 'Kamu tidak diijinkan menjawab pertanyaan ini!';
	}
	elseif($jawaban == '')
	{
		$err = 'Silakan masukan jawaban Kamu!';
	}
	elseif(mb_strlen($jawaban) > 50)
	{
		$err = 'Jawaban maksimal 50 karakter!';
	}
	elseif($kuis['terjawab'] != 0)
	{
		$err = 'Kuis ini sudah terjawab sebelumnya';
	}
	elseif(mysql_num_rows(mysql_query("SELECT `id` FROM `kuis_jawaban` WHERE `kuis_id` = '".$kuis['id']."' AND `user_id` = '".$user_id."'")) != 0)
	{
		$err = 'Kamu sudah menjawab pertanyaan ini sebelumnya!';
	}
	if($err == false)
	{
		if($kuis['jawaban2'] == strtolower(preg_replace('#([\W_]+)#','',$jawaban)))
		{
			$sts = 'benar';
			$balance = $datauser['balance'] + $kuis['hadiah'];
			mysql_query("UPDATE `users` SET `balance` = '".$balance."' WHERE `id` = '".$user_id."'");
			$msg = '<div class="alarm">Selamat, Kamu berhasil menjawab pertanyaan ini.</div>';
		}
		else
		{
			$sts = 'salah';
			$msg = functions::display_error('Sayang sekali jawaban Kamu tidak benar!');
		}
		mysql_query("INSERT INTO `kuis_jawaban` SET `kuis_id`='".$kuis['id']."', `user_id`='".$user_id."', `jawaban1`='".mysql_real_escape_string($jawaban)."', `jawaban2`='".mysql_real_escape_string($jawaban)."', `status`='".$sts."', `tanggal`='".time()."'");
		$jid = mysql_insert_id();
		mysql_query("UPDATE `kuis_jawaban` SET `terjawab` = $jid WHERE `id` = {$kuis['id']}");
		$result = $msg;
	}
	else
	{
		$result = functions::display_error($err);
	}
	
}

/**
 * Keterangan table kuis_tanya:
 * `user_id` = Id pembuat kuis
 * `pertanyaan` = Pertanyaan kuis
 * `jawaban1` = Jawaban yang meliputi semua simbol
 * `jawaban2` = Jawaban yang terdiri dari abjad a-z dan angka 0-9 kolom ini yang menjadi patokan jawaban
 * `waktu_mulai` = Waktu dimana kuis dimulai
 * `waktu_berakhir` Waktu kuis nerakhir
 * `waktu_pembuatan` = Waktu pembuatan kuis
 *
 * Untuk mengetahui selisih waktu berapa menit durasi kuis itu `waktu_mulai` - `waktu_berakhir`
**/

$textl = "Kuis - ".mb_substr(htmlentities($kuis['pertanyaan']),0,15);
require('../incfiles/head.php');
echo '<div class="phdr"><a href="index.php">Kuis</a> | <a href="create.php">Buat Kuis</a> | <a href="kredit.php">Kredit</a> | <b>Read</b></div>';
echo '<div class="user" id="pertanyaan">';
$pembuat = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$kuis['user_id']."'"));
$arg = array(
	'body'   => $kuis['terjawab'] != 0 || $kuis['waktu_berakhir'] < $tm ? '<s><b>@Rp '.$kuis['hadiah'].'</b> '.htmlentities($kuis['pertanyaan']).'</s>' : '<b>@Rp '.$kuis['hadiah'].'</b> '.htmlentities($kuis['pertanyaan']),
	);
echo functions::display_user($pembuat, $arg);
echo '</div>';
$req = mysql_query("SELECT * FROM `kuis_jawaban` WHERE `kuis_id` = '".$kuis['id']."' ORDER BY `id` ASC");
$total = mysql_num_rows($req);
if($total > 0)
{
	while($jawab = mysql_fetch_array($req))
	{
		echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
		$penjawab = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$jawab['user_id']."'"));
		$arg = array(
			'body'   => '<span class="'.($jawab['status'] == 'benar' ? "green" : "red").'">'.htmlspecialchars($jawab['jawaban1'].' ('.$jawab['jawaban2'].')').'</span>'
			);
		echo functions::display_user($penjawab, $arg);
		echo '</div>';
		++$i;
	}
}
else
{
	echo '<div class="list1">Belum ada yang menjawab!</div>';
}
echo '<div class="gmenu">';
if($result)
	echo $result;
echo '<form method="post" action="read.php?id='.$kuis['id'].'#jawab" id="jawab">'.
'<textarea rows="' . $set_user['field_h'] . '" name="jawaban"></textarea>'.
'<p><input type="submit" name="submit" value="' . $lng['sent'] . '"/></p>'.
'</form>';
echo '</div>';
require('../incfiles/end.php');
?>