<?php
/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */
define('_IN_JOHNCMS', 1);
$headmod = "kuis";
require('../incfiles/core.php');
if (!$user_id)
{
	header('Location: ../index.php');
	exit;
}
$textl = "Kuis";
require('../incfiles/head.php');
echo '<div class="phdr"><b>Kuis</b> | <a href="create.php">Buat Kuis</a> | <a href="kredit.php">Kredit</a></div>';
$tm = time();
$req = mysql_query("SELECT * FROM `kuis_tanya` WHERE `waktu_mulai` < '".$tm."' ORDER BY `id` DESC");
$total = mysql_num_rows($req);
if($total > 0)
{
	while($kuis = mysql_fetch_array($req))
	{
		echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
		$pembuat = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$kuis['user_id']."'"));
		$arg = array(
			'body'   => $kuis['terjawab'] != 0 || $kuis['waktu_berakhir'] < $tm ? '<s><a href="read.php?id='.$kuis['id'].'#pertanyaan">'.htmlspecialchars($kuis['pertanyaan']).'</a></s>' : '<a href="read.php?id='.$kuis['id'].'#pertanyaan">'.htmlspecialchars($kuis['pertanyaan']).'</a>'
			);
		echo functions::display_user($pembuat, $arg);
		echo '</div>';
		++$i;
	}
}
else
{
	echo '<div class="list1">Tidak ada kuis</div>';
}
require('../incfiles/end.php');
?>