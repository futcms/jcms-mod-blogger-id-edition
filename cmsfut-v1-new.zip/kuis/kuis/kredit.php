<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */
define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
if (!$user_id)
{
	require('../incfiles/head.php');
	echo functions::display_error($lng['access_guest_forbidden']);
	require('../incfiles/end.php');
	exit;
}
switch($act)
{
	case 'topup':
		$textl = "Kredit | Top-Up";
		require('../incfiles/head.php');
		echo '<div class="phdr"><a href="kredit.php">Kredit</a> | <b>Top-Up</b></div>';
		echo '<div>Untuk mengisi ulang kredit silakan hubungi SV</div>';
		require('../incfiles/end.php');
		break;
	
	case 'transfer':
		$result = false;
		$error = false;
		$textl = "Kredit | Transfer";
		if(isset($_POST['submit']))
		{
			$uid = $_POST['uid'];
			$jumlah = $_POST['jumlah'];
			$captcha = $_POST['captcha'];
			if (!$captcha || !isset($_SESSION['code']) || mb_strlen($captcha) < 4 || $captcha != $_SESSION['code'])
			{
				$error = 'Kode keamanan tidak benar';
			}
			elseif(empty($jumlah) || !ctype_digit($jumlah))
			{
				$error = "Silakan masukan jumlah dengan benar";
			}
			elseif(empty($uid) || !ctype_digit($uid))
			{
				$error = 'Silakan masukan User ID dengan benar';
			}
			elseif($jumlah > $datauser['balance'])
			{
				$error = 'Jumlah kredit Kamu tidak mencukupi';
			}
			else
			{
				$rek = mysql_query("SELECT * FROM `users` WHERE `id` = '".mysql_real_escape_string($uid)."'");
				if(mysql_num_rows($rek) == 0)
				{
					$error = 'User ID tidak ditemukan';
				}
				else
				{
					$us = mysql_fetch_array($rek);
					mysql_query("UPDATE `users` SET `balance` = `balance` + $jumlah WHERE `id` = {$us['id']}");
					$result = '<div class="fmenu">Kamu berhasil mentransfer kredit sebesar Rp. '.$jumlah.' kepada <a href="profile.php?user='.$us['id'].'">'.htmlspecialchars($us['name_lat']).'</a></div>';
				}
			}
			unset($_SESSION['code']);
		}
		require('../incfiles/head.php');
		echo '<div class="phdr"><a href="kredit.php">Kredit</a> | <b>Transfer</b></div>';
		if($error)
			echo functions::display_error($error);
		elseif($result)
			echo $result;
		echo '<div class="gmenu">'.
		'<p>'.
		'<form method="post" action="kredit.php?act=transfer">'.
		'<b>Masukan ID User</b><br/>'.
		'<input type="text" name="uid"/><br/>'.
		'<b>Jumlah</b><br/>'.
		'<input type="text" name="jumlah"/><br/>'.
		'<b>Kode Keamanan</b><br/>'.
		'<img src="../captcha.php?r='.rand(1000, 9999).'" alt="" border="1"/><br />'.
		'<input type="text" name="captcha"/><br/>'.
		'<p><input type="submit" name="submit" value="Kirim"/></p>'.
		'</form>'.
		'</p>'.
		'</div>';
		require('../incfiles/end.php');
		break;
	
	default:
		$textl = "Kredit | Top-Up";
		require('../incfiles/head.php');
		echo '<div class="phdr">Kredit</div>';
		echo '<div>Jumlah kredit Kamu saat ini adalah Rp. '.$datauser['balance'].'</div>';
		echo '<div class="menu"><a href="kredit.php?act=topup">Top-Up/Isi Ulang Kredit</a></div>';
		echo '<div class="menu"><a href="kredit.php?act=transfer">Transfer Kredit</a></div>';
		require('../incfiles/end.php');
		break;
}
?>