<?php
/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */
define('_IN_JOHNCMS', 1);
$headmod = "kuis";
require('../incfiles/core.php');
if ($rights < 9) // Hanya bisa diinstall oleh SV
{
	header('Location: ../index.php');
	exit;
}
mysql_query("CREATE TABLE IF NOT EXISTS `kuis_jawaban` (
	    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
	    `kuis_id` int(10) NOT NULL,
	    `user_id` int(10) NOT NULL,
	    `jawaban1` varchar(50) NOT NULL,
	    `jawaban2` varchar(50) NOT NULL,
	    `status` enum('benar','salah') NOT NULL,
	    `tanggal` int(10) NOT NULL,
	    PRIMARY KEY (`id`)
	    ) ENGINE=MyISAM  DEFAULT CHARSET=utf8");

mysql_query("CREATE TABLE IF NOT EXISTS `kuis_tanya` (
	    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
	    `user_id` int(10) NOT NULL,
	    `pertanyaan` text NOT NULL,
	    `jawaban1` varchar(50) NOT NULL,
	    `jawaban2` varchar(50) NOT NULL,
	    `hadiah` int(10) NOT NULL,
	    `waktu_mulai` int(10) NOT NULL,
	    `waktu_berakhir` int(10) NOT NULL,
	    `waktu_pembuatan` int(10) NOT NULL,
	    `daftar_hitam` text NOT NULL,
	    PRIMARY KEY (`id`)
	    ) ENGINE=MyISAM  DEFAULT CHARSET=utf8");

mysql_query("ALTER TABLE `users`  ADD `balance` INT(10) NOT NULL DEFAULT '0' AFTER `rights`");
// unlink(basename(__FILE__)); // Menghapus file installasi
header('location: index.php');
?>