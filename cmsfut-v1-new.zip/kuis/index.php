<?php

define('_IN_JOHNCMS', 1);
$headmod = "kuis";
require('../incfiles/core.php');
if (!$user_id)
{
   header('Location: ../index.php');
   exit;
}
$textl = $lng['quiz'];
require('../incfiles/head.php');
echo '<div class="phdr"><b>' . $lng['quiz'] . '</b> | <a href="create.php">' . $lng['buat'] . '&#160;' . $lng['quiz'] . '</a> | <a href="kredit.php">' . $lng['erikduo'] . '</a></div>';
$tm = time();
$req = mysql_query("SELECT * FROM `kuis_tanya` WHERE `waktu_mulai` < '".$tm."' ORDER BY `id` DESC");
$total = mysql_num_rows($req);
if($total > 0)
{
   while($kuis = mysql_fetch_array($req))
   {
      echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
      $pembuat = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$kuis['user_id']."'"));
      $arg = array(
         'body'   => $kuis['terjawab'] != 0 || $kuis['waktu_berakhir'] < $tm ? '<s><a href="read.php?id='.$kuis['id'].'#pertanyaan">'.htmlspecialchars($kuis['pertanyaan']).'</a></s>' : '<a href="read.php?id='.$kuis['id'].'#pertanyaan">'.htmlspecialchars($kuis['pertanyaan']).'</a>'
         );
      echo functions::display_user($pembuat, $arg);
      echo '</div>';
      ++$i;
   }
}
else
{
   echo '<div class="list1">' . $lng['list_empty'] . '</div>';
}
require('../incfiles/end.php');
?>