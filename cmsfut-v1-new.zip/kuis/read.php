<?php

define('_IN_JOHNCMS', 1);
$headmod = "kuis";
require('../incfiles/core.php');
if (!$user_id)
{
   header('Location: ../index.php');
   exit;
}
$tm = time();
$req = mysql_query("SELECT * FROM `kuis_tanya` WHERE `id` = '".mysql_real_escape_string($id)."' AND `waktu_mulai` < '".$tm."'");
if(mysql_num_rows($req) == 0)
{
   $textl = $lng['quiz'];
   require('../incfiles/head.php');
   echo '<div class="phdr"><a href="index.php">' . $lng['quiz'] . '</a> | <a href="create.php">' . $lng['buat'] . '&#160; ' . $lng['quiz'] . '</a></div>';
   echo functions::display_error('' . $lng['kuis15'] . '','<a href="index.php">' . $lng['back'] . '</a>');
   require('../incfiles/end.php');
   exit;
}
$kuis = mysql_fetch_array($req);
unset($req);
$result = false;
if(isset($_POST['submit']))
{
   $err = false;
   $jawaban = $_POST['jawaban'];
   if($kuis['waktu_berakhir'] < $tm)
   {
      $err = '' . $lng['kuis16'] . '';
   }
   if($kuis['user_id'] == $user_id)
   {
      $err = '' . $lng['kuis17'] . '';
   }
   elseif($kuis['datar_hitam'] != "")
   {
      $blocked = unserialize($kuis['daftar_hitam']);
      if (in_array($user_id,$blocked))
         $err = '' . $lng['kuis18'] . '';
   }
   elseif($jawaban == '')
   {
      $err = '' . $lng['kuis19'] . '';
   }
   elseif(mb_strlen($jawaban) > 50)
   {
      $err = '' . $lng['kuis20'] . '';
   }
   elseif($kuis['terjawab'] != 0)
   {
      $err = '' . $lng['kuis21'] . '';
   }
   elseif(mysql_num_rows(mysql_query("SELECT `id` FROM `kuis_jawaban` WHERE `kuis_id` = '".$kuis['id']."' AND `user_id` = '".$user_id."'")) != 0)
   {
      $err = '' . $lng['kuis22'] . '';
   }
   if($err == false)
   {
      if($kuis['jawaban2'] == strtolower(preg_replace('#([\W_]+)#','',$jawaban)))
      {
         $sts = 'benar';
         $balance = $datauser['balance'] + $kuis['hadiah'];
         mysql_query("UPDATE `users` SET `balance` = '".$balance."' WHERE `id` = '".$user_id."'");
         $msg = '<div class="alarm">' . $lng['jawaban_ok'] . '</div>';
      }
      else
      {
         $sts = 'salah';
         $msg = functions::display_error('' . $lng['sayang_sekali'] . '');
      }
      mysql_query("INSERT INTO `kuis_jawaban` SET `kuis_id`='".$kuis['id']."', `user_id`='".$user_id."', `jawaban1`='".mysql_real_escape_string($jawaban)."', `jawaban2`='".mysql_real_escape_string($jawaban)."', `status`='".$sts."', `tanggal`='".time()."'");
      $jid = mysql_insert_id();
      mysql_query("UPDATE `kuis_jawaban` SET `terjawab` = $jid WHERE `id` = {$kuis['id']}");
      $result = $msg;
   }
   else
   {
      $result = functions::display_error($err);
   }
   
}

/**
 * Keterangan table kuis_tanya:
 * `user_id` = Id pembuat kuis
 * `pertanyaan` = Pertanyaan kuis
 * `jawaban1` = Jawaban yang meliputi semua simbol
 * `jawaban2` = Jawaban yang terdiri dari abjad a-z dan angka 0-9 kolom ini yang menjadi patokan jawaban
 * `waktu_mulai` = Waktu dimana kuis dimulai
 * `waktu_berakhir` Waktu kuis nerakhir
 * `waktu_pembuatan` = Waktu pembuatan kuis
 *
 * Untuk mengetahui selisih waktu berapa menit durasi kuis itu `waktu_mulai` - `waktu_berakhir`
**/

$textl = $lng['quiz'];
require('../incfiles/head.php');
echo '<div class="phdr"><a href="index.php">' . $lng['quiz'] . '</a> | <a href="create.php">' . $lng['buat'] . '</a> | <a href="kredit.php">' . $lng['erikduo'] . '</a> | <b>' . $lng['unread'] . '</b></div>';
echo '<div class="user" id="pertanyaan">';
$pembuat = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$kuis['user_id']."'"));
$arg = array(
   'body'   => $kuis['terjawab'] != 0 || $kuis['waktu_berakhir'] < $tm ? '<s><b>@Rp '.$kuis['hadiah'].'</b> '.htmlentities($kuis['pertanyaan']).'</s>' : '' . $lng['gifts'] . '<b>@Rp '.$kuis['hadiah'].'</b> '.htmlentities($kuis['pertanyaan']),
   );
echo functions::display_user($pembuat, $arg);
echo '</div>';
$req = mysql_query("SELECT * FROM `kuis_jawaban` WHERE `kuis_id` = '".$kuis['id']."' ORDER BY `id` ASC");
$total = mysql_num_rows($req);
if($total > 0)
{
   while($jawab = mysql_fetch_array($req))
   {
      echo $i % 2 ? '<div class="list1">' : '<div class="list2">';
      $penjawab = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$jawab['user_id']."'"));
      $arg = array(
         'body'   => '<span class="'.($jawab['status'] == 'benar' ? "green" : "red").'">'.htmlspecialchars($jawab['jawaban1'].' ('.$jawab['jawaban2'].')').'</span>'
         );
      echo functions::display_user($penjawab, $arg);
      echo '</div>';
      ++$i;
   }
}
else
{
   echo '<div class="list1">' . $lng['list_empty'] . '</div>';
}
echo '<div class="phdr">' . $lng['kuis19'] . '</div>';
echo '<div class="gmenu">';
if($result)
   echo $result;
echo '<form method="post" action="read.php?id='.$kuis['id'].'#jawab" id="jawab">'.
'<textarea rows="' . $set_user['field_h'] . '" name="jawaban"></textarea>'.
'<p><input type="submit" name="submit" value="' . $lng['sent'] . '"/></p>'.
'</form>';
echo '</div>';
require('../incfiles/end.php');
?>