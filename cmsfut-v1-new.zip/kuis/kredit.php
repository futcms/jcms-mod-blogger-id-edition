<?php

define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
if (!$user_id)
{
   require('../incfiles/head.php');
   echo functions::display_error($lng['access_guest_forbidden']);
   require('../incfiles/end.php');
   exit;
}
switch($act)
{
   case 'topup':
      $textl = $lng['quiz'];
      require('../incfiles/head.php');
      echo '<div class="phdr"><a href="kredit.php">' . $lng['erikduo'] . '</a> | <b>Top-Up</b></div>';
      echo '<div class="list1">' . $lng['isi_ulang'] . ' <a href="/users/profile.php?act=user=1">AdminSV!</a></div>';
      require('../incfiles/end.php');
      break;
   
   case 'transfer':
      $result = false;
      $error = false;
      $textl = $lng['quiz'];
      if(isset($_POST['submit']))
      {
         $uid = $_POST['uid'];
         $jumlah = $_POST['jumlah'];
         $captcha = $_POST['captcha'];
         if (!$captcha || !isset($_SESSION['code']) || mb_strlen($captcha) < 4 || $captcha != $_SESSION['code'])
         {
            $error = '' . $lng['kuis10'] . '';
         }
         elseif(empty($jumlah) || !ctype_digit($jumlah))
         {
            $error = '' . $lng['kuis11'] . '';
         }
         elseif(empty($uid) || !ctype_digit($uid))
         {
            $error = '' . $lng['kuis12'] . '';
         }
         elseif($jumlah > $datauser['balance'])
         {
            $error = '' . $lng['kuis13'] . '';
         }
         else
         {
            $rek = mysql_query("SELECT * FROM `users` WHERE `id` = '".mysql_real_escape_string($uid)."'");
            if(mysql_num_rows($rek) == 0)
            {
               $error = '' . $lng['kuis14'] . '';
            }
            else
            {
               $us = mysql_fetch_array($rek);
               mysql_query("UPDATE `users` SET `balance` = `balance` + $jumlah WHERE `id` = {$us['id']}");
               $result = '<div class="fmenu">' . $lng['kredit_terkirim'] . ' Rp. '.$jumlah.' ' . $lng['kepada'] . ' <a href="profile.php?user='.$us['id'].'">'.htmlspecialchars($us['name_lat']).'</a></div>';
            }
         }
         unset($_SESSION['code']);
      }
      require('../incfiles/head.php');
      echo '<div class="phdr"><a href="/kuis">' . $lng['quiz'] . '</a> | <a href="kredit.php">' . $lng['erikduo'] . '</a> | <b>' . $lng['transfer_kredit'] . '</b></div>';
      if($error)
         echo functions::display_error($error);
      elseif($result)
         echo $result;
      echo '<div class="gmenu">'.
      '<p>'.
      '<form method="post" action="kredit.php?act=transfer">'.
      '<b>' . $lng['masukan_id_erik'] . '</b><br/>'.
      '<input type="text" name="uid"/><br/>'.
      '<b>' . $lng['jumlah'] . '</b><br/>'.
      '<input type="text" name="jumlah"/><br/>'.
      '<b>' . $lng['enter_code'] . '</b><br/>'.
      '<img src="../captcha.php?r='.rand(1000, 9999).'" alt="" border="1"/><br />'.
      '<input type="text" name="captcha"/><br/>'.
      '<p><input type="submit" name="submit" value="' . $lng['sent'] . '"/></p>'.
      '</form>'.
      '</p>'.
      '</div>';
      require('../incfiles/end.php');
      break;
   
   default:
      $textl = $lng['quiz'];
      require('../incfiles/head.php');
      echo '<div class="phdr"><a href="/kuis">' . $lng['quiz'] . '</a> | <b>' . $lng['topup_isi_ulang'] . '</b></div>';
      echo '<div class="list1">' . $lng['jumlah_kredit'] . ' Rp. '.$datauser['balance'].'</div>';
      echo '<div class="menu"><a href="kredit.php?act=topup">' . $lng['topup_isi_ulang'] . '</a></div>';
      echo '<div class="menu"><a href="kredit.php?act=transfer">' . $lng['transfer'] . '</a></div>';
      require('../incfiles/end.php');
      break;
}
?>