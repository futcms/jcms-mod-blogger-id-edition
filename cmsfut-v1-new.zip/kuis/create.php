<?php

define('_IN_JOHNCMS', 1);
$headmod = "kuis";
require('../incfiles/core.php');
if (!$user_id)
{
   header('Location: ../index.php');
   exit;
}
$durations = array(2,3,4,5,6,7,8,9,10,15,20,25,30);
$return = false;
$tanya = isset($_POST['tanya']) ? $_POST['tanya'] : '';
$jawab = isset($_POST['jawab']) ? $_POST['jawab'] : '';
$hadiah = isset($_POST['hadiah']) ? $_POST['hadiah'] : '';
$blokir = isset($_POST['blokir']) ? $_POST['blokir'] : '';
if(isset($_POST['submit']))
{
   $error = false;
   $durasi = $_POST['durasi'];
   $user_blokir = '';
   if(empty($tanya))
   {
      $error = '' . $lng['kuis1'] . '';
   }
   elseif(mb_strlen($tanya) > 1024 || mb_strlen($tanya) < 5)
   {
      $error = '' . $lng['kuis2'] . '';
   }
   elseif(empty($jawab))
   {
      $error = '' . $lng['kuis3'] . '';
   }
   elseif(mb_strlen($jawab) > 50)
   {
      $error = '' . $lng['kuis4'] . '';
   }
   elseif(empty($hadiah))
   {
      $error = '' . $lng['kuis5'] . '';
   }
   elseif(!ctype_digit($hadiah))
   {
      $error= '' . $lng['kuis6'] . '';
   }
   elseif($hadiah < 200 || $hadiah > 100000)
   {
      $error = '' . $lng['kuis7'] . '';
   }
   elseif($datauser['balance'] < $hadiah)
   {
      $error = '' . $lng['kuis8'] . '';
   }
   elseif(!in_array($durasi,$durations))
   {
      $error = '' . $lng['kuis9'] . '';
   }
   elseif(!empty($blokir))
   {
      if(strpos(',',$blokir) !== false)
      {
         $us = array();
         $users = explode(',',$blokir);
         for($i=0;$i<count($users);$i++)
         {
            if(!ctype_digit($users[$i]))
               continue;
            $us[] = $users[$i];
         }
         $user_blokir = serialize($us);
      }
      else
      {
         if(ctype_digit($blokir))
         {
            $us = array();
            $us[]= $blokir;
            $user_blokir = serialize($us);
         }
      }
   }
   if($error == false)
   {
      mysql_query("UPDATE users SET balance = balance - $hadiah WHERE `id` = $user_id");
      $date = time();
      $mulai = $date;
      $akhir = $date + ($durasi * 60);
      $submit = $date;
      $jwb = strtolower(preg_replace('#([\W_]+)#','',$jawab));
      mysql_query("INSERT INTO `kuis_tanya` SET `user_id` = '".$user_id."', `pertanyaan` = '".mysql_real_escape_string($tanya)."', `jawaban1` = '".mysql_real_escape_string($jawab)."', `jawaban2` = '".mysql_real_escape_string($jwb)."', `hadiah` = '".mysql_real_escape_string($hadiah)."', `waktu_mulai` = '".$mulai."', `waktu_berakhir` = '".$akhir."', `waktu_pembuatan` = '".$submit."', `daftar_hitam` = '".mysql_real_escape_string($user_blokir)."'");
      $kid = mysql_insert_id();
      // header('Location: read.php?id='.$kid);
      header('Location: index.php');
      exit;
   }
   else
   {
      $return = functions::display_error($error);
   }
}
$textl = $lng['quiz'];
require('../incfiles/head.php');
echo '<div class="phdr"><a href="index.php">' . $lng['quiz'] . '</a> | <b>' . $lng['buat'] . '</b> | <a href="kredit.php">' . $lng['erikduo'] . '</a></div>';
if($return)
   echo $return;
echo '<div class="gmenu">'.
'<form method="post" action="create.php">'.
'<b>' . $lng['pertanyaan'] . '</b><br/>'.
'<input type="text" name="tanya" value="'.htmlentities($tanya).'"/><br/>'.
'<b>' . $lng['jawaban'] . '</b><br/>'.
'<input type="text" name="jawab" value="'.htmlentities($jawab).'"/><br/>'.
'<b>' . $lng['gifts'] . '</b><br/>'.
'<input type="text" name="hadiah" value="'.htmlentities($hadiah).'"/><br/>'.
'<b>' . $lng['durasi'] . '</b><br/>'.
'<select name="durasi">';
foreach($durations as $menit)
{
   echo '<option value="'.$menit.'">'.$menit.' ' . $lng['menit'] . '</option>';
}
echo '</select><br/>'.
'<b>' . $lng['block_id_user'] . '</b><br/>'.
'<input type="text" name="blokir" value="'.htmlentities($blokir).'"/><br/><span>' . $lng['block_user'] . '</span><br/>'.
'<p><input type="submit" name="submit" value="' . $lng['buat'] . ' ' . $lng['quiz'] . '"/></p>'.
'</form>'.
'</div>';
require('../incfiles/end.php');
?>