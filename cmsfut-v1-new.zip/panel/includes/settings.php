<?php

/*
// Name: Erik Supratman
// Powered by: Pasaman Waps
// Site: http://www.pasaman.biz
// Facebook: fb.com/eric.supratman
// Twitter: twitter.com/eric_supratman
*/

defined('_IN_ERIKSUPRATMAN') or die('Error: restricted access');

// Erik Supratman = Pasaman Waps
if ($rights < 9) {
    header('Location: ' . core::$system_set['homeurl'] . '/index.php/err');
    exit;
}
echo '<div class="phdr"><a href="index.php"><b>' . $lng['admin_panel'] . '</b></a> | ' . $lng['site_settings'] . '</div>';
if (isset($_POST['submit'])) {
    /*
    -----------------------------------------------------------------
Erik Supratman = Pasaman Waps -----------------------------------------------------------------
    */
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['skindef']) . "' WHERE `key` = 'skindef'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . mysql_real_escape_string(htmlspecialchars($_POST['madm'])) . "' WHERE `key` = 'email'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . intval($_POST['timeshift']) . "' WHERE `key` = 'timeshift'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['copyright']) . "' WHERE `key` = 'copyright'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check(preg_replace("#/$#", '', trim($_POST['homeurl']))) . "' WHERE `key` = 'homeurl'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . intval($_POST['flsz']) . "' WHERE `key` = 'flsz'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . isset($_POST['gz']) . "' WHERE `key` = 'gzip'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['meta_google']) . "' WHERE `key` = 'meta_google'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['meta_author']) . "' WHERE `key` = 'meta_author'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['erik']) . "' WHERE `key` = 'erik'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['official_blog']) . "' WHERE `key` = 'official_blog'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['meta_key']) . "' WHERE `key` = 'meta_key'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['seo_title']) . "' WHERE `key` = 'seo_title'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['seo_type']) . "' WHERE `key` = 'seo_type'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['seo_image']) . "' WHERE `key` = 'seo_image'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['seo_url']) . "' WHERE `key` = 'seo_url'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['seo_desc']) . "' WHERE `key` = 'seo_desc");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($_POST['meta_desc']) . "' WHERE `key` = 'meta_desc'");
    $req = mysql_query("SELECT * FROM `cms_settings`");
    $set = array ();
    while ($res = mysql_fetch_row($req)) $set[$res[0]] = $res[1];
    echo '<div class="rmenu">' . $lng['settings_saved'] . '</div>';
}
/*
-----------------------------------------------------------------
Erik Supratman = Pasaman Waps
-----------------------------------------------------------------
*/
echo '<form action="index.php?act=settings" method="post"><div class="menu">';
// Erik Supratman = Pasaman Waps
echo '<p>' .
    '<h3>' . $lng['common_settings'] . '</h3>' .
    $lng['site_url'] . ':<br/>' . '<input type="text" name="homeurl" value="' . htmlentities($set['homeurl']) . '"/><br/>' .
    $lng['title_site'] . ':<br/>' . '<input type="text" name="copyright" value="' . htmlentities($set['copyright'], ENT_QUOTES, 'UTF-8') . '"/><br/>' .
    $lng['site_email'] . ':<br/>' . '<input name="madm" maxlength="50" value="' . htmlentities($set['email']) . '"/><br />' .
    $lng['file_maxsize'] . ' (kb):<br />' . '<input type="text" name="flsz" value="' . intval($set['flsz']) . '"/><br />' .
    '<input name="gz" type="checkbox" value="1" ' . ($set['gzip'] ? 'checked="checked"' : '') . ' />&#160;' . $lng['gzip_compress'] .
    '</p>';
// Erik Supratman = Pasaman Waps
echo '<p>' .
    '<h3>' . $lng['clock_settings'] . '</h3>' .
    '<input type="text" name="timeshift" size="2" maxlength="3" value="' . $set['timeshift'] . '"/> ' . $lng['time_shift'] . ' (+-12)<br />' .
    '<span style="font-weight:bold; background-color:#C0FFC0">' . date("H:i", time() + $set['timeshift'] * 3600) . '</span> ' . $lng['system_time'] .
    '<br /><span style="font-weight:bold; background-color:#FFC0C0">' . date("H:i") . '</span> ' . $lng['server_time'] .
    '</p>';
// Erik Supratman = Pasaman Waps
echo '<p>' .
    '<h3>' . $lng['meta_tags'] . '</h3>' .
    '&#160;' . $lng['meta_keywords'] . ':<br />&#160;<textarea rows="' . $set_user['field_h'] . '" name="meta_key">' . $set['meta_key'] . '</textarea><br />' .
    '&#160;' . $lng['meta_google'] . ':<br />&#160;<textarea rows="' . $set_user['field_h'] . '" name="meta_google">' . $set['meta_google'] . '</textarea><br />' .
    '&#160;' . $lng['site_author'] . ':<br />&#160;<textarea rows="' . $set_user['field_h'] . '" name="meta_author">' . $set['meta_author'] . '</textarea><br />' .
    '&#160;' . $lng['site_copyright'] . ':<br />&#160;<textarea rows="' . $set_user['field_h'] . '" name="erik">' . $set['erik'] . '</textarea><br />' .
    '&#160;Official Blog:<br />&#160;<textarea rows="' . $set_user['field_h'] . '" name="official_blog">' . $set['official_blog'] . '</textarea><br />' .
    '&#160;' . $lng['title_seo'] . ':<br />&#160;<textarea rows="' . $set_user['field_h'] . '" name="seo_title">' . $set['seo_title'] . '</textarea><br />' .
    '&#160;' . $lng['type_seo'] . ':<br />&#160;<textarea rows="' . $set_user['field_h'] . '" name="seo_type">' . $set['seo_type'] . '</textarea><br />' .
    '&#160;' . $lng['image_seo'] . ':<br />&#160;<textarea rows="' . $set_user['field_h'] . '" name="seo_image">' . $set['seo_image'] . '</textarea><br />' .
    '&#160;' . $lng['url_seo'] . ':<br />&#160;<textarea rows="' . $set_user['field_h'] . '" name="seo_url">' . $set['seo_url'] . '</textarea><br />' .
    '&#160;' . $lng['meta_description'] . ' & ' . $lng['description_seo'] . ':<br />&#160;<textarea rows="' . $set_user['field_h'] . '" name="meta_desc">' . $set['meta_desc'] . '</textarea>' .
    '</p>';
// Erik Supratman = Pasaman Waps
echo '<p><h3>' . $lng['design_template'] . '</h3>&#160;<select name="skindef">';
$dir = opendir('../theme');
while ($skindef = readdir($dir)) {
    if (($skindef != '.') && ($skindef != '..') && ($skindef != '.svn')) {
        $skindef = str_replace('.css', '', $skindef);
        echo '<option' . ($set['skindef'] == $skindef ? ' selected="selected">' : '>') . $skindef . '</option>';
    }
}
closedir($dir);
echo '</select>' .
    '</p><p><input type="submit" name="submit" value="' . $lng['save'] . '"/></p></div></form>' .
    '<div class="phdr"><a href="index.php">' . $lng['admin_panel'] . '</a></div>';
?>