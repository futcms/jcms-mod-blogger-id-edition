<?php
defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 9) {
    header('Location: http://johncms.com/?err');
    exit;
}

echo '<div class="phdr"><b>Prefix Management</b></div>';
 
switch ($mod) {
    case 'delete'':
$id = functions::checkout($_GET['id']);

        if (!$id) {
            echo functions::display_error($lng['error_wrong_data'], '<a href="index.php?act=prefix">' . $lng_forum['forum_management'] . '</a>');
            require('../incfiles/end.php');
            exit;
        }

$data = mysql_fetch_array(mysql_query("SELECT * FROM `cms_prefix` WHERE `id` = '" . $id . "'"));
                    mysql_query("DELETE FROM `cms_prefix` WHERE `id` = '" . $data['id'] . "'");
 echo '<div class="rmenu">Prefix has been deleted</div>';
     break;
    case 'add':

        if (isset($_POST['submit'])) {
            $prf_name = isset($_POST['prf_name']) ? functions::check($_POST['prf_name']) : '';
            $style = $_POST['style'];

if ($prf_name == NULL || $style == NULL) {
echo '<div class="menu"><span style="color: red"><b>Field can't be empty</b></span></div>';
} else { 
                if (mysql_query("INSERT INTO `cms_prefix` SET
                `text` = '$prf_name',
                `style` = '$style',
                `id_add` = '$user_id' ")
                ) {
                    header('Location: index.php?act=prefix');
                } else {
                    echo mysql_error();
                }
}
}
            echo '<form action="index.php?act=prefix&mod=add" method="post">' ;

echo '<div class="menu">' .
                '<p><b>Prefix name:</b></p>' .
                '<input type="text" name="prf_name" />' ;
echo '</div>' ;
echo '<div class="menu">' .
                '<p><b>Style CSS Prefix:</b></p>' .
                '<textarea name="style" rows="2"></textarea>' ;
echo '</div>';
echo '<div class="menu">' .
            '<input type="submit" value="Add""" name="submit" />' .
                '</div></form>' ;

    break;
    default;
echo '<div class="topmenu"><a class="button" href="?act=prefix&mod=add">Add</a></div>';

$prf = mysql_query("SELECT * FROM `cms_prefix` ORDER BY `id`");
while ($show = mysql_fetch_array($prf)) {
echo '<div class="list1" style="padding:10px;"><span style="'.$show['style'].'">'.$show['text'].'</span><div class"sub"><a href="?act=prefix&mod=delete&id='.$show['id'].'"><input type="submit" value="Delete""/></a>&nbsp;<a href="?act=prefix&mod=edit"><input type="submit" value="Edit""/></a></div></div>';

}

}




























