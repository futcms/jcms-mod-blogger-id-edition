<?php

defined('_IN_JOHNADM') or die('Error: restricted access');

if ($rights < 7) {
    header('Location: ../index.php?err');
    exit;
}


echo '<div class="phdr"><a href="index.php"><b>' . $lng['admin_panel'] . '</b></a> | Blog Settings</div>';
if (isset($_POST['submit'])) {
$blogdomain = $_POST['blogdomain'];
$blogsubdomaindisallow = $_POST['blogsubdomaindisallow'];
$blogwildcard = ctype_digit($_POST['blogwildcard']) ? $_POST['blogwildcard'] : 0;
$blogpreview = ctype_digit($_POST['blogpreview']) ? $_POST['blogpreview'] : 1;
$blogcat = $_POST['blogcat'];
$blogmax = ctype_digit($_POST['blogmax']) ? $_POST['blogmax'] : 10;
$blogediturl = $_POST['blogediturl'];
    mysql_query("UPDATE `cms_settings` SET `val`='" . mysql_real_escape_string($blogwildcard) . "' WHERE `key` = 'blogwildcard'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . mysql_real_escape_string($blogpreview) . "' WHERE `key` = 'blogpreview'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($blogdomain) . "' WHERE `key` = 'blogdomain'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($blogsubdomaindisallow) . "' WHERE `key` = 'blogsubdomaindisallow'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . mysql_real_escape_string($blogcat) . "' WHERE `key` = 'blogcat'");
$blog_categories = explode(",",$blogcat);
$in = array();
for ($i=0;$i<count($blog_categories);$i++) {
$in[] = strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$blog_categories[$i])));
}
mysql_query("UPDATE `blog_sites` SET `category`='uncategories' WHERE FIND_IN_SET(category,'".implode(",",$in)."') = 0");

    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($blogmax) . "' WHERE `key` = 'blogmax'");
    mysql_query("UPDATE `cms_settings` SET `val`='" . functions::check($blogediturl) . "' WHERE `key` = 'blogediturl'");
$req = mysql_query("SELECT * FROM `cms_settings`");
$return = "";
if ($blogwildcard != $set['blogwildcard']) {
if (!copy("../incfiles/blog/".$blogwildcard.".htaccess","../.htaccess"))
$return = '<br />WARNING: Gagal membuat .htaccess baru. Silakan masuk ke FTP Client dan salin file "incfiles/blog/'.$blogwildcard.'.htaccess" menjadi .htaccess dan simpan dalam root yang digunakan situs ini (sejajar dengan exit.php).';
else
$return = "";
}
    $set = array ();
    while ($res = mysql_fetch_row($req)) $set[$res[0]] = $res[1];
    echo '<div class="rmenu">' . $lng['settings_saved'] . $return . '</div>';
}

echo '<form action="index.php?act=blog" method="post">' .
    '<div class="gmenu"><p><h3>Domain</h3><input type="text" name="blogdomain" value="'.htmlentities($set['blogdomain']).'"/><br /><span>Jika domain lebih dari satu pisahkan dengan koma (,). Contoh: domain1.com,domain2.com</span><br /><h3>Subdomain dilarang</h3><input type="text" name="blogsubdomaindisallow" value="'.htmlentities($set['blogsubdomaindisallow']).'"/><br /><span>Jika subdomain lebih dari satu pisahkan dengan koma (,). Contoh: mail,cpanel</span><br /><h3>URL Blog</h3>
<input type="radio" name="blogwildcard" value="1"'.($set['blogwildcard'] == "1" ? ' checked="checked"' : '').'> http://username.'.str_replace("http://","",str_replace("http://www.","",$set['homeurl'])).' (Wildcard subdomain harus aktif).<br /><input type="radio" name="blogwildcard" value="0"'.($set['blogwildcard'] == "0" ? ' checked="checked"' : '').'> http://'.str_replace("http://","",str_replace("http://www.","",$set['homeurl'])).'/username<br /><h3>Blog Preview</h3><input type="text" name="blogpreview" value="'.$set['blogpreview'].'" size="10"/><br /><span>ID Blog untuk preview template</span><br /><h3>Kategori</h3><input type="text" name="blogcat" value="'.htmlentities($set['blogcat']).'"/><br /><span>Pisahkan dengan koma (,). Contoh: Kesehatan,Hobi</span><br /><h3>Maksimal Jumlah Blog</h3><input type="text" name="blogmax" value="'.htmlentities($set['blogmax']).'" size="2"/><br /><span>Maksimal jumlah blog per user</span><br /><h3>Mengubah URL Blog</h3><input type="radio" name="blogediturl" value="yes"'.($set['blogediturl'] == "yes" ? ' checked="checked"' : '').'> Ijinkan<br /><input type="radio" name="blogediturl" value="no"'.($set['blogediturl'] == "no" ? ' checked="checked"' : '').'> Jangan ijinkan</p><p><br /><input type="submit" name="submit" value="' . $lng['save'] . '"/></p></div></form><p><a href="index.php">' . $lng['admin_panel'] . '</a></p>';
?>