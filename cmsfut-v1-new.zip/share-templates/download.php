<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

define('_IN_JOHNCMS', 1);require('../incfiles/core.php');
$treq = mysql_query("SELECT * FROM `sharetemplates` WHERE `id`='".mysql_real_escape_string($id)."' AND `type`='file'");

function create_zip($files = array(),$destination = '',$overwrite = false) {
if(file_exists($destination) && !$overwrite) { return false; }
$valid_files = array();
if(is_array($files)) {
foreach($files as $file) {
if(file_exists($file)) {
    $valid_files[] = $file;
   }
  }
 }
if(count($valid_files)) {
$zip = new ZipArchive();
  if($zip->open($destination,$overwrite ? ZIPARCHIVE::OVERWRITE : ZIPARCHIVE::CREATE) !== true) {
   return false;
  }
foreach($valid_files as $file) {
   $zip->addFile($file,basename($file));
  }
  $zip->close();
return file_exists($destination); }
 else {
  return false;
 }
}

$archive = isset($_GET['archive']) ? strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$_GET['archive']))) : false;
if (mysql_num_rows($treq) == 0) { header("Location: index.php");
exit;
}
$tres = mysql_fetch_array($treq);
$template = $tres['user_id']."-".$tres['theme']."-".$tres['template'];
if ($archive AND $archive == "zip") {
$files = array("../files/share-templates/files/".$template.".xml","../files/share-templates/description/".$template.".txt","../files/share-templates/screenshot/".$template.".jpeg");
create_zip($files,"../files/share-templates/download/".$template.".zip",false);
if (file_exists("../files/share-templates/download/".$template.".zip"))
header("Location: ../files/share-templates/download/".$template.".zip");
else
header("Location: download.php?template=".$template);
exit;
}
$file_location = "../files/share-templates/files/".$template.".xml";
$name = $tres['template'].".xml";
header('Content-Description: File Transfer');
header('Content-Type: text/xml');    header('Content-Disposition: attachment; filename='.$name);
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' .$tres['size']);
readfile($file_location);
exit;
?>