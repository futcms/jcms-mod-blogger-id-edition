<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

define('_IN_JOHNCMS', 1);$headmod = "sharetemplates";
require('../incfiles/core.php');
$textl = "Share Templates | Upload";
if (!$user_id) {
header("location: index.php");
exit;
}
$bprev = mysql_fetch_array(mysql_query("SELECT * FROM `blog_sites` WHERE `id` = '".mysql_real_escape_string($set['blogpreview'])."'"));
if (!$bprev) {
die("Blog untuk preview template tidak ada.");
exit;
}
$blogpreview = "u".$bprev['user_id']."-b".$bprev['id'];
ini_set("ignore_user_abort",true);
if (isset($_POST['upload'])) {
$err = array();
if ($_POST['tmp'] == "mobile") {
$temp="mobile";
$wd = 230;
}
else {
$temp="desktop";
$wd = 1024;
}
$name = $_POST['nama'];
$filename = $name;
$name=preg_replace('#([\W_]+)#',' ',$name);
$name=str_replace(' ','-',$name);
$name=strtolower($name);
$desc = str_replace("|","-",str_replace("^","'",$_POST['description']));
$types = array("application/xml","text/xml","text/html","text/xhtml");
if (file_exists("../files/share-templates/files/".$user_id."-".$temp."-".$name.".xml")){
$err[] = "Nama file sudah ada.";
}
elseif (!in_array($_FILES['fail']['type'],$types)) {
$err[] = "Jenis file tidak benar";
}
elseif(substr($_FILES['fail']['name'],-4) != ".xml") {
$err[] = "Ekstensi file tidak benar.";
}
elseif ($_FILES['fail']['size'] > 501024) {
$err[] = "Ukuran file melebihi 50 kb.";
}
elseif (strlen($name) > 30 OR strlen($name) < 4) {
$err[] = "Nama file minimal 4 dan maksimal 30 karakter.";
}
elseif (mb_strlen($desc) < 5 OR mb_strlen($desc) > 5000) {
$err[] = "Keterangan minimal 5 dan maksimal 5000 karakter."; } else {
if(is_file("../files/templates/".$blogpreview."-".$temp.".xml"))
unlink("../files/templates/".$blogpreview."-".$temp.".xml");
if (move_uploaded_file($_FILES['fail']['tmp_name'],"../files/share-templates/files/".$user_id."-".$temp."-".$name.".xml")) {
file_put_contents("../files/share-templates/description/".$user_id."-".$temp."-".$name.".txt",$desc);
copy("../files/share-templates/files/".$user_id."-".$temp."-".$name.".xml","../files/templates/".$blogpreview."-".$temp.".xml");
ini_set("user_agent",$_SERVER['HTTP_USER_AGENT']);
copy("http://mini.site-shot.com/".$wd."/400/jpeg/?".functions::blog_link($bprev['url1'])."/".$temp.".iwb?rand".rand(100000,99999)."=src".time(),"../files/share-templates/screenshot/".$user_id."-".$temp."-".$name.".jpeg");
if ($rights == 7 || $rights == 9)
$tipe = "file";
else
$tipe = "xfile";
mysql_query("INSERT INTO `sharetemplates` SET `user_id`='".$user_id."',`name`='".mysql_real_escape_string($filename)."',`template`='".mysql_real_escape_string($name)."',`theme`='".mysql_real_escape_string($temp)."',`size`='".mysql_real_escape_string($_FILES['fail']['size'])."',`text`='".mysql_real_escape_string($desc)."',`type`='".$tipe."',`time`='".time()."'");
$tid = mysql_insert_id();
if ($tipe == "xfile") { require('../incfiles/head.php');
echo '<div class="phdr"><a href="index.php"><b>Share Templates</b></a> | Upload</div><div class="rmenu">Template berhasil diupload. Mohon tunggu, template Kamu sedang menunggu moderasi Administrator.<br /><a href="index.php">Kembali</a></div>';
require('../incfiles/end.php');
exit;
} else {
header("Location: detail.php?id=".$tid);
exit;
}
}
else {
$err[] = "Gagal mengupload file. Cobalah beberapa saat lagi.";
}
}
}
require('../incfiles/head.php');
echo '<div class="phdr"><a href="index.php"><b>Share Templates</b></a> | Upload</div>';

if ($err)
echo functions::display_error($err);

echo '<div class="rmenu"><h3>Ketentuan</h3>* Dilarang mengupload template yang sudah ada.<br />* Dilarang memodifikasi template orang lain lalu menguploadnya tanpa seijin pemilik.<br />* Dilarang menggunakan HTML MyWapBlog.<br /><br />Jika ketentuan di atas dilanggar maka template yang diupload akan dihapus dan pemblokiran akun Anda.</div><div class="gmenu"><p><h3>File</h3><form action="upload.php" method="post" enctype="multipart/form-data">
    <input name="MAX_FILE_SIZE" value="522880" type="hidden"/><input type="file" name="fail"/><br /><span>Ekstensi file harus .xml dan ukuran maksimal 50 kb.</span><br /><h3>Nama</h3><input type="text" name="nama" maxlength="20" value=""/><br /><span>Tanpa ekstensi, 4 - 30 karakter</span><br /><h3>Template</h3><select name="tmp"><option value="mobile">Mobile</option><option value="desktop">Desktop</option></select><br /><h3>Keterangan</h3><textarea name="description" rows="5"></textarea><br /><span>Minimal 5 dan maksimal 5000 karakter</span><br /><p><input name="upload" type="submit" value="Upload"/></form></p></p></div>';
require('../incfiles/end.php');

?>
