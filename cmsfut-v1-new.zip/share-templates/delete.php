<?php
/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

 
define('_IN_JOHNCMS', 1);
require('../incfiles/core.php');
if ($rights == 7 || $rights == 9) {
$treq = mysql_query("SELECT * FROM `sharetemplates` WHERE `id`='".mysql_real_escape_string($id)."' AND (`type`='file' OR `type`='xfile')");
} else {
$treq = mysql_query("SELECT * FROM `sharetemplates` WHERE `id`='".mysql_real_escape_string($id)."' AND `type`='file'");
}
$textl = "Share Templates";
if (!$user_id) {
header("location: index.php");
exit;
}
$sess = $_GET['sess'];
if (!$sess OR empty($sess) OR empty($_SESSION['auth']) OR ($sess != $_SESSION['auth'])) {
header("Location: index.php");
exit;
}
unset($_SESSION['auth']);
if (mysql_num_rows($treq) == 0) {
header("Location: index.php");
exit;
}
$tres = mysql_fetch_array($treq);
$template = $tres['user_id']."-".$tres['theme']."-".$tres['template'];
if(($tres['user_id'] == $user_id) OR $rights == 7 OR $rights == 9) {
if (unlink("../files/share-templates/files/".$template.".xml") === false) {
require("../incfiles/head.php");
echo '<div class="rmenu">Gagal menghapus file!</div>';
require("../incfiles/end.php");
exit;
}
if (file_exists("../files/share-templates/screenshot/".$template.".jpeg"));
unlink("../files/share-templates/screenshot/".$template.".jpeg");
if (file_exists("../files/share-templates/description/".$template.".txt"));
unlink("../files/share-templates/description/".$template.".txt");
if (file_exists("../files/share-templates/download/".$template.".zip"));
unlink("../files/share-templates/download/".$template.".zip");
mysql_query("DELETE FROM `sharetemplates` WHERE `template`='".$tres['id']."' AND `type`='comment'");
mysql_query("DELETE FROM `sharetemplates` WHERE `template`='".$tres['id']."' AND `type`='like'");
mysql_query("DELETE FROM `sharetemplates` WHERE `template`='".$tres['id']."' AND `type`='notlike'");
mysql_query("DELETE FROM `sharetemplates` WHERE `id`='".$tres['id']."' AND (`type`='file' OR `type`='xfile')");
}
else {
header("Location: index.php");
exit;
}
header("Location: index.php");
?>