<?php

/**
 * @package     JohnCMS Blogger Edition
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
  * @developed      Achunk JealousMan http://facebook.com/achunks achunk17@gmail.com
 */

define('_IN_JOHNCMS', 1);
$headmod = "sharetemplates";
require('../incfiles/core.php');
$textl = "Share Templates";
require('../incfiles/head.php');
echo '<div class="phdr">Share Templates</div>';
$author = isset($_GET['author']) ? strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$_GET['author']))) : false;
$theme = isset($_GET['theme']) ? strtolower(str_replace(' ','-',preg_replace('#([\W_]+)#',' ',$_GET['theme']))) : false;
$search = isset($_GET['search']) ? htmlspecialchars($_GET['search']) : false;
if ($author) {
$sql_query = " `user_id`='".mysql_real_escape_string($author)."' AND";
$link = "author=".htmlentities($author)."&amp;";
} elseif ($search  AND mb_strlen($search) > 1 AND mb_strlen($search) < 10) { $sql_query = " (`name` LIKE '%".mysql_real_escape_string($search)."%' OR `template` LIKE '%".mysql_real_escape_string($search)."%') AND";
$link = "search=".htmlentities($search)."&amp;";
} elseif ($theme AND $theme == "mobile") { $sql_query = " `theme`='mobile' AND";
$link = "theme=mobile&amp;"; } elseif ($theme AND $theme == "desktop") { $sql_query = " `theme`='desktop' AND";
$link = "theme=desktop&amp;"; } else { $sql_query = "";
$link = ""; }
if(($rights == 7 || $rights == 9) && ($theme == "moderated")) { $tipe = 'xfile'; $link = "theme=moderated&amp;"; } else { $tipe = 'file'; }
$total = mysql_result(mysql_query("SELECT COUNT(*) FROM `sharetemplates` WHERE".$sql_query." `type`='".$tipe."'"),0);
echo '<div class="gmenu"><form method="get" action="index.php"><input type="text" name="search" value="'.$search.'"/><br /><input type="submit" value="Cari"/></form></div>';
if ($search AND mb_strlen($search) > 1 AND mb_strlen($search) < 10)
echo '<div class="rmenu">Ditemukan <b>'.$total.'</b> untuk pencarian <b>'.$search.'</b></div>';
if ($author AND ($author != "")) {
$q = mysql_query("SELECT `name` FROM `users` WHERE `id`='".mysql_real_escape_string($author)."'");
if (mysql_num_rows($q)) { $p = mysql_fetch_assoc($q); echo '<div class="rmenu">Penampilkan template yang dipublikasikan oleh <a href="../users/profile.php?user='.$author.'">'.$p['name'].'</a></div>';
}
}
if ($total == 0) { echo '<div class="rmenu">Template tidak ada</div>'; } else {
if ($total > $kmess) echo '<div class="topmenu">' . functions::display_pagination("index.php?".$link, $start, $total, $kmess) . '</div>';
$treq = mysql_query("SELECT * FROM `sharetemplates` WHERE".$sql_query." `type`='".$tipe."' ORDER BY `time` DESC LIMIT $start, $kmess;");
while($tres=mysql_fetch_array($treq)) {
echo $i % 2 ? '<div class="list2">' : '<div class="list1">';
echo '<div style="float:left;width:80px;">';
if(file_exists("../files/share-templates/screenshot/".$tres['user_id']."-".$tres['theme']."-".$tres['template'].".jpeg"))
echo '<img src="../files/share-templates/screenshot/'.$tres['user_id'].'-'.$tres['theme'].'-'.$tres['template'].'.jpeg" width="78" height="100" alt=""/>';
else
echo '<img src="../files/share-templates/screenshot/no-preview.jpg" width="78" height="100" alt=""/>';
echo '</div>';
echo '<div style="float:right;width:120px;"><a href="detail.php?id='.$tres['id'].'">'.htmlspecialchars($tres['name']).'</a><br /><span>Template: '.ucfirst($tres['theme']).'<br />Diunggah: '.functions::display_date($tres['time']).'</span></div><div style="clear:both;"></div>';
echo '</div><div style="clear:both;"></div>';
$i++;
} if ($total > $kmess) echo '<div class="topmenu">' . functions::display_pagination("index.php?".$link, $start, $total, $kmess) . '</div>';
}
echo '<div class="func">';
if ($rights == 7 || $rights == 9) {
echo '<a class="red" href="index.php?theme=moderated">Menunggu Moderasi ('.$count_new_template.')</a><br />';
}
echo '<a href="index.php?theme=mobile">Mobile Template</a><br /><a href="index.php?theme=desktop">Desktop Template</a>'.($user_id ? '<br /><a href="upload.php">Upload</a><br /><a href="index.php?author='.$user_id.'">My Template</a>' : '').'</div>';
require('../incfiles/end.php');
?>
